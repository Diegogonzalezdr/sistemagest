# Cómo instalar SistemaGest en Windows

## Opción 1 — Netlify (Recomendada, 5 minutos)

1. Crea cuenta gratis en **netlify.com**
2. En el Dashboard haz clic en **"Add new site" → "Deploy manually"**
3. Arrastra la carpeta `mi-sistema` completa al área de arrastre
4. Netlify te da una URL como: `https://sistemagest-xxxx.netlify.app`
5. Abre esa URL en Chrome
6. En la barra de Chrome aparece un ícono de instalación (⊕) a la derecha
7. Haz clic → **"Instalar"** → el sistema queda en el escritorio como app

## Opción 2 — GitHub Pages

1. Crea cuenta en **github.com**
2. Crea repositorio nuevo llamado `sistemagest`
3. Sube todos los archivos de `mi-sistema/`
4. Ve a Settings → Pages → Branch: main → Save
5. URL: `https://tu-usuario.github.io/sistemagest`
6. Instala desde Chrome igual que la Opción 1

## Instalar en Windows desde Chrome

Una vez tengas la URL pública:
1. Abre la URL en **Google Chrome**
2. Espera que cargue completamente
3. En la barra de direcciones (derecha) aparece ícono **⊕ Instalar**
4. Clic → **"Instalar"**
5. ¡Listo! Aparece el ícono en el escritorio y en el menú Inicio

## ⚠ Importante

- El sistema necesita estar en **HTTPS** para que funcione como PWA
- Netlify y GitHub Pages dan HTTPS gratis automáticamente
- **No funciona** desde `file://` ni desde `localhost` para instalar como PWA
