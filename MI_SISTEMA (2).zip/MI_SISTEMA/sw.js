/**
 * sw.js — Service Worker para SistemaGest PWA
 * Permite funcionamiento offline y caching de recursos
 */

const CACHE_NAME   = 'sistemgest-v1.7';
const CACHE_STATIC = [
  '/',
  '/index.html',
  '/login.html',
  '/app.js',
  '/styles/main.css',
  '/db/database.js',
  '/libs/sql-wasm.js',
  '/libs/sql-wasm.wasm',
  '/manifest.json',
  '/modules/ventas.js',
  '/modules/compras.js',
  '/modules/clientes.js',
  '/modules/proveedores.js',
  '/modules/facturacion.js',
  '/modules/usuarios.js',
  '/modules/documentos.js',
  '/modules/facturas-proveedores.js',
  '/modules/api-dian.js',
  '/modules/email.js',
  '/modules/backup.js',
  '/modules/reportes.js',
  '/icons/icon-192.png',
  '/icons/icon-512.png',
];

// ── Instalación: cachea todos los recursos estáticos ──
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(CACHE_STATIC.map(url => new Request(url, { cache: 'reload' })))
        .catch(err => console.warn('SW cache parcial:', err));
    }).then(() => self.skipWaiting())
  );
});

// ── Activación: elimina caches antiguos ──
self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

// ── Fetch: sirve desde caché, con red como fallback ──
self.addEventListener('fetch', event => {
  // Solo cachea peticiones GET al mismo origen
  if (event.request.method !== 'GET') return;
  if (!event.request.url.startsWith(self.location.origin)) return;

  event.respondWith(
    caches.match(event.request).then(cached => {
      if (cached) return cached;
      return fetch(event.request).then(response => {
        if (!response || response.status !== 200) return response;
        const clone = response.clone();
        caches.open(CACHE_NAME).then(cache => cache.put(event.request, clone));
        return response;
      }).catch(() => {
        // Si no hay red y no está en caché, devuelve index.html como fallback
        if (event.request.destination === 'document') {
          return caches.match('/index.html');
        }
      });
    })
  );
});
