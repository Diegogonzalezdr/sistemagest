/**
 * backup.js — Sistema de copias de seguridad automáticas
 *
 * - Copia diaria automática a la hora configurada
 * - Exporta BD SQLite + configuración en archivo ZIP
 * - Restauración desde ZIP con contraseña de administrador
 * - Configuración de hora desde el módulo de Configuración
 */

// ============================================================
//  CONSTANTES
// ============================================================
const BACKUP_HORA_KEY   = 'sg_backup_hora';
const BACKUP_ULTIMA_KEY = 'sg_backup_ultima';
const BACKUP_TIMER_KEY  = 'sg_backup_timer_id';
const NOMBRE_ARCHIVO    = 'SistemaGest_Backup';

// ============================================================
//  UTILIDADES ZIP (sin librería externa — formato ZIP manual)
// ============================================================

// CRC32 para validación del ZIP
const crc32Table = (() => {
  const t = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
    t[i] = c;
  }
  return t;
})();

function calcCRC32(data) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < data.length; i++)
    crc = crc32Table[(crc ^ data[i]) & 0xFF] ^ (crc >>> 8);
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

function strToBytes(str) {
  return new TextEncoder().encode(str);
}

function uint32LE(n) {
  const b = new Uint8Array(4);
  b[0]=n&0xFF; b[1]=(n>>8)&0xFF; b[2]=(n>>16)&0xFF; b[3]=(n>>24)&0xFF;
  return b;
}

function uint16LE(n) {
  return new Uint8Array([n&0xFF, (n>>8)&0xFF]);
}

function concat(...arrays) {
  const total = arrays.reduce((s,a) => s + a.length, 0);
  const out   = new Uint8Array(total);
  let offset  = 0;
  for (const a of arrays) { out.set(a, offset); offset += a.length; }
  return out;
}

// Crea un archivo ZIP con múltiples entradas { name, data (Uint8Array) }
function crearZIP(entradas) {
  const archivos   = [];
  let   offsetLocal = 0;

  for (const { name, data } of entradas) {
    const nameBytes = strToBytes(name);
    const crc       = calcCRC32(data);
    const now       = new Date();
    const dosDate   = ((now.getFullYear()-1980)<<9)|((now.getMonth()+1)<<5)|now.getDate();
    const dosTime   = (now.getHours()<<11)|(now.getMinutes()<<5)|(now.getSeconds()>>1);

    // Local file header
    const localHeader = concat(
      new Uint8Array([0x50,0x4B,0x03,0x04]), // signature
      uint16LE(20),          // version needed
      uint16LE(0),           // flags
      uint16LE(0),           // compression (stored)
      uint16LE(dosTime),
      uint16LE(dosDate),
      uint32LE(crc),
      uint32LE(data.length), // compressed size
      uint32LE(data.length), // uncompressed size
      uint16LE(nameBytes.length),
      uint16LE(0),           // extra field length
      nameBytes
    );

    archivos.push({ name, nameBytes, data, crc, localHeader, offset: offsetLocal, dosDate, dosTime });
    offsetLocal += localHeader.length + data.length;
  }

  // Central directory
  const centralDirs = archivos.map(f => concat(
    new Uint8Array([0x50,0x4B,0x01,0x02]), // signature
    uint16LE(20), uint16LE(20),
    uint16LE(0), uint16LE(0),
    uint16LE(f.dosTime), uint16LE(f.dosDate),
    uint32LE(f.crc),
    uint32LE(f.data.length),
    uint32LE(f.data.length),
    uint16LE(f.nameBytes.length),
    uint16LE(0), uint16LE(0), uint16LE(0), uint16LE(0),
    uint32LE(0),
    uint32LE(f.offset),
    f.nameBytes
  ));

  const centralDir    = concat(...centralDirs);
  const centralOffset = offsetLocal;

  // End of central directory record
  const eocd = concat(
    new Uint8Array([0x50,0x4B,0x05,0x06]),
    uint16LE(0), uint16LE(0),
    uint16LE(archivos.length),
    uint16LE(archivos.length),
    uint32LE(centralDir.length),
    uint32LE(centralOffset),
    uint16LE(0)
  );

  const partes = [];
  for (const f of archivos) { partes.push(f.localHeader); partes.push(f.data); }
  partes.push(centralDir);
  partes.push(eocd);

  return concat(...partes);
}

// Lee el primer archivo de un ZIP y retorna sus bytes
function leerPrimerArchivoZIP(zipBytes) {
  // Busca la firma del local file header
  if (zipBytes[0]!==0x50||zipBytes[1]!==0x4B||zipBytes[2]!==0x03||zipBytes[3]!==0x04) {
    throw new Error('El archivo no es un ZIP válido.');
  }
  const nameLen  = zipBytes[26] | (zipBytes[27]<<8);
  const extraLen = zipBytes[28] | (zipBytes[29]<<8);
  const dataSize = zipBytes[18] | (zipBytes[19]<<8) | (zipBytes[20]<<16) | (zipBytes[21]<<24);
  const dataStart= 30 + nameLen + extraLen;
  return zipBytes.slice(dataStart, dataStart + dataSize);
}

// Extrae TODOS los archivos del ZIP → { nombre: Uint8Array }
function extraerTodosDelZIP(zipBytes) {
  const archivos = {};
  let pos = 0;
  while (pos < zipBytes.length - 4) {
    if (zipBytes[pos]===0x50&&zipBytes[pos+1]===0x4B&&zipBytes[pos+2]===0x03&&zipBytes[pos+3]===0x04) {
      const nameLen  = zipBytes[pos+26] | (zipBytes[pos+27]<<8);
      const extraLen = zipBytes[pos+28] | (zipBytes[pos+29]<<8);
      const dataSize = zipBytes[pos+18]|(zipBytes[pos+19]<<8)|(zipBytes[pos+20]<<16)|(zipBytes[pos+21]<<24);
      const nameBytes= zipBytes.slice(pos+30, pos+30+nameLen);
      const nombre   = new TextDecoder().decode(nameBytes);
      const dataStart= pos + 30 + nameLen + extraLen;
      archivos[nombre] = zipBytes.slice(dataStart, dataStart + dataSize);
      pos = dataStart + dataSize;
    } else {
      pos++;
    }
  }
  return archivos;
}

// ============================================================
//  CREAR COPIA DE SEGURIDAD
// ============================================================
async function crearBackup(mostrarMensaje = true) {
  try {
    const ahora    = new Date();
    const fechaStr = ahora.toISOString().replace(/[:.]/g,'-').substring(0,19);
    const nombre   = `${NOMBRE_ARCHIVO}_${fechaStr}`;

    // 1. Exportar BD SQLite como bytes
    const dbRef  = window.db || DB.db || (DB._db) || null;
    const bdData = dbRef ? dbRef.export() : null;
    if (!bdData) {
      // Intentar obtener los bytes desde localStorage directamente
      const raw = localStorage.getItem('sistemgest_db');
      if (!raw) throw new Error('La base de datos no está disponible.');
      // Guardar desde localStorage como fallback
      const arr  = JSON.parse(raw);
      const uint = new Uint8Array(arr);
      // Crear ZIP directamente con los bytes del localStorage
      const zipBytes = crearZIP([
        { name: 'sistemagest.db',   data: uint },
        { name: 'backup_meta.json', data: strToBytes(JSON.stringify({
            version:'1.0', fecha: ahora.toISOString(), sistema:'SistemaGest',
            empresa: DB.Config.get('nombre_empresa') || 'Mi Empresa',
            nota:'Backup desde localStorage'
          }, null, 2)) },
      ]);
      const blob = new Blob([zipBytes], { type:'application/zip' });
      const url  = URL.createObjectURL(blob);
      const a    = document.createElement('a');
      a.href = url; a.download = `${nombre}.zip`;
      document.body.appendChild(a); a.click();
      document.body.removeChild(a); URL.revokeObjectURL(url);
      localStorage.setItem(BACKUP_ULTIMA_KEY, ahora.toLocaleString('es-CO'));
      DB.Notificaciones.create('exito','Copia de seguridad creada',`Backup generado: ${nombre}.zip`);
      DB.saveDB();
      if (typeof updateNotifBadge==='function') updateNotifBadge();
      if (mostrarMensaje && typeof showToast==='function') showToast(`✓ Backup creado: ${nombre}.zip`);
      const ultimaEl = document.getElementById('backup-ultima');
      if (ultimaEl) ultimaEl.textContent = ahora.toLocaleString('es-CO');
      return true;
    }

    // 2. Metadatos del backup (bdData ya está disponible via dbRef)
    const meta = {
      version:   '1.0',
      fecha:     ahora.toISOString(),
      sistema:   'SistemaGest',
      empresa:   DB.Config.get('nombre_empresa') || 'Mi Empresa',
      tablas:    DB.dbQuery("SELECT name FROM sqlite_master WHERE type='table'").map(t=>t.name),
      registros: {
        productos:   DB.dbQuery("SELECT COUNT(*) as n FROM productos")[0]?.n || 0,
        ventas:      DB.dbQuery("SELECT COUNT(*) as n FROM ventas")[0]?.n || 0,
        compras:     DB.dbQuery("SELECT COUNT(*) as n FROM compras")[0]?.n || 0,
        clientes:    DB.dbQuery("SELECT COUNT(*) as n FROM clientes")[0]?.n || 0,
        proveedores: DB.dbQuery("SELECT COUNT(*) as n FROM proveedores")[0]?.n || 0,
      }
    };

    // 3. Crear ZIP con BD + metadatos
    const zipBytes = crearZIP([
      { name: 'sistemagest.db',   data: new Uint8Array(bdData) },
      { name: 'backup_meta.json', data: strToBytes(JSON.stringify(meta, null, 2)) },
    ]);

    // 4. Descargar ZIP
    const blob = new Blob([zipBytes], { type: 'application/zip' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href     = url;
    a.download = `${nombre}.zip`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    // 5. Registrar última copia
    const horaStr = ahora.toLocaleString('es-CO');
    localStorage.setItem(BACKUP_ULTIMA_KEY, horaStr);

    // 6. Notificación en el sistema
    DB.Notificaciones.create('exito',
      'Copia de seguridad creada',
      `Backup generado: ${nombre}.zip — ${meta.registros.productos} productos, ${meta.registros.ventas} ventas.`
    );
    DB.saveDB();
    if (typeof updateNotifBadge === 'function') updateNotifBadge();

    if (mostrarMensaje && typeof showToast === 'function')
      showToast(`✓ Backup creado: ${nombre}.zip`);

    // Actualizar UI si está visible
    const ultimaEl = document.getElementById('backup-ultima');
    if (ultimaEl) ultimaEl.textContent = horaStr;

    return true;
  } catch(err) {
    console.error('Error al crear backup:', err);
    if (mostrarMensaje && typeof showToast === 'function')
      showToast('✗ Error al crear backup: ' + err.message);
    return false;
  }
}

window.crearBackupManual = function() {
  crearBackup(true);
};

// ============================================================
//  PROGRAMADOR AUTOMÁTICO
// ============================================================
function programarBackupDiario() {
  // Cancela timer anterior si existe
  const timerId = localStorage.getItem(BACKUP_TIMER_KEY);
  if (timerId) clearTimeout(parseInt(timerId));

  const horaConfig = localStorage.getItem(BACKUP_HORA_KEY) || '23:00';
  const [horas, minutos] = horaConfig.split(':').map(Number);

  const ahora  = new Date();
  const target = new Date();
  target.setHours(horas, minutos, 0, 0);

  // Si la hora ya pasó hoy, programar para mañana
  if (target <= ahora) target.setDate(target.getDate() + 1);

  const msHasta = target - ahora;

  const tid = setTimeout(async () => {
    await crearBackup(false); // Silencioso — sin toast
    programarBackupDiario();  // Reprogramar para el día siguiente
  }, msHasta);

  localStorage.setItem(BACKUP_TIMER_KEY, tid.toString());

  console.log(`Backup programado para ${target.toLocaleString('es-CO')}`);
}

// Inicia el programador al cargar el módulo
window.iniciarBackupAutomatico = function() {
  programarBackupDiario();
};

// ============================================================
//  RESTAURAR DESDE ZIP
// ============================================================
window.restaurarBackup = async function() {
  const pass  = document.getElementById('restore-admin-pass').value;
  const msgEl = document.getElementById('restore-msg');
  const fileEl= document.getElementById('restore-file');

  const err = (t) => {
    msgEl.className='alert alert-error'; msgEl.textContent=t; msgEl.style.display='block';
  };

  if (!pass) { err('Ingresa la contraseña de administrador.'); return; }
  if (!fileEl?.files[0]) { err('Selecciona un archivo ZIP de backup.'); return; }

  // Verificar contraseña admin
  try {
    await DB.initDB();
    const admin = DB.dbGet(
      "SELECT * FROM usuarios WHERE rol='admin' AND password=? AND activo=1",
      [pass]
    );
    if (!admin) { err('Contraseña de administrador incorrecta.'); return; }
  } catch(e) { err('Error al verificar contraseña.'); return; }

  if (!confirm(`¿Restaurar la copia de seguridad? Esto REEMPLAZARÁ toda la información actual del sistema.\n\nEsta acción no se puede deshacer.`)) return;

  const btn = document.getElementById('btn-restaurar');
  if (btn) { btn.textContent = '⏳ Restaurando...'; btn.disabled = true; }
  msgEl.style.display = 'none';

  try {
    const file     = fileEl.files[0];
    const zipBytes = new Uint8Array(await file.arrayBuffer());
    const archivos = extraerTodosDelZIP(zipBytes);

    const bdBytes = archivos['sistemagest.db'];
    if (!bdBytes) throw new Error('El ZIP no contiene una BD válida (sistemagest.db).');

    // Verificar metadatos si existen
    let meta = null;
    if (archivos['backup_meta.json']) {
      meta = JSON.parse(new TextDecoder().decode(archivos['backup_meta.json']));
    }

    // Guardar BD restaurada en localStorage
    localStorage.setItem('sistemgest_db', JSON.stringify(Array.from(bdBytes)));

    // Notificación de restauración
    DB.Notificaciones.create('info',
      'Sistema restaurado',
      `Backup restaurado: ${file.name}${meta ? ' — Fecha original: '+new Date(meta.fecha).toLocaleString('es-CO') : ''}`
    );
    DB.saveDB();

    msgEl.className='alert alert-success';
    msgEl.textContent='✓ Backup restaurado correctamente. El sistema se recargará en 3 segundos...';
    msgEl.style.display='block';

    setTimeout(() => location.reload(), 3000);

  } catch(err) {
    if (btn) { btn.textContent='🔄 Restaurar'; btn.disabled=false; }
    err('Error al restaurar: ' + err.message);
  }
};

// ============================================================
//  VISTA — Sección en Configuración
// ============================================================
window.renderSeccionBackup = function() {
  const horaActual  = localStorage.getItem(BACKUP_HORA_KEY) || '23:00';
  const ultimaBackup= localStorage.getItem(BACKUP_ULTIMA_KEY) || 'Nunca';

  return `
    <div style="margin-top:28px">
      <div style="margin-bottom:14px">
        <div style="font-family:var(--font-mono);font-size:13px;font-weight:600;color:var(--text-primary)">
          Copias de Seguridad
        </div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:2px">
          El sistema crea automáticamente un archivo ZIP con toda la información del sistema.
        </div>
      </div>

      <!-- Estado actual -->
      <div class="table-container" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">ESTADO DEL BACKUP</span></div>
        <div style="padding:16px;display:grid;grid-template-columns:1fr 1fr;gap:16px">
          <div>
            <div style="font-family:var(--font-mono);font-size:10px;color:var(--text-muted);
                        letter-spacing:0.1em;margin-bottom:4px">ÚLTIMA COPIA CREADA</div>
            <div style="font-size:13px;color:var(--text-primary)" id="backup-ultima">${ultimaBackup}</div>
          </div>
          <div>
            <div style="font-family:var(--font-mono);font-size:10px;color:var(--text-muted);
                        letter-spacing:0.1em;margin-bottom:4px">HORA PROGRAMADA DIARIA</div>
            <div style="font-size:13px;color:var(--accent);font-family:var(--font-mono)">${horaActual}</div>
          </div>
        </div>
      </div>

      <!-- Configuración de hora -->
      <div class="table-container" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">PROGRAMAR BACKUP AUTOMÁTICO</span></div>
        <div style="padding:16px">
          <div style="display:grid;grid-template-columns:1fr auto;gap:12px;align-items:flex-end;max-width:360px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Hora del backup diario</label>
              <input class="form-input" type="time" id="backup-hora" value="${horaActual}" />
              <div style="font-size:11px;color:var(--text-muted);margin-top:4px">
                El sistema descargará el ZIP automáticamente cada día a esta hora.
              </div>
            </div>
            <button class="btn btn-primary" onclick="guardarHoraBackup()" style="margin-bottom:24px">
              Guardar hora
            </button>
          </div>
        </div>
      </div>

      <!-- Crear backup manual -->
      <div class="table-container" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">CREAR BACKUP AHORA</span></div>
        <div style="padding:16px">
          <p style="font-size:13px;color:var(--text-secondary);margin-bottom:14px">
            Crea una copia de seguridad inmediata con toda la información actual del sistema.
            El archivo ZIP se descargará automáticamente en tu dispositivo.
          </p>
          <button class="btn btn-primary" onclick="crearBackupManual()">
            💾 Descargar copia de seguridad ahora
          </button>
        </div>
      </div>

      <!-- Restaurar backup -->
      <div class="table-container">
        <div class="table-header">
          <span class="table-title">🔒 CARGAR COPIA DE SEGURIDAD</span>
        </div>
        <div style="padding:16px;display:flex;flex-direction:column;gap:14px">
          <div class="alert alert-error" style="font-size:12px">
            ⚠ <strong>Advertencia:</strong> Restaurar un backup reemplazará TODA la información
            actual del sistema. Esta acción no se puede deshacer.
          </div>

          <div class="form-group" style="margin:0">
            <label class="form-label">Contraseña de administrador *</label>
            <input class="form-input" type="password" id="restore-admin-pass"
              placeholder="Requerida para restaurar" />
          </div>

          <div class="form-group" style="margin:0">
            <label class="form-label">Archivo ZIP de backup *</label>
            <div style="border:2px dashed var(--border);border-radius:6px;padding:20px;
                        text-align:center;cursor:pointer;transition:border-color 0.2s"
                 onclick="document.getElementById('restore-file').click()"
                 ondragover="event.preventDefault();this.style.borderColor='var(--accent)'"
                 ondragleave="this.style.borderColor='var(--border)'"
                 ondrop="handleRestoreDrop(event)">
              <div style="font-size:28px;margin-bottom:8px">📦</div>
              <div style="font-size:13px;color:var(--text-secondary)" id="restore-file-label">
                Arrastra el ZIP aquí o haz clic para seleccionar
              </div>
              <div style="font-size:11px;color:var(--text-muted);margin-top:4px">
                Solo archivos .zip generados por SistemaGest
              </div>
              <input type="file" id="restore-file" accept=".zip" style="display:none"
                onchange="mostrarNombreZip(this)"/>
            </div>
          </div>

          <div id="restore-msg" style="display:none" class="alert"></div>

          <button class="btn btn-danger" id="btn-restaurar" onclick="restaurarBackup()">
            🔄 Restaurar copia de seguridad
          </button>
        </div>
      </div>
    </div>
  `;
};

window.guardarHoraBackup = function() {
  const hora = document.getElementById('backup-hora').value;
  if (!hora) { if (typeof showToast==='function') showToast('Selecciona una hora válida.'); return; }
  localStorage.setItem(BACKUP_HORA_KEY, hora);
  programarBackupDiario(); // Reprogramar con nueva hora
  if (typeof showToast==='function') showToast(`✓ Backup automático programado para las ${hora}`);

  // Actualizar display
  const el = document.getElementById('seccion-backup');
  if (el) el.innerHTML = renderSeccionBackup();
};

window.mostrarNombreZip = function(input) {
  const label = document.getElementById('restore-file-label');
  if (label && input.files[0]) label.textContent = '✓ ' + input.files[0].name;
};

window.handleRestoreDrop = function(e) {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  if (!file || !file.name.endsWith('.zip')) {
    if (typeof showToast==='function') showToast('Solo se aceptan archivos .zip');
    return;
  }
  const input = document.getElementById('restore-file');
  const dt    = new DataTransfer();
  dt.items.add(file);
  input.files = dt.files;
  const label = document.getElementById('restore-file-label');
  if (label) label.textContent = '✓ ' + file.name;
};

window.toggleSeccionBackup = function() {
  const sec = document.getElementById('seccion-backup');
  if (!sec) return;
  if (sec.style.display === 'none') {
    sec.style.display = 'block';
    sec.innerHTML = renderSeccionBackup();
  } else {
    sec.style.display = 'none';
  }
};
