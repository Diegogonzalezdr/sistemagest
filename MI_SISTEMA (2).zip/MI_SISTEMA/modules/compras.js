/**
 * compras.js — Módulo de Compras
 * - Registrar compra: producto, cantidad, precio, fecha
 * - Suma automáticamente al stock
 * - Registra movimiento de entrada
 * - Resumen del día con sumatoria
 * - Anular compra (descuenta el stock sumado)
 */

// ============================================================
//  VISTA
// ============================================================
window.viewCompras = function() {
  const hoy = new Date().toISOString().substring(0, 10);
  return `
    <div class="page-header">
      <div>
        <div class="page-title">Compras</div>
        <div class="page-subtitle">Registro de entradas de mercancía</div>
      </div>
      <button class="btn btn-primary" onclick="mostrarResumenCompras()">📊 Ver resumen del día</button>
    </div>

    <!-- FORMULARIO -->
    <div class="table-container" style="max-width:580px; margin-bottom:24px">
      <div class="table-header"><span class="table-title">NUEVA COMPRA</span></div>
      <div style="padding:20px; display:flex; flex-direction:column; gap:14px">

        <div class="form-group" style="margin:0;position:relative">
          <label class="form-label">Producto *</label>
          <input class="form-input" type="text" id="c-buscar-producto"
            placeholder="Buscar por nombre o código..."
            autocomplete="off" />
          <input type="hidden" id="c-producto-id" />
          <div id="c-resultados" style="display:none;position:absolute;top:100%;left:0;right:0;
               background:var(--bg-elevated);border:1px solid var(--accent);border-top:none;
               border-radius:0 0 4px 4px;z-index:200;max-height:220px;overflow-y:auto"></div>
          <div id="c-producto-seleccionado" style="display:none;margin-top:6px;padding:8px 12px;
               background:var(--accent-dim);border:1px solid var(--accent);border-radius:4px;
               font-size:12px;font-family:var(--font-mono);color:var(--accent);
               justify-content:space-between;align-items:center">
            <span id="c-producto-label"></span>
            <button onclick="limpiarProductoCompra()"
              style="background:none;border:none;color:var(--accent);cursor:pointer;font-size:16px;padding:0 4px">×</button>
          </div>
        </div>

        <div style="display:grid; grid-template-columns:1fr 1fr 1fr; gap:12px">
          <div class="form-group" style="margin:0">
            <label class="form-label">Cantidad *</label>
            <input class="form-input" type="number" id="c-cantidad" min="1" value="1">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Precio unitario *</label>
            <input class="form-input" type="number" id="c-precio" min="0" step="0.01" placeholder="0.00">
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Fecha *</label>
            <input class="form-input" type="date" id="c-fecha" value="${hoy}">
          </div>
        </div>

        <div style="background:var(--bg-base); border:1px solid var(--border); border-radius:4px;
                    padding:12px 16px; display:flex; justify-content:space-between; align-items:center">
          <span style="font-family:var(--font-mono); font-size:12px; color:var(--text-muted)">SUBTOTAL</span>
          <span style="font-family:var(--font-mono); font-size:20px; color:var(--green)" id="c-preview">$0.00</span>
        </div>

        <div id="c-msg" style="display:none" class="alert"></div>

        <button class="btn btn-primary" style="padding:11px; font-size:13px" onclick="registrarCompra()">
          ✓ Registrar Compra
        </button>
      </div>
    </div>

    <!-- TABLA -->
    <div class="table-container">
      <div class="table-header">
        <span class="table-title">COMPRAS REGISTRADAS</span>
        <span id="c-total-hoy" style="font-family:var(--font-mono); font-size:12px; color:var(--green)"></span>
      </div>
      <table>
        <thead>
          <tr>
            <th>N°</th>
            <th>Fecha</th>
            <th>Producto</th>
            <th>Cantidad</th>
            <th>Precio Unit.</th>
            <th>Total</th>
            <th>Estado</th>
            <th>Acción</th>
          </tr>
        </thead>
        <tbody id="c-tbody"></tbody>
      </table>
    </div>

    <!-- MODAL RESUMEN -->
    <div id="modal-resumen-compras" style="display:none; position:fixed; inset:0;
         background:rgba(0,0,0,0.75); z-index:500; align-items:center; justify-content:center">
      <div style="background:var(--bg-surface); border:1px solid var(--border); border-radius:6px;
                  width:560px; max-width:95vw; max-height:85vh; overflow-y:auto">
        <div style="display:flex; justify-content:space-between; align-items:center;
                    padding:16px 20px; border-bottom:1px solid var(--border)">
          <span style="font-family:var(--font-mono); font-weight:600">📊 Resumen de compras del día</span>
          <button onclick="document.getElementById('modal-resumen-compras').style.display='none'"
            style="background:none; border:none; color:var(--text-muted); font-size:20px; cursor:pointer">×</button>
        </div>
        <div id="modal-resumen-compras-body" style="padding:20px"></div>
        <div style="padding:14px 20px; border-top:1px solid var(--border); display:flex; justify-content:flex-end; gap:8px">
          <button class="btn btn-outline"
            onclick="document.getElementById('modal-resumen-compras').style.display='none'">Cerrar</button>
          <button class="btn btn-primary" onclick="imprimirResumenCompras()">🖨 Imprimir</button>
        </div>
      </div>
    </div>
  `;
};

// ============================================================
//  CONTROLADOR
// ============================================================
window.initCompras = function() {
  const inputBuscar = document.getElementById('c-buscar-producto');

  inputBuscar.addEventListener('input', function() {
    const q = this.value.trim().toLowerCase();
    const res = document.getElementById('c-resultados');
    if (q.length < 1) { res.style.display = 'none'; return; }

    const productos = DB.Productos.getAll().filter(p =>
      p.nombre.toLowerCase().includes(q) || p.codigo.toLowerCase().includes(q)
    );

    if (!productos.length) {
      res.innerHTML = '<div style="padding:10px 14px;font-size:12px;color:var(--text-muted)">Sin resultados</div>';
      res.style.display = 'block';
      return;
    }

    res.innerHTML = productos.map(p => `
      <div class="c-resultado-item" data-id="${p.id}" data-precio="${p.precio_compra}"
           data-nombre="${p.nombre}" data-codigo="${p.codigo}" data-stock="${p.stock}"
           style="padding:10px 14px;cursor:pointer;border-bottom:1px solid var(--border);
                  display:flex;justify-content:space-between;align-items:center">
        <div>
          <div style="font-size:13px;color:var(--text-primary)">${p.nombre}</div>
          <div style="font-size:10px;font-family:var(--font-mono);color:var(--text-muted)">
            ${p.codigo} · Stock actual: ${p.stock}
          </div>
        </div>
        <div style="font-family:var(--font-mono);font-size:13px;color:var(--green)">
          $${parseFloat(p.precio_compra).toFixed(2)}
        </div>
      </div>
    `).join('');

    res.style.display = 'block';

    res.querySelectorAll('.c-resultado-item').forEach(el => {
      el.addEventListener('mouseenter', () => el.style.background = 'var(--bg-hover)');
      el.addEventListener('mouseleave', () => el.style.background = '');
      el.addEventListener('click', () => {
        seleccionarProductoCompra(el.dataset.id, el.dataset.nombre, el.dataset.codigo,
                                  el.dataset.precio, el.dataset.stock);
      });
    });
  });

  document.addEventListener('click', function(e) {
    if (!e.target.closest('#c-buscar-producto') && !e.target.closest('#c-resultados')) {
      const res = document.getElementById('c-resultados');
      if (res) res.style.display = 'none';
    }
  });

  document.getElementById('c-cantidad').addEventListener('input', actualizarPreviewCompra);
  document.getElementById('c-precio').addEventListener('input', actualizarPreviewCompra);

  renderTablaCompras();
};

function seleccionarProductoCompra(id, nombre, codigo, precio, stock) {
  document.getElementById('c-producto-id').value = id;
  document.getElementById('c-buscar-producto').value = '';
  document.getElementById('c-resultados').style.display = 'none';
  document.getElementById('c-precio').value = parseFloat(precio).toFixed(2);

  const label = document.getElementById('c-producto-label');
  label.textContent = nombre + ' (' + codigo + ') · Stock: ' + stock;

  const sel = document.getElementById('c-producto-seleccionado');
  sel.style.display = 'flex';

  actualizarPreviewCompra();
  document.getElementById('c-cantidad').focus();
}

window.limpiarProductoCompra = function() {
  document.getElementById('c-producto-id').value = '';
  document.getElementById('c-precio').value = '';
  document.getElementById('c-producto-seleccionado').style.display = 'none';
  document.getElementById('c-buscar-producto').value = '';
  document.getElementById('c-preview').textContent = '$0.00';
  document.getElementById('c-buscar-producto').focus();
};

function recargarBuscadorCompra() {
  const id = document.getElementById('c-producto-id').value;
  if (id) {
    const prod = DB.Productos.getById(parseInt(id));
    if (prod) {
      document.getElementById('c-producto-label').textContent =
        prod.nombre + ' (' + prod.codigo + ') · Stock: ' + prod.stock;
    }
  }
}

function actualizarPreviewCompra() {
  const cant   = parseFloat(document.getElementById('c-cantidad').value) || 0;
  const precio = parseFloat(document.getElementById('c-precio').value)   || 0;
  document.getElementById('c-preview').textContent = '$' + (cant * precio).toFixed(2);
}

// ============================================================
//  REGISTRAR COMPRA
// ============================================================
window.registrarCompra = function() {
  const msgEl = document.getElementById('c-msg');
  msgEl.style.display = 'none';
  msgEl.className = 'alert';

  const productoId = parseInt(document.getElementById('c-producto-id').value);
  const cantidad   = parseInt(document.getElementById('c-cantidad').value);
  const precio     = parseFloat(document.getElementById('c-precio').value);
  const fecha      = document.getElementById('c-fecha').value;

  if (!productoId)           { mostrarMsgC('error', 'Busca y selecciona un producto.'); return; }
  if (!cantidad || cantidad < 1) { mostrarMsgC('error', 'La cantidad debe ser mayor a 0.'); return; }
  if (!precio || precio <= 0)    { mostrarMsgC('error', 'El precio debe ser mayor a 0.'); return; }
  if (!fecha)                    { mostrarMsgC('error', 'Selecciona una fecha.'); return; }

  const prod = DB.Productos.getById(productoId);
  if (!prod) { mostrarMsgC('error', 'Producto no encontrado.'); return; }

  // Generar número de compra
  const ultimo = DB.dbGet("SELECT numero FROM compras ORDER BY id DESC LIMIT 1");
  const num    = ultimo ? parseInt(ultimo.numero.replace('C-', '')) + 1 : 1;
  const numero = 'C-' + String(num).padStart(4, '0');
  const subtotal  = cantidad * precio;
  const fechaHora = fecha + ' ' + new Date().toTimeString().substring(0, 8);

  // Insertar compra
  const r = DB.dbRun(
    "INSERT INTO compras (numero, subtotal, impuesto, total, estado, creado_en) VALUES (?,?,0,?,'recibida',?)",
    [numero, subtotal, subtotal, fechaHora]
  );
  const compraId = r.lastId;

  // Insertar detalle
  DB.dbRun(
    "INSERT INTO compras_detalle (compra_id, producto_id, cantidad, precio_unit, subtotal) VALUES (?,?,?,?,?)",
    [compraId, productoId, cantidad, precio, subtotal]
  );

  // Sumar al stock
  const stockAntes   = prod.stock;
  const stockDespues = stockAntes + cantidad;
  DB.dbRun("UPDATE productos SET stock = ? WHERE id = ?", [stockDespues, productoId]);

  // Registrar movimiento
  DB.dbRun(
    "INSERT INTO movimientos (producto_id, tipo, cantidad, stock_antes, stock_despues, referencia, nota, usuario_id) VALUES (?,'entrada',?,?,?,?,'Compra registrada',1)",
    [productoId, cantidad, stockAntes, stockDespues, numero]
  );

  DB.saveDB();

  mostrarMsgC('success',
    '✓ Compra ' + numero + ' registrada — Total: $' + subtotal.toFixed(2) +
    ' · Nuevo stock: ' + stockDespues
  );

  // Resetea form
  
  document.getElementById('c-cantidad').value = '1';
  document.getElementById('c-precio').value   = '';
  document.getElementById('c-preview').textContent = '$0.00';

  recargarBuscadorCompra();
  limpiarProductoCompra();
  renderTablaCompras();

  setTimeout(() => { msgEl.style.display = 'none'; }, 5000);
};

function mostrarMsgC(tipo, texto) {
  const el = document.getElementById('c-msg');
  el.className = 'alert alert-' + (tipo === 'error' ? 'error' : 'success');
  el.textContent = texto;
  el.style.display = 'block';
}

// ============================================================
//  TABLA DE COMPRAS
// ============================================================
function renderTablaCompras() {
  const compras = DB.dbQuery(`
    SELECT c.id, c.numero, c.creado_en, c.estado, c.total,
           cd.cantidad, cd.precio_unit, cd.subtotal,
           p.nombre AS producto_nombre
    FROM compras c
    JOIN compras_detalle cd ON cd.compra_id = c.id
    JOIN productos p ON p.id = cd.producto_id
    ORDER BY c.creado_en DESC
    LIMIT 100
  `);

  const tbody = document.getElementById('c-tbody');
  if (!tbody) return;

  if (!compras.length) {
    tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:var(--text-muted);padding:28px">Sin compras registradas aún</td></tr>';
  } else {
    tbody.innerHTML = compras.map(c => `
      <tr style="${c.estado === 'anulada' ? 'opacity:0.4' : ''}">
        <td style="font-family:var(--font-mono);font-size:11px">${c.numero}</td>
        <td style="font-family:var(--font-mono);font-size:11px">${(c.creado_en || '').substring(0,10)}</td>
        <td>${c.producto_nombre}</td>
        <td style="font-family:var(--font-mono);text-align:center">${c.cantidad}</td>
        <td style="font-family:var(--font-mono)">$${parseFloat(c.precio_unit).toFixed(2)}</td>
        <td style="font-family:var(--font-mono);color:var(--green)">$${parseFloat(c.subtotal).toFixed(2)}</td>
        <td><span class="tag ${c.estado === 'recibida' ? 'tag-green' : 'tag-red'}">${c.estado}</span></td>
        <td>
          ${c.estado === 'recibida'
            ? `<button class="btn btn-danger" style="padding:3px 8px;font-size:11px"
                 onclick="anularCompra(${c.id},'${c.numero}')">Anular</button>`
            : '—'}
        </td>
      </tr>
    `).join('');
  }

  // Total del día
  const hoy = new Date().toISOString().substring(0, 10);
  const hoy_ = compras.filter(c => (c.creado_en || '').startsWith(hoy) && c.estado === 'recibida');
  const totalHoy = hoy_.reduce((s, c) => s + parseFloat(c.subtotal), 0);
  const el = document.getElementById('c-total-hoy');
  if (el && hoy_.length) {
    el.textContent = 'HOY: $' + totalHoy.toFixed(2) + ' (' + hoy_.length + ' compras)';
  }
}

// ============================================================
//  ANULAR COMPRA
// ============================================================
window.anularCompra = function(id, numero) {
  if (!confirm('¿Anular la compra ' + numero + '? El stock será descontado.')) return;

  const det = DB.dbQuery("SELECT * FROM compras_detalle WHERE compra_id = ?", [id]);
  det.forEach(d => {
    const prod    = DB.Productos.getById(d.producto_id);
    const antes   = prod.stock;
    const despues = Math.max(0, antes - d.cantidad);
    DB.dbRun("UPDATE productos SET stock = ? WHERE id = ?", [despues, d.producto_id]);
    DB.dbRun(
      "INSERT INTO movimientos (producto_id, tipo, cantidad, stock_antes, stock_despues, referencia, nota, usuario_id) VALUES (?,'salida',?,?,?,?,'Compra anulada',1)",
      [d.producto_id, -d.cantidad, antes, despues, numero]
    );
  });

  DB.dbRun("UPDATE compras SET estado='anulada' WHERE id=?", [id]);
  DB.saveDB();

  recargarBuscadorCompra();
  limpiarProductoCompra();
  renderTablaCompras();
  showToast('Compra ' + numero + ' anulada — stock ajustado');
};

// ============================================================
//  RESUMEN DEL DÍA
// ============================================================
window.mostrarResumenCompras = function() {
  const hoy = new Date().toISOString().substring(0, 10);
  const compras = DB.dbQuery(`
    SELECT c.numero, c.creado_en,
           cd.cantidad, cd.precio_unit, cd.subtotal,
           p.nombre AS producto_nombre
    FROM compras c
    JOIN compras_detalle cd ON cd.compra_id = c.id
    JOIN productos p ON p.id = cd.producto_id
    WHERE date(c.creado_en) = ? AND c.estado = 'recibida'
    ORDER BY c.creado_en DESC
  `, [hoy]);

  const body = document.getElementById('modal-resumen-compras-body');

  if (!compras.length) {
    body.innerHTML = `<div style="text-align:center;padding:32px;color:var(--text-muted);
      font-family:var(--font-mono)">Sin compras registradas hoy (${hoy})</div>`;
  } else {
    const total = compras.reduce((s, c) => s + parseFloat(c.subtotal), 0);

    // Agrupa por producto
    const agrupado = {};
    compras.forEach(c => {
      if (!agrupado[c.producto_nombre]) agrupado[c.producto_nombre] = { cantidad: 0, total: 0 };
      agrupado[c.producto_nombre].cantidad += c.cantidad;
      agrupado[c.producto_nombre].total    += parseFloat(c.subtotal);
    });

    body.innerHTML = `
      <div id="contenido-resumen-compras">
        <div style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted);
                    margin-bottom:10px;letter-spacing:0.08em">FECHA: ${hoy}</div>

        <table style="width:100%;border-collapse:collapse;margin-bottom:20px">
          <thead>
            <tr style="border-bottom:1px solid var(--border)">
              <th style="text-align:left;padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">PRODUCTO</th>
              <th style="text-align:center;padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">CANTIDAD</th>
              <th style="text-align:right;padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">TOTAL</th>
            </tr>
          </thead>
          <tbody>
            ${Object.entries(agrupado).map(([nombre, d]) => `
              <tr style="border-bottom:1px solid var(--border-light)">
                <td style="padding:10px;color:var(--text-primary);font-size:13px">${nombre}</td>
                <td style="padding:10px;text-align:center;font-family:var(--font-mono)">${d.cantidad}</td>
                <td style="padding:10px;text-align:right;font-family:var(--font-mono);color:var(--green)">$${d.total.toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
          <tfoot>
            <tr style="border-top:2px solid var(--border)">
              <td colspan="2" style="padding:12px 10px;font-family:var(--font-mono);font-weight:600;font-size:14px;color:var(--text-primary)">
                TOTAL INVERTIDO HOY
              </td>
              <td style="padding:12px 10px;text-align:right;font-family:var(--font-mono);font-size:18px;font-weight:600;color:var(--green)">
                $${total.toFixed(2)}
              </td>
            </tr>
          </tfoot>
        </table>

        <div style="font-family:var(--font-mono);font-size:10px;color:var(--text-muted);
                    letter-spacing:0.08em;margin-bottom:8px">DETALLE POR TRANSACCIÓN</div>
        <table style="width:100%;border-collapse:collapse">
          <thead>
            <tr style="border-bottom:1px solid var(--border)">
              <th style="text-align:left;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">N°</th>
              <th style="text-align:left;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">PRODUCTO</th>
              <th style="text-align:center;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">CANT.</th>
              <th style="text-align:right;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">P.UNIT</th>
              <th style="text-align:right;padding:6px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted)">SUBTOTAL</th>
            </tr>
          </thead>
          <tbody>
            ${compras.map(c => `
              <tr style="border-bottom:1px solid var(--border-light)">
                <td style="padding:7px 10px;font-family:var(--font-mono);font-size:11px;color:var(--text-muted)">${c.numero}</td>
                <td style="padding:7px 10px;font-size:13px">${c.producto_nombre}</td>
                <td style="padding:7px 10px;text-align:center;font-family:var(--font-mono)">${c.cantidad}</td>
                <td style="padding:7px 10px;text-align:right;font-family:var(--font-mono)">$${parseFloat(c.precio_unit).toFixed(2)}</td>
                <td style="padding:7px 10px;text-align:right;font-family:var(--font-mono);color:var(--green)">$${parseFloat(c.subtotal).toFixed(2)}</td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>
    `;
  }

  document.getElementById('modal-resumen-compras').style.display = 'flex';
};

// ============================================================
//  IMPRIMIR RESUMEN
// ============================================================
window.imprimirResumenCompras = function() {
  const hoy      = new Date().toISOString().substring(0, 10);
  const empresa  = DB.Config.get('nombre_empresa') || 'Mi Empresa';
  const contenido = document.getElementById('contenido-resumen-compras');
  if (!contenido) return;

  const win = window.open('', '_blank', 'width:500,height:650');
  win.document.write(`<!DOCTYPE html><html><head>
    <meta charset="UTF-8"/>
    <title>Compras ${hoy}</title>
    <style>
      body { font-family:'Courier New',monospace; font-size:12px; color:#111; padding:24px; max-width:420px; margin:auto }
      h2   { text-align:center; font-size:15px; margin-bottom:4px }
      .sub { text-align:center; color:#666; margin-bottom:16px; font-size:11px }
      table { width:100%; border-collapse:collapse; margin-bottom:16px }
      th  { font-size:10px; color:#666; padding:5px 6px; border-bottom:1px solid #ccc; text-align:left }
      td  { padding:7px 6px; border-bottom:1px solid #eee }
      tfoot td { font-weight:bold; font-size:14px; border-top:2px solid #000; padding-top:10px }
      @media print { button { display:none } }
    </style>
  </head><body>
    <h2>${empresa}</h2>
    <div class="sub">RESUMEN DE COMPRAS — ${hoy}</div>
    ${contenido.innerHTML.replace(/style="[^"]*color:var[^"]*"/g, '').replace(/var\(--[^)]+\)/g, '')}
    <br>
    <div style="text-align:center">
      <button onclick="window.print()" style="padding:8px 20px;cursor:pointer;font-size:13px">🖨 Imprimir / Guardar PDF</button>
    </div>
  </body></html>`);
  win.document.close();
};
