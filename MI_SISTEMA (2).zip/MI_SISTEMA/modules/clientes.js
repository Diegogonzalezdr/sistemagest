/**
 * clientes.js — Módulo completo de Clientes
 */

// ============================================================
//  VISTA
// ============================================================
window.viewClientes = function() {
  return `
    <div class="page-header">
      <div>
        <div class="page-title">Clientes</div>
        <div class="page-subtitle">Base de clientes registrados</div>
      </div>
      <button class="btn btn-primary" onclick="abrirModalCliente()">+ Nuevo Cliente</button>
    </div>

    <!-- BUSCADOR -->
    <div style="margin-bottom:16px">
      <input class="form-input" id="cli-buscar" placeholder="Buscar por nombre, email o RUC/NIT/Cédula..."
        style="max-width:420px" oninput="filtrarClientes(this.value)" />
    </div>

    <!-- TABLA -->
    <div class="table-container">
      <div class="table-header">
        <span class="table-title">CLIENTES</span>
        <span id="cli-count" style="font-family:var(--font-mono);font-size:12px;color:var(--text-muted)"></span>
      </div>
      <table>
        <thead>
          <tr>
            <th>Nombre</th>
            <th>Teléfono</th>
            <th>Email</th>
            <th>Dirección</th>
            <th>RUC / NIT / Cédula</th>
            <th>Acciones</th>
          </tr>
        </thead>
        <tbody id="cli-tbody"></tbody>
      </table>
    </div>

    <!-- MODAL FORMULARIO -->
    <div id="modal-cli" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.75);
         z-index:500;align-items:center;justify-content:center">
      <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                  width:500px;max-width:95vw;max-height:90vh;overflow-y:auto">
        <div style="display:flex;justify-content:space-between;align-items:center;
                    padding:16px 20px;border-bottom:1px solid var(--border)">
          <span style="font-family:var(--font-mono);font-weight:600" id="modal-cli-title">Nuevo Cliente</span>
          <button onclick="cerrarModalCliente()" style="background:none;border:none;
            color:var(--text-muted);font-size:20px;cursor:pointer">×</button>
        </div>
        <div style="padding:20px;display:flex;flex-direction:column;gap:14px">
          <input type="hidden" id="cli-id" />
          <div class="form-group" style="margin:0">
            <label class="form-label">Nombre *</label>
            <input class="form-input" id="cli-nombre" placeholder="Nombre completo" />
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Teléfono</label>
              <input class="form-input" id="cli-telefono" placeholder="Ej: 3001234567" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Email</label>
              <input class="form-input" id="cli-email" placeholder="correo@ejemplo.com" />
            </div>
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Dirección</label>
            <input class="form-input" id="cli-direccion" placeholder="Calle, ciudad" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">RUC / NIT / Cédula</label>
            <input class="form-input" id="cli-ruc" placeholder="Documento de identidad" />
          </div>
          <div id="cli-msg" style="display:none" class="alert"></div>
        </div>
        <div style="padding:14px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-outline" onclick="cerrarModalCliente()">Cancelar</button>
          <button class="btn btn-primary" onclick="guardarCliente()">Guardar</button>
        </div>
      </div>
    </div>

    <!-- MODAL HISTORIAL -->
    <div id="modal-cli-historial" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.75);
         z-index:500;align-items:center;justify-content:center">
      <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                  width:620px;max-width:95vw;max-height:85vh;overflow-y:auto">
        <div style="display:flex;justify-content:space-between;align-items:center;
                    padding:16px 20px;border-bottom:1px solid var(--border)">
          <span style="font-family:var(--font-mono);font-weight:600" id="cli-historial-title">Historial</span>
          <button onclick="document.getElementById('modal-cli-historial').style.display='none'"
            style="background:none;border:none;color:var(--text-muted);font-size:20px;cursor:pointer">×</button>
        </div>
        <div id="cli-historial-body" style="padding:20px"></div>
      </div>
    </div>
  `;
};

// ============================================================
//  CONTROLADOR
// ============================================================
window.initClientes = function() {
  renderTablaClientes();
};

function renderTablaClientes(filtro) {
  let clientes = DB.Clientes.getAll();
  if (filtro) {
    const q = filtro.toLowerCase();
    clientes = clientes.filter(c =>
      c.nombre.toLowerCase().includes(q) ||
      (c.email   || '').toLowerCase().includes(q) ||
      (c.ruc_dni || '').toLowerCase().includes(q)
    );
  }

  const tbody = document.getElementById('cli-tbody');
  const count = document.getElementById('cli-count');
  if (!tbody) return;

  if (count) count.textContent = clientes.length + ' registro(s)';

  if (!clientes.length) {
    tbody.innerHTML = '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:28px">Sin clientes registrados</td></tr>';
    return;
  }

  tbody.innerHTML = clientes.map(c => `
    <tr>
      <td style="font-weight:500;color:var(--text-primary)">${c.nombre}</td>
      <td style="font-family:var(--font-mono);font-size:12px">${c.telefono || '—'}</td>
      <td style="font-size:12px">${c.email || '—'}</td>
      <td style="font-size:12px;color:var(--text-secondary)">${c.direccion || '—'}</td>
      <td style="font-family:var(--font-mono);font-size:12px">${c.ruc_dni || '—'}</td>
      <td>
        <div style="display:flex;gap:6px">
          <button class="btn btn-outline" style="padding:3px 8px;font-size:11px"
            onclick="verHistorialCliente(${c.id},'${c.nombre.replace(/'/g,"\\'")}')">Historial</button>
          <button class="btn btn-outline" style="padding:3px 8px;font-size:11px"
            onclick="editarCliente(${c.id})">Editar</button>
          <button class="btn btn-danger" style="padding:3px 8px;font-size:11px"
            onclick="eliminarCliente(${c.id},'${c.nombre.replace(/'/g,"\\'")}')">×</button>
        </div>
      </td>
    </tr>
  `).join('');
}

window.filtrarClientes = function(val) {
  renderTablaClientes(val);
};

// ── MODAL FORMULARIO ──
window.abrirModalCliente = function(id) {
  document.getElementById('cli-id').value       = '';
  document.getElementById('cli-nombre').value   = '';
  document.getElementById('cli-telefono').value = '';
  document.getElementById('cli-email').value    = '';
  document.getElementById('cli-direccion').value= '';
  document.getElementById('cli-ruc').value      = '';
  document.getElementById('cli-msg').style.display = 'none';
  document.getElementById('modal-cli-title').textContent = 'Nuevo Cliente';
  document.getElementById('modal-cli').style.display = 'flex';
};

window.cerrarModalCliente = function() {
  document.getElementById('modal-cli').style.display = 'none';
};

window.editarCliente = function(id) {
  const c = DB.Clientes.getById(id);
  if (!c) return;
  document.getElementById('cli-id').value        = c.id;
  document.getElementById('cli-nombre').value    = c.nombre;
  document.getElementById('cli-telefono').value  = c.telefono  || '';
  document.getElementById('cli-email').value     = c.email     || '';
  document.getElementById('cli-direccion').value = c.direccion || '';
  document.getElementById('cli-ruc').value       = c.ruc_dni   || '';
  document.getElementById('cli-msg').style.display = 'none';
  document.getElementById('modal-cli-title').textContent = 'Editar Cliente';
  document.getElementById('modal-cli').style.display = 'flex';
};

window.guardarCliente = function() {
  const msgEl = document.getElementById('cli-msg');
  msgEl.style.display = 'none';

  const id      = document.getElementById('cli-id').value;
  const nombre  = document.getElementById('cli-nombre').value.trim();
  const telefono= document.getElementById('cli-telefono').value.trim();
  const email   = document.getElementById('cli-email').value.trim();
  const dir     = document.getElementById('cli-direccion').value.trim();
  const ruc     = document.getElementById('cli-ruc').value.trim();

  if (!nombre) {
    msgEl.className = 'alert alert-error';
    msgEl.textContent = 'El nombre es obligatorio.';
    msgEl.style.display = 'block';
    return;
  }

  if (id) {
    DB.dbRun(
      "UPDATE clientes SET nombre=?,telefono=?,email=?,direccion=?,ruc_dni=? WHERE id=?",
      [nombre, telefono, email, dir, ruc, id]
    );
    DB.saveDB();
    showToast('Cliente actualizado');
  } else {
    DB.Clientes.create({ nombre, telefono, email, direccion: dir, ruc_dni: ruc });
    showToast('Cliente registrado');
  }

  cerrarModalCliente();
  renderTablaClientes();
};

window.eliminarCliente = function(id, nombre) {
  if (!confirm('¿Eliminar al cliente "' + nombre + '"?')) return;
  DB.Clientes.delete(id);
  renderTablaClientes();
  showToast('Cliente eliminado');
};

// ── HISTORIAL ──
window.verHistorialCliente = function(id, nombre) {
  const ventas = DB.dbQuery(`
    SELECT v.numero, v.creado_en, v.total, v.estado,
           p.nombre AS producto_nombre, vd.cantidad, vd.precio_unit, vd.subtotal
    FROM ventas v
    JOIN ventas_detalle vd ON vd.venta_id = v.id
    JOIN productos p ON p.id = vd.producto_id
    WHERE v.cliente_id = ? AND v.estado = 'completada'
    ORDER BY v.creado_en DESC
  `, [id]);

  document.getElementById('cli-historial-title').textContent = 'Historial de ventas — ' + nombre;

  const body = document.getElementById('cli-historial-body');

  if (!ventas.length) {
    body.innerHTML = `<div style="text-align:center;padding:32px;color:var(--text-muted);
      font-family:var(--font-mono)">Este cliente no tiene ventas registradas</div>`;
  } else {
    const total = ventas.reduce((s, v) => s + parseFloat(v.subtotal), 0);
    body.innerHTML = `
      <table style="width:100%;border-collapse:collapse">
        <thead>
          <tr style="border-bottom:1px solid var(--border)">
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:left">N°</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:left">FECHA</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:left">PRODUCTO</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:center">CANT.</th>
            <th style="padding:8px 10px;font-family:var(--font-mono);font-size:10px;color:var(--text-muted);text-align:right">TOTAL</th>
          </tr>
        </thead>
        <tbody>
          ${ventas.map(v => `
            <tr style="border-bottom:1px solid var(--border-light)">
              <td style="padding:9px 10px;font-family:var(--font-mono);font-size:11px;color:var(--text-muted)">${v.numero}</td>
              <td style="padding:9px 10px;font-family:var(--font-mono);font-size:11px">${(v.creado_en||'').substring(0,10)}</td>
              <td style="padding:9px 10px;font-size:13px">${v.producto_nombre}</td>
              <td style="padding:9px 10px;font-family:var(--font-mono);text-align:center">${v.cantidad}</td>
              <td style="padding:9px 10px;font-family:var(--font-mono);text-align:right;color:var(--accent)">$${parseFloat(v.subtotal).toFixed(2)}</td>
            </tr>
          `).join('')}
        </tbody>
        <tfoot>
          <tr style="border-top:2px solid var(--border)">
            <td colspan="4" style="padding:12px 10px;font-family:var(--font-mono);font-weight:600;color:var(--text-primary)">TOTAL COMPRADO</td>
            <td style="padding:12px 10px;text-align:right;font-family:var(--font-mono);font-size:16px;font-weight:600;color:var(--accent)">$${total.toFixed(2)}</td>
          </tr>
        </tfoot>
      </table>`;
  }

  document.getElementById('modal-cli-historial').style.display = 'flex';
};
