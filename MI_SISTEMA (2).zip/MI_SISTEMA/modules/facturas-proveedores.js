/**
 * facturas-proveedores.js — Gestión de facturas recibidas de proveedores
 * - Carpetas por proveedor
 * - Cargar PDF con extracción automática
 * - Sistema de abonos parciales con barra de progreso
 * - Estado de pago (pendiente / pagada)
 * - Reporte diario de abonos en Dashboard
 * - Notificaciones de vencimiento
 * - Buscador por empresa o número de factura
 */

// ============================================================
//  SCHEMA
// ============================================================
function initFacturasProveedoresDB() {
  try { DB.dbRun("ALTER TABLE proveedores ADD COLUMN tiene_facturas INTEGER DEFAULT 0"); } catch(e) {}

  DB.dbRun(`CREATE TABLE IF NOT EXISTS facturas_proveedores (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    proveedor_id      INTEGER NOT NULL,
    numero_factura    TEXT,
    fecha_expedicion  TEXT,
    fecha_vencimiento TEXT,
    total             REAL DEFAULT 0,
    abonado           REAL DEFAULT 0,
    estado            TEXT DEFAULT 'pendiente',
    pdf_nombre        TEXT,
    pdf_data          TEXT,
    notas             TEXT,
    creado_en         TEXT DEFAULT (datetime('now'))
  )`);

  // Migración para BDs ya existentes
  try { DB.dbRun("ALTER TABLE facturas_proveedores ADD COLUMN abonado REAL DEFAULT 0"); } catch(e) {}

  DB.dbRun(`CREATE TABLE IF NOT EXISTS abonos_proveedores (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    factura_id   INTEGER NOT NULL,
    proveedor_id INTEGER NOT NULL,
    monto        REAL    NOT NULL,
    nota         TEXT,
    fecha        TEXT    NOT NULL DEFAULT (date('now')),
    creado_en    TEXT    NOT NULL DEFAULT (datetime('now'))
  )`);

  DB.saveDB();
}

// ============================================================
//  ESTADO DE NAVEGACIÓN
// ============================================================
let fpEstado = { vista:'lista', proveedorId:null, proveedorNombre:'' };

// ============================================================
//  VISTA PRINCIPAL
// ============================================================
window.viewFacturasProveedores = function() {
  return `
    <div id="fp-root"></div>
    <div id="fp-modal-overlay" style="display:none;position:fixed;inset:0;
         background:rgba(0,0,0,0.8);z-index:700;align-items:center;justify-content:center">
      <div id="fp-modal-box" style="background:var(--bg-surface);border:1px solid var(--border);
           border-radius:6px;width:520px;max-width:96vw;max-height:88vh;overflow-y:auto"></div>
    </div>`;
};

window.initFacturasProveedores = function() {
  initFacturasProveedoresDB();
  fpEstado = { vista:'lista', proveedorId:null, proveedorNombre:'' };
  fpRenderLista();
  verificarVencimientosProveedores();
};

// ============================================================
//  VISTA 1 — LISTA DE CARPETAS
// ============================================================
function fpRenderLista(filtro='') {
  fpEstado.vista = 'lista';
  const root = document.getElementById('fp-root');
  if (!root) return;

  // Construye el HTML estático solo la primera vez
  if (!document.getElementById('fp-carpetas-grid')) {
    root.innerHTML = `
      <div class="page-header">
        <div>
          <div class="page-title">Facturas de Proveedores</div>
          <div class="page-subtitle">Carpetas organizadas por proveedor</div>
        </div>
      </div>
      <div style="margin-bottom:20px;max-width:420px">
        <input class="form-input" id="fp-buscar"
          placeholder="Buscar por empresa o número de factura..."
          oninput="fpFiltrarCarpetas(this.value)" />
      </div>
      <div id="fp-carpetas-grid" style="display:grid;
           grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:16px">
      </div>`;
  }
  fpFiltrarCarpetas(filtro);
}

window.fpFiltrarCarpetas = function(filtro='') {
  let proveedores = DB.Proveedores.getAll();
  if (filtro) {
    const q = filtro.toLowerCase();
    try {
      const provIds = DB.dbQuery(
        "SELECT DISTINCT proveedor_id FROM facturas_proveedores WHERE LOWER(numero_factura) LIKE ?",
        ['%'+q+'%']
      ).map(r => r.proveedor_id);
      proveedores = proveedores.filter(p =>
        p.nombre.toLowerCase().includes(q) || provIds.includes(p.id)
      );
    } catch(e) {
      proveedores = proveedores.filter(p => p.nombre.toLowerCase().includes(q));
    }
  }

  const grid = document.getElementById('fp-carpetas-grid');
  if (!grid) return;
  grid.innerHTML = proveedores.length ? proveedores.map(p => {
        const facturas   = DB.dbQuery("SELECT * FROM facturas_proveedores WHERE proveedor_id=?",[p.id]);
        const pendientes = facturas.filter(f => f.estado==='pendiente');
        const totalPend  = pendientes.reduce((s,f) => {
          const total   = parseFloat(f.total||0);
          const abonado = parseFloat(f.abonado||0);
          return s + Math.max(0, total - abonado);
        }, 0);

        return `
          <div onclick="fpAbrirCarpeta(${p.id},'${p.nombre.replace(/'/g,"\\'")}')"
            style="background:var(--bg-surface);border:1px solid ${pendientes.length>0?'var(--yellow)':'var(--border)'};
                   border-radius:6px;padding:20px;cursor:pointer;transition:all 0.15s"
            onmouseenter="this.style.borderColor='var(--accent)';this.style.transform='translateY(-2px)'"
            onmouseleave="this.style.borderColor='${pendientes.length>0?'var(--yellow)':'var(--border)'}';this.style.transform=''">
            <div style="font-size:32px;margin-bottom:10px">📁</div>
            <div style="font-weight:600;font-size:13px;color:var(--text-primary);
                        margin-bottom:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${p.nombre}</div>
            <div style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted)">
              ${facturas.length} factura${facturas.length!==1?'s':''}
            </div>
            ${pendientes.length>0 ? `
              <div style="margin-top:8px;padding:4px 8px;background:rgba(255,204,68,0.1);
                          border-radius:3px;font-size:11px;color:var(--yellow);font-family:var(--font-mono)">
                ⚠ Saldo: $${totalPend.toLocaleString('es-CO')}
              </div>` : facturas.length>0 ? `
              <div style="margin-top:8px;padding:4px 8px;background:rgba(61,220,132,0.08);
                          border-radius:3px;font-size:11px;color:var(--green);font-family:var(--font-mono)">✓ Al día</div>` : ''}
          </div>`;
      }).join('') : `
        <div style="grid-column:1/-1;text-align:center;padding:48px;
                    color:var(--text-muted);font-family:var(--font-mono)">
          No hay proveedores registrados.
        </div>`;
};

// ============================================================
//  VISTA 2 — CARPETA DE UN PROVEEDOR (ventana nueva)
// ============================================================
window.fpAbrirCarpeta = function(proveedorId, nombre) {
  fpEstado = { vista:'carpeta', proveedorId, proveedorNombre: nombre };

  // Elimina ventana previa si existe
  const prev = document.getElementById('fp-ventana-carpeta');
  if (prev) prev.remove();

  const overlay = document.createElement('div');
  overlay.id = 'fp-ventana-carpeta';
  overlay.style.cssText = `position:fixed;inset:0;background:var(--bg-base);z-index:400;
    display:flex;flex-direction:column;animation:slideInFP 0.22s ease`;

  const styleEl = document.createElement('style');
  styleEl.textContent = `@keyframes slideInFP{from{transform:translateX(50px);opacity:0}to{transform:translateX(0);opacity:1}}`;
  document.head.appendChild(styleEl);

  overlay.innerHTML = `
    <div style="height:52px;background:var(--bg-surface);border-bottom:1px solid var(--border);
                display:flex;align-items:center;padding:0 20px;gap:14px;flex-shrink:0">
      <button onclick="fpCerrarVentana()" style="background:var(--bg-elevated);border:1px solid var(--border);
              color:var(--text-secondary);width:32px;height:32px;border-radius:4px;cursor:pointer;
              font-size:18px;display:flex;align-items:center;justify-content:center">←</button>
      <div style="font-family:var(--font-mono);font-size:13px;color:var(--text-muted)">
        Facturas Recibidas /
        <span style="color:var(--text-primary);margin-left:4px">${nombre}</span>
      </div>
    </div>
    <div style="flex:1;overflow-y:auto;padding:24px" id="fp-ventana-contenido"></div>`;

  document.body.appendChild(overlay);
  fpRenderContenidoCarpeta(proveedorId, nombre);
};

function fpRenderContenidoCarpeta(proveedorId, nombre) {
  const facturas  = DB.dbQuery(
    "SELECT * FROM facturas_proveedores WHERE proveedor_id=? ORDER BY creado_en DESC",
    [proveedorId]
  );
  const contenido = document.getElementById('fp-ventana-contenido');
  if (!contenido) return;

  const totalSaldo = facturas.filter(f=>f.estado==='pendiente')
    .reduce((s,f) => s + Math.max(0, parseFloat(f.total||0) - parseFloat(f.abonado||0)), 0);

  contenido.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:20px;flex-wrap:wrap;gap:12px">
      <div>
        <div style="font-size:20px;font-weight:600;color:var(--text-primary)">${nombre}</div>
        <div style="font-size:13px;color:var(--text-muted);margin-top:4px">
          ${facturas.length} factura${facturas.length!==1?'s':''} ·
          ${totalSaldo>0
            ? `<span style="color:var(--yellow)">⚠ Saldo pendiente: $${totalSaldo.toLocaleString('es-CO')}</span>`
            : '<span style="color:var(--green)">✓ Sin saldos pendientes</span>'}
        </div>
      </div>
      <button class="btn btn-primary" onclick="fpCargarPDF(${proveedorId},'${nombre.replace(/'/g,"\\'")}')" id="btn-cargar-pdf">
        + Cargar factura PDF
      </button>
    </div>
    <div style="margin-bottom:16px;max-width:380px">
      <input class="form-input" placeholder="Buscar por N° factura..."
        oninput="fpFiltrarFacturasEnCarpeta(this.value,${proveedorId},'${nombre.replace(/'/g,"\\'")}')"/>
    </div>
    ${facturas.length ? `
      <div style="display:flex;flex-direction:column;gap:12px" id="fp-lista-facturas-carpeta">
        ${fpHtmlFacturas(facturas, proveedorId, nombre)}
      </div>` : `
      <div style="text-align:center;padding:60px;color:var(--text-muted);font-family:var(--font-mono)">
        <div style="font-size:40px;margin-bottom:12px">📭</div>
        <div>No hay facturas. Carga un PDF con el botón de arriba.</div>
      </div>`}`;
}

// ============================================================
//  HTML DE CADA FACTURA CON ABONOS
// ============================================================
function fpHtmlFacturas(facturas, proveedorId, nombre) {
  return facturas.map(f => {
    const vence   = f.fecha_vencimiento ? diasHastaFP(f.fecha_vencimiento) : null;
    const estV    = fpEstadoVencimiento(f.fecha_vencimiento, f.estado);
    const total   = parseFloat(f.total   || 0);
    const abonado = parseFloat(f.abonado || 0);
    const saldo   = Math.max(0, total - abonado);
    const pct     = total > 0 ? Math.min(100, Math.round((abonado/total)*100)) : 0;

    let abonos = [];
    try { abonos = DB.dbQuery("SELECT * FROM abonos_proveedores WHERE factura_id=? ORDER BY fecha DESC",[f.id]); } catch(e){}

    const nomb = nombre.replace(/'/g,"\\'");
    const nfac = (f.numero_factura||'Sin número').replace(/'/g,"\\'");

    return `
      <div style="background:var(--bg-surface);border:1px solid ${estV.border};
                  border-radius:6px;padding:18px 20px">

        <!-- Cabecera -->
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px;flex-wrap:wrap;gap:8px">
          <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
            <span style="font-size:20px">🧾</span>
            <span style="font-family:var(--font-mono);font-size:14px;font-weight:700;
                         color:var(--text-primary)">${f.numero_factura || 'Sin número'}</span>
            <span class="tag ${f.estado==='pagada'?'tag-green':'tag-yellow'}">
              ${f.estado==='pagada'?'PAGADA':'PENDIENTE'}
            </span>
            ${abonado>0 && f.estado!=='pagada' ? `<span class="tag tag-blue" style="font-size:10px">ABONO PARCIAL</span>` : ''}
          </div>
          <!-- Botones -->
          <div style="display:flex;gap:6px;flex-wrap:wrap">
            ${f.pdf_data ? `
              <button class="btn btn-outline" style="padding:4px 10px;font-size:11px"
                onclick="fpDescargarPDF(${f.id})">⬇ PDF</button>` : ''}
            ${f.estado==='pendiente' ? `
              <button class="btn btn-outline" style="padding:5px 12px;font-size:12px;
                      color:var(--green);border-color:var(--green);font-weight:600"
                onclick="fpAbrirModalAbono(${f.id},'${nfac}',${saldo},${proveedorId},'${nomb}')">
                💰 Abonar
              </button>
              <button class="btn btn-outline" style="padding:5px 10px;font-size:11px;
                      color:var(--green);border-color:var(--green)"
                onclick="fpMarcarPagada(${f.id},${proveedorId},'${nomb}')">✓ Pago total</button>` : ''}
            <button class="btn btn-danger" style="padding:4px 10px;font-size:11px"
              onclick="fpEliminarFactura(${f.id},${proveedorId},'${nomb}')">×</button>
          </div>
        </div>

        <!-- Fechas -->
        <div style="display:flex;gap:16px;font-size:12px;color:var(--text-secondary);flex-wrap:wrap;margin-bottom:12px">
          ${f.fecha_expedicion ? `<span>📅 Expedición: ${f.fecha_expedicion}</span>` : ''}
          ${f.fecha_vencimiento ? `
            <span style="color:${estV.color}">
              ${estV.icono} Vence: ${f.fecha_vencimiento}
              ${vence!==null ? `(${vence>=0?'en '+vence+' días':'hace '+Math.abs(vence)+' días'})` : ''}
            </span>` : ''}
          ${f.pdf_nombre ? `<span style="color:var(--text-muted)">📎 ${f.pdf_nombre}</span>` : ''}
        </div>

        <!-- Barra de pago -->
        ${total>0 ? `
          <div style="margin-bottom:10px">
            <div style="display:flex;justify-content:space-between;margin-bottom:4px">
              <span style="font-size:12px;color:var(--text-muted)">Total factura</span>
              <span style="font-family:var(--font-mono);font-size:13px;color:var(--accent);font-weight:600">
                $${total.toLocaleString('es-CO')}
              </span>
            </div>
            ${abonado>0 ? `
              <div style="display:flex;justify-content:space-between;margin-bottom:4px">
                <span style="font-size:12px;color:var(--text-muted)">Total abonado</span>
                <span style="font-family:var(--font-mono);font-size:13px;color:var(--green)">
                  $${abonado.toLocaleString('es-CO')}
                </span>
              </div>` : ''}
            <div style="display:flex;justify-content:space-between;margin-bottom:6px">
              <span style="font-size:12px;color:var(--text-muted);font-weight:600">Saldo pendiente</span>
              <span style="font-family:var(--font-mono);font-size:14px;
                           color:${saldo>0?'var(--red)':'var(--green)'};font-weight:700">
                $${saldo.toLocaleString('es-CO')}
              </span>
            </div>
            <div style="height:7px;background:var(--bg-elevated);border-radius:4px;overflow:hidden">
              <div style="height:100%;width:${pct}%;
                          background:${pct>=100?'var(--green)':'var(--accent)'};
                          border-radius:4px;transition:width 0.5s ease"></div>
            </div>
            <div style="font-size:10px;color:var(--text-muted);margin-top:3px;
                        text-align:right;font-family:var(--font-mono)">${pct}% pagado</div>
          </div>` : ''}

        <!-- Historial de abonos -->
        ${abonos.length>0 ? `
          <details style="margin-top:4px">
            <summary style="font-size:11px;color:var(--text-muted);cursor:pointer;
                            font-family:var(--font-mono);letter-spacing:0.06em;user-select:none">
              📋 VER HISTORIAL DE ABONOS (${abonos.length})
            </summary>
            <div style="margin-top:8px;display:flex;flex-direction:column;gap:4px">
              ${abonos.map(a=>`
                <div style="display:flex;justify-content:space-between;padding:7px 12px;
                            background:var(--bg-elevated);border-radius:4px;font-size:12px;
                            border-left:3px solid var(--green)">
                  <span style="color:var(--text-secondary)">${a.fecha}${a.nota?' — '+a.nota:''}</span>
                  <span style="font-family:var(--font-mono);color:var(--green);font-weight:600">
                    +$${parseFloat(a.monto).toLocaleString('es-CO')}
                  </span>
                </div>`).join('')}
            </div>
          </details>` : ''}
      </div>`;
  }).join('');
}

// ============================================================
//  MODAL DE ABONO
// ============================================================
window.fpAbrirModalAbono = function(facturaId, numFactura, saldo, proveedorId, nombreProv) {
  const overlay = document.getElementById('fp-modal-overlay');
  const box     = document.getElementById('fp-modal-box');
  if (!overlay || !box) return;

  box.innerHTML = `
    <div style="padding:16px 20px;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <span style="font-family:var(--font-mono);font-weight:600;font-size:14px">
        💰 Registrar abono
      </span>
      <button onclick="fpCerrarModal()"
        style="background:none;border:none;color:var(--text-muted);font-size:20px;cursor:pointer">×</button>
    </div>
    <div style="padding:20px;display:flex;flex-direction:column;gap:14px">

      <!-- Info factura -->
      <div style="background:var(--bg-elevated);border-radius:4px;padding:12px 14px">
        <div style="font-size:10px;font-family:var(--font-mono);color:var(--text-muted);
                    letter-spacing:0.1em;margin-bottom:6px">FACTURA A ABONAR</div>
        <div style="font-family:var(--font-mono);font-size:14px;color:var(--accent);
                    font-weight:600;margin-bottom:2px">${numFactura}</div>
        <div style="font-size:12px;color:var(--text-muted)">Proveedor: ${nombreProv}</div>
        <div style="margin-top:8px;padding-top:8px;border-top:1px solid var(--border);
                    display:flex;justify-content:space-between;align-items:center">
          <span style="font-size:12px;color:var(--text-muted)">Saldo pendiente</span>
          <span style="font-family:var(--font-mono);font-size:16px;color:var(--red);font-weight:700">
            $${parseFloat(saldo).toLocaleString('es-CO')}
          </span>
        </div>
      </div>

      <div class="form-group" style="margin:0">
        <label class="form-label">Monto del abono *</label>
        <input class="form-input" type="number" id="abono-monto"
          min="1" max="${saldo}" step="1" placeholder="0"
          style="font-family:var(--font-mono);font-size:16px"/>
        <div style="font-size:11px;color:var(--text-muted);margin-top:4px">
          Máximo: $${parseFloat(saldo).toLocaleString('es-CO')}
        </div>
      </div>

      <div class="form-group" style="margin:0">
        <label class="form-label">Fecha del abono *</label>
        <input class="form-input" type="date" id="abono-fecha"
          value="${new Date().toISOString().substring(0,10)}" />
      </div>

      <div class="form-group" style="margin:0">
        <label class="form-label">Nota (opcional)</label>
        <input class="form-input" id="abono-nota"
          placeholder="Ej: Transferencia bancaria, efectivo..." />
      </div>

      <div id="abono-msg" style="display:none" class="alert"></div>
    </div>

    <div style="padding:14px 20px;border-top:1px solid var(--border);
                display:flex;justify-content:flex-end;gap:8px">
      <button class="btn btn-outline" onclick="fpCerrarModal()">Cancelar</button>
      <button class="btn btn-primary"
        style="background:rgba(61,220,132,0.15);border:1px solid var(--green);color:var(--green);font-weight:600"
        onclick="fpGuardarAbono(${facturaId},${saldo},${proveedorId},'${nombreProv.replace(/'/g,"\\'")}')">
        💰 Guardar abono
      </button>
    </div>`;

  overlay.style.display = 'flex';
  setTimeout(() => document.getElementById('abono-monto')?.focus(), 80);
};

// ============================================================
//  GUARDAR ABONO
// ============================================================
window.fpGuardarAbono = function(facturaId, saldo, proveedorId, nombreProv) {
  const monto = parseFloat(document.getElementById('abono-monto').value) || 0;
  const fecha = document.getElementById('abono-fecha').value;
  const nota  = document.getElementById('abono-nota').value.trim();
  const msgEl = document.getElementById('abono-msg');

  const err = (t) => { msgEl.className='alert alert-error'; msgEl.textContent=t; msgEl.style.display='block'; };

  if (!monto || monto <= 0)    { err('El monto debe ser mayor a 0.'); return; }
  if (monto > saldo + 0.01)   { err(`No puede superar el saldo ($${saldo.toLocaleString('es-CO')}).`); return; }
  if (!fecha)                  { err('Selecciona una fecha.'); return; }

  const factura = DB.dbGet("SELECT * FROM facturas_proveedores WHERE id=?", [facturaId]);
  if (!factura) { err('Factura no encontrada.'); return; }

  const nuevoAbonado = parseFloat(factura.abonado||0) + monto;
  const total        = parseFloat(factura.total||0);
  const nuevoEstado  = nuevoAbonado >= total - 0.01 ? 'pagada' : 'pendiente';

  // Guardar abono
  DB.dbRun(
    "INSERT INTO abonos_proveedores (factura_id, proveedor_id, monto, nota, fecha) VALUES (?,?,?,?,?)",
    [facturaId, proveedorId, monto, nota, fecha]
  );

  // Actualizar factura
  DB.dbRun(
    "UPDATE facturas_proveedores SET abonado=?, estado=? WHERE id=?",
    [nuevoAbonado, nuevoEstado, facturaId]
  );

  // Notificación
  const provNom = DB.dbGet("SELECT nombre FROM proveedores WHERE id=?", [proveedorId])?.nombre || nombreProv;
  const numFac  = factura.numero_factura || 'sin N°';

  if (nuevoEstado === 'pagada') {
    DB.Notificaciones.create('exito',
      'Factura pagada — ' + provNom,
      `Factura ${numFac} de "${provNom}" saldada en su totalidad. Total: $${total.toLocaleString('es-CO')}`
    );
  } else {
    const saldoRest = total - nuevoAbonado;
    DB.Notificaciones.create('info',
      'Abono registrado — ' + provNom,
      `Abono de $${monto.toLocaleString('es-CO')} a factura ${numFac} de "${provNom}". Saldo restante: $${saldoRest.toLocaleString('es-CO')}`
    );
  }

  DB.saveDB();
  if (typeof updateNotifBadge === 'function') updateNotifBadge();
  fpCerrarModal();
  fpRenderContenidoCarpeta(proveedorId, nombreProv);

  if (typeof showToast === 'function')
    showToast(nuevoEstado==='pagada'
      ? '✓ Factura saldada en su totalidad'
      : `✓ Abono de $${monto.toLocaleString('es-CO')} registrado`);
};

// ============================================================
//  CARGAR PDF
// ============================================================
window.fpCargarPDF = function(proveedorId, nombre) {
  const input = document.createElement('input');
  input.type = 'file';
  input.accept = '.pdf';
  input.onchange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const btn = document.getElementById('btn-cargar-pdf');
    if (btn) { btn.textContent = '⏳ Analizando...'; btn.disabled = true; }
    try {
      const base64 = await fileToBase64(file);
      const texto  = await extraerTextoPDFfp(file);
      const datos  = extraerDatosFactura(texto);
      fpMostrarModalConfirmar(proveedorId, nombre, file.name, base64, datos);
    } catch(err) {
      if (typeof showToast === 'function') showToast('Error al leer el PDF: ' + err.message);
    } finally {
      if (btn) { btn.textContent = '+ Cargar factura PDF'; btn.disabled = false; }
    }
  };
  input.click();
};

function fileToBase64(file) {
  return new Promise((res, rej) => {
    const reader = new FileReader();
    reader.onload  = e => res(e.target.result.split(',')[1]);
    reader.onerror = () => rej(new Error('No se pudo leer el archivo'));
    reader.readAsDataURL(file);
  });
}

async function cargarPDFjsFP() {
  if (window.pdfjsLib) return;
  await new Promise((res, rej) => {
    const s = document.createElement('script');
    s.src = window._pdfJsUrl || 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
    s.onload = () => {
      pdfjsLib.GlobalWorkerOptions.workerSrc =
        window._pdfJsWorker || 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';
      res();
    };
    s.onerror = rej;
    document.head.appendChild(s);
  });
}

async function extraerTextoPDFfp(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        await cargarPDFjsFP();
        if (window.pdfjsLib) {
          const pdf = await pdfjsLib.getDocument({ data: e.target.result }).promise;
          let texto = '';
          for (let i = 1; i <= Math.min(pdf.numPages, 3); i++) {
            const page    = await pdf.getPage(i);
            const content = await page.getTextContent();
            texto += content.items.map(s => s.str).join(' ') + '\n';
          }
          resolve(texto);
        } else resolve('');
      } catch(err) { resolve(''); }
    };
    reader.readAsArrayBuffer(file);
  });
}

function extraerDatosFactura(texto) {
  const datos = {};
  const numMatch = texto.match(/(?:factura|fact|invoice|n[°oO]\.?|N[ÚU]MERO)[:\s#]*([A-Z0-9\-]{3,20})/i);
  if (numMatch) datos.numero = numMatch[1].trim();
  const fechas    = [...texto.matchAll(/(\d{2})[\/\-](\d{2})[\/\-](\d{4})/g)].map(m=>`${m[1]}/${m[2]}/${m[3]}`);
  const fechasISO = [...texto.matchAll(/(\d{4})\-(\d{2})\-(\d{2})/g)].map(m=>`${m[3]}/${m[2]}/${m[1]}`);
  const todas = [...fechas, ...fechasISO];
  if (todas[0]) datos.fecha_expedicion  = todas[0];
  if (todas[1]) datos.fecha_vencimiento = todas[1];
  const totMatch = texto.match(/(?:total|valor total|grand total)[:\s$]*\$?\s*([\d\.,]+)/i);
  if (totMatch) datos.total = parseFloat(totMatch[1].replace(/\./g,'').replace(',','.')) || 0;
  return datos;
}

function fpMostrarModalConfirmar(proveedorId, nombre, pdfNombre, pdfBase64, datos) {
  const overlay = document.getElementById('fp-modal-overlay');
  const box     = document.getElementById('fp-modal-box');
  if (!overlay || !box) return;
  window._fpPdfTmp = pdfBase64;

  box.innerHTML = `
    <div style="padding:16px 20px;border-bottom:1px solid var(--border);
                display:flex;justify-content:space-between;align-items:center">
      <span style="font-family:var(--font-mono);font-weight:600">📎 Confirmar datos extraídos</span>
      <button onclick="fpCerrarModal()"
        style="background:none;border:none;color:var(--text-muted);font-size:20px;cursor:pointer">×</button>
    </div>
    <div style="padding:20px;display:flex;flex-direction:column;gap:14px">
      ${Object.keys(datos).length>0
        ? `<div class="alert alert-success" style="font-size:12px">✓ ${Object.keys(datos).length} campo(s) extraídos automáticamente. Verifica antes de guardar.</div>`
        : `<div class="alert alert-info" style="font-size:12px">ℹ No se pudo extraer texto del PDF. Ingresa los datos manualmente.</div>`}
      <div style="background:var(--bg-elevated);border-radius:4px;padding:8px 12px;
                  font-size:12px;font-family:var(--font-mono);color:var(--text-muted)">📎 ${pdfNombre}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
        <div class="form-group" style="grid-column:1/-1;margin:0">
          <label class="form-label">N° de Factura</label>
          <input class="form-input" id="fp-modal-numero" value="${datos.numero||''}" placeholder="Ej: FV-00123"/>
        </div>
        <div class="form-group" style="margin:0">
          <label class="form-label">Fecha expedición</label>
          <input class="form-input" id="fp-modal-expedicion" value="${datos.fecha_expedicion||''}" placeholder="dd/mm/yyyy"/>
        </div>
        <div class="form-group" style="margin:0">
          <label class="form-label">Fecha vencimiento</label>
          <input class="form-input" id="fp-modal-vencimiento" value="${datos.fecha_vencimiento||''}" placeholder="dd/mm/yyyy"/>
        </div>
        <div class="form-group" style="grid-column:1/-1;margin:0">
          <label class="form-label">Total a pagar</label>
          <input class="form-input" id="fp-modal-total" type="number" value="${datos.total||''}"
            placeholder="0" style="font-family:var(--font-mono)"/>
        </div>
        <div class="form-group" style="grid-column:1/-1;margin:0">
          <label class="form-label">Notas</label>
          <input class="form-input" id="fp-modal-notas" placeholder="Observaciones opcionales"/>
        </div>
      </div>
      <div id="fp-modal-msg" style="display:none" class="alert"></div>
    </div>
    <div style="padding:14px 20px;border-top:1px solid var(--border);display:flex;justify-content:flex-end;gap:8px">
      <button class="btn btn-outline" onclick="fpCerrarModal()">Cancelar</button>
      <button class="btn btn-primary"
        onclick="fpGuardarFactura(${proveedorId},'${nombre.replace(/'/g,"\\'")}','${pdfNombre}')">
        Guardar factura
      </button>
    </div>`;

  overlay.style.display = 'flex';
}

window.fpGuardarFactura = function(proveedorId, nombre, pdfNombre) {
  const numero      = document.getElementById('fp-modal-numero').value.trim();
  const expedicion  = document.getElementById('fp-modal-expedicion').value.trim();
  const vencimiento = document.getElementById('fp-modal-vencimiento').value.trim();
  const total       = parseFloat(document.getElementById('fp-modal-total').value) || 0;
  const notas       = document.getElementById('fp-modal-notas').value.trim();
  const pdfData     = window._fpPdfTmp || '';

  try {
    DB.dbRun(
      `INSERT INTO facturas_proveedores
       (proveedor_id,numero_factura,fecha_expedicion,fecha_vencimiento,total,abonado,estado,pdf_nombre,pdf_data,notas)
       VALUES (?,?,?,?,?,0,'pendiente',?,?,?)`,
      [proveedorId, numero, expedicion, vencimiento, total, pdfNombre, pdfData, notas]
    );
    DB.saveDB();
    if (vencimiento) {
      const dias = diasHastaFP(vencimiento);
      if (dias !== null && dias <= 30) {
        DB.Notificaciones.create('alerta','Factura próxima a vencer',
          `Factura ${numero||'sin N°'} de "${nombre}" vence ${dias>=0?'en '+dias+' días':'hace '+Math.abs(dias)+' días'} — Total: $${total.toLocaleString('es-CO')}`);
        if (typeof updateNotifBadge==='function') updateNotifBadge();
      }
    }
    fpCerrarModal();
    fpRenderContenidoCarpeta(proveedorId, nombre);
    if (typeof showToast==='function') showToast('✓ Factura guardada correctamente');
  } catch(err) {
    const msg = document.getElementById('fp-modal-msg');
    if (msg) { msg.className='alert alert-error'; msg.textContent='Error: '+err.message; msg.style.display='block'; }
  }
};

// ============================================================
//  ACCIONES
// ============================================================
window.fpMarcarPagada = function(id, proveedorId, nombre) {
  if (!confirm('¿Marcar esta factura como totalmente pagada?')) return;
  const f = DB.dbGet("SELECT * FROM facturas_proveedores WHERE id=?", [id]);
  if (f) {
    DB.dbRun("UPDATE facturas_proveedores SET abonado=total, estado='pagada' WHERE id=?", [id]);
    DB.saveDB();
  }
  fpRenderContenidoCarpeta(proveedorId, nombre);
  if (typeof showToast==='function') showToast('✓ Factura marcada como pagada');
};

window.fpEliminarFactura = function(id, proveedorId, nombre) {
  if (!confirm('¿Eliminar esta factura y todos sus abonos?')) return;
  DB.dbRun("DELETE FROM abonos_proveedores WHERE factura_id=?", [id]);
  DB.dbRun("DELETE FROM facturas_proveedores WHERE id=?", [id]);
  DB.saveDB();
  fpRenderContenidoCarpeta(proveedorId, nombre);
  if (typeof showToast==='function') showToast('Factura eliminada');
};

window.fpDescargarPDF = function(id) {
  const f = DB.dbGet("SELECT * FROM facturas_proveedores WHERE id=?", [id]);
  if (!f?.pdf_data) { if (typeof showToast==='function') showToast('No hay PDF guardado'); return; }
  try {
    const byteStr = atob(f.pdf_data);
    const arr     = new Uint8Array(byteStr.length);
    for (let i=0; i<byteStr.length; i++) arr[i] = byteStr.charCodeAt(i);
    const blob = new Blob([arr], { type:'application/pdf' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = f.pdf_nombre || `factura-${f.id}.pdf`;
    a.click(); URL.revokeObjectURL(url);
  } catch(e) { if (typeof showToast==='function') showToast('Error al descargar'); }
};

// ============================================================
//  BUSCADOR GLOBAL
// ============================================================
window.fpBuscar = function(q) {
  if (!q || q.length < 2) { fpFiltrarCarpetas(''); return; }
  const ql = q.toLowerCase();
  const provPorNombre = DB.Proveedores.getAll().filter(p => p.nombre.toLowerCase().includes(ql));
  let facturasBuscadas = [];
  try {
    facturasBuscadas = DB.dbQuery(
      `SELECT fp.*, p.nombre as proveedor_nombre FROM facturas_proveedores fp
       JOIN proveedores p ON p.id=fp.proveedor_id WHERE LOWER(fp.numero_factura) LIKE ?`,
      ['%'+ql+'%']
    );
  } catch(e) {}

  const root = document.getElementById('fp-root');
  root.innerHTML = `
    <div class="page-header"><div><div class="page-title">Facturas de Proveedores</div></div></div>
    <div style="margin-bottom:20px;max-width:420px">
      <input class="form-input" value="${q}" placeholder="Buscar por empresa o número de factura..."
        oninput="fpBuscar(this.value)" />
    </div>
    ${facturasBuscadas.length ? `
      <div style="margin-bottom:14px">
        <div style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted);
                    letter-spacing:0.08em;margin-bottom:8px">FACTURAS ENCONTRADAS</div>
        <div style="display:flex;flex-direction:column;gap:8px">
          ${facturasBuscadas.map(f => {
            const saldo = Math.max(0, parseFloat(f.total||0)-parseFloat(f.abonado||0));
            return `
            <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                        padding:12px 16px;display:flex;justify-content:space-between;align-items:center">
              <div>
                <div style="font-family:var(--font-mono);font-size:13px;color:var(--accent)">${f.numero_factura}</div>
                <div style="font-size:12px;color:var(--text-muted)">${f.proveedor_nombre}</div>
              </div>
              <div style="display:flex;align-items:center;gap:10px">
                <div style="text-align:right">
                  <div style="font-family:var(--font-mono);font-size:12px;color:var(--accent)">$${parseFloat(f.total||0).toLocaleString('es-CO')}</div>
                  ${saldo>0?`<div style="font-family:var(--font-mono);font-size:11px;color:var(--red)">Saldo: $${saldo.toLocaleString('es-CO')}</div>`:''}
                </div>
                <span class="tag ${f.estado==='pagada'?'tag-green':'tag-yellow'}">${f.estado.toUpperCase()}</span>
                <button class="btn btn-outline" style="padding:3px 8px;font-size:11px"
                  onclick="fpAbrirCarpeta(${f.proveedor_id},'${f.proveedor_nombre.replace(/'/g,"\\'")}')" >
                  Abrir
                </button>
              </div>
            </div>`;
          }).join('')}
        </div>
      </div>` : ''}
    ${provPorNombre.length ? `
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px">
        ${provPorNombre.map(p=>`
          <div onclick="fpAbrirCarpeta(${p.id},'${p.nombre.replace(/'/g,"\\'")}')"
            style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                   padding:16px;cursor:pointer"
            onmouseenter="this.style.borderColor='var(--accent)'"
            onmouseleave="this.style.borderColor='var(--border)'">
            <div style="font-size:24px;margin-bottom:6px">📁</div>
            <div style="font-size:13px;color:var(--text-primary)">${p.nombre}</div>
          </div>`).join('')}
      </div>` : ''}
    ${!facturasBuscadas.length && !provPorNombre.length ? `
      <div style="text-align:center;padding:40px;color:var(--text-muted);font-family:var(--font-mono)">
        Sin resultados para "${q}"
      </div>` : ''}`;
};

window.fpFiltrarFacturasEnCarpeta = function(q, proveedorId, nombre) {
  let facturas = DB.dbQuery(
    "SELECT * FROM facturas_proveedores WHERE proveedor_id=? ORDER BY creado_en DESC",
    [proveedorId]
  );
  if (q) facturas = facturas.filter(f => (f.numero_factura||'').toLowerCase().includes(q.toLowerCase()));
  const lista = document.getElementById('fp-lista-facturas-carpeta');
  if (lista) lista.innerHTML = facturas.length
    ? fpHtmlFacturas(facturas, proveedorId, nombre)
    : '<div style="text-align:center;padding:32px;color:var(--text-muted)">Sin resultados</div>';
};

window.fpCerrarVentana = function() {
  const v = document.getElementById('fp-ventana-carpeta');
  if (v) v.remove();
  fpRenderLista();
};

window.fpCerrarModal = function() {
  const o = document.getElementById('fp-modal-overlay');
  if (o) o.style.display = 'none';
  window._fpPdfTmp = null;
};

// ============================================================
//  HELPERS
// ============================================================
function diasHastaFP(fechaStr) {
  if (!fechaStr) return null;
  const p = fechaStr.split('/');
  if (p.length!==3) return null;
  const fecha = new Date(p[2], p[1]-1, p[0]);
  if (isNaN(fecha)) return null;
  const hoy = new Date(); hoy.setHours(0,0,0,0);
  return Math.floor((fecha-hoy)/86400000);
}

function fpEstadoVencimiento(fechaVenc, estado) {
  if (estado==='pagada') return { color:'var(--green)', border:'var(--border)', icono:'✓' };
  const dias = diasHastaFP(fechaVenc);
  if (dias===null) return { color:'var(--text-muted)', border:'var(--border)', icono:'📅' };
  if (dias<0)      return { color:'var(--red)',    border:'var(--red)',    icono:'⚠' };
  if (dias<=15)    return { color:'var(--yellow)', border:'var(--yellow)', icono:'⏰' };
  return { color:'var(--text-secondary)', border:'var(--border)', icono:'📅' };
}

function verificarVencimientosProveedores() {
  try {
    const hoy = new Date().toISOString().substring(0,10);
    const facturas = DB.dbQuery(`
      SELECT fp.*, p.nombre as prov_nombre FROM facturas_proveedores fp
      JOIN proveedores p ON p.id=fp.proveedor_id
      WHERE fp.estado='pendiente' AND fp.fecha_vencimiento IS NOT NULL AND fp.fecha_vencimiento!=''`);
    facturas.forEach(f => {
      const dias = diasHastaFP(f.fecha_vencimiento);
      if (dias!==null && dias<=15) {
        const ya = DB.dbGet("SELECT id FROM notificaciones WHERE titulo LIKE ? AND creado_en LIKE ?",
          [`%${f.numero_factura||''}%`, hoy+'%']);
        if (!ya) {
          const msg = dias<0
            ? `Factura ${f.numero_factura||'sin N°'} de "${f.prov_nombre}" venció hace ${Math.abs(dias)} días. Saldo: $${Math.max(0,parseFloat(f.total||0)-parseFloat(f.abonado||0)).toLocaleString('es-CO')}`
            : `Factura ${f.numero_factura||'sin N°'} de "${f.prov_nombre}" vence en ${dias} día${dias!==1?'s':''}. Saldo: $${Math.max(0,parseFloat(f.total||0)-parseFloat(f.abonado||0)).toLocaleString('es-CO')}`;
          DB.Notificaciones.create('alerta', dias<0?'Factura vencida — '+f.prov_nombre:'Por vencer — '+f.prov_nombre, msg);
        }
      }
    });
    if (typeof updateNotifBadge==='function') updateNotifBadge();
  } catch(e) {}
}

function fpRenderCarpeta() {}
