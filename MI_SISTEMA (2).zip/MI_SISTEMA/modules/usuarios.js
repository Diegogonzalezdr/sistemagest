/**
 * usuarios.js — Gestión de usuarios y control de acceso por rol
 *
 * Roles:
 *  - admin     → acceso total (agregar, eliminar, anular, configuración)
 *  - empleado  → solo puede agregar registros, no eliminar ni anular
 */

// ============================================================
//  HELPER — Sesión actual
// ============================================================
function getSesion() {
  try { return JSON.parse(sessionStorage.getItem('sg_user') || '{}'); }
  catch { return {}; }
}

function esAdmin() {
  return getSesion().rol === 'admin';
}

// Exponer globalmente para que otros módulos puedan usarlo
window.esAdmin   = esAdmin;
window.getSesion = getSesion;

// ============================================================
//  CONTROL DE ACCESO — aplica restricciones según rol
// ============================================================
window.aplicarRestriccionesRol = function() {
  const admin = esAdmin();

  // Ocultar botones de eliminar y anular si NO es admin
  if (!admin) {
    // Agrega estilos globales que ocultan los elementos restringidos
    const style = document.createElement('style');
    style.id = 'rol-restrictions';
    style.textContent = `
      .btn-danger,
      button[onclick*="eliminar"],
      button[onclick*="anular"],
      button[onclick*="Anular"],
      button[onclick*="Eliminar"] {
        display: none !important;
      }
    `;
    if (!document.getElementById('rol-restrictions')) {
      document.head.appendChild(style);
    }

    // Ocultar ítem de configuración en el sidebar
    document.querySelectorAll('.nav-item[data-route="configuracion"]').forEach(el => {
      el.style.display = 'none';
    });
  }
};

// ============================================================
//  VISTA — sección dentro de Configuración
// ============================================================
window.renderSeccionUsuarios = function() {
  const admin = esAdmin();

  const usuarios = DB.dbQuery(
    "SELECT id, nombre, email, rol, activo FROM usuarios ORDER BY id ASC"
  );

  const sesion = getSesion();

  return `
    <div style="margin-top:28px">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">
        <div>
          <div style="font-family:var(--font-mono);font-size:13px;font-weight:600;
                      color:var(--text-primary)">Usuarios del sistema</div>
          <div style="font-size:12px;color:var(--text-muted);margin-top:2px">
            Gestiona quién puede acceder al sistema y con qué permisos
          </div>
        </div>
        ${admin ? `<button class="btn btn-primary" onclick="abrirModalUsuario()">+ Nuevo Usuario</button>` : ''}
      </div>

      <!-- Tabla de usuarios -->
      <div class="table-container" style="margin-bottom:20px">
        <table>
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Email</th>
              <th>Teléfono</th>
              <th>Rol</th>
              <th>Estado</th>
              ${admin ? '<th>Acciones</th>' : ''}
            </tr>
          </thead>
          <tbody>
            ${usuarios.map(u => `
              <tr>
                <td style="color:var(--text-primary);font-weight:500">${u.nombre}</td>
                <td style="font-size:12px">${u.email || '—'}</td>
                <td style="font-family:var(--font-mono);font-size:12px">
                  ${DB.dbGet("SELECT telefono FROM usuarios WHERE id=?", [u.id])?.telefono || '—'}
                </td>
                <td>
                  <span class="tag ${u.rol === 'admin' ? 'tag-blue' : 'tag-yellow'}">
                    ${u.rol === 'admin' ? 'Administrador' : 'Empleado'}
                  </span>
                </td>
                <td>
                  <span class="tag ${u.activo ? 'tag-green' : 'tag-red'}">
                    ${u.activo ? 'Activo' : 'Inactivo'}
                  </span>
                </td>
                ${admin ? `
                <td>
                  <div style="display:flex;gap:6px">
                    <button class="btn btn-outline" style="padding:3px 8px;font-size:11px"
                      onclick="editarUsuario(${u.id})">Editar</button>
                    ${u.id !== 1 && u.id !== sesion.id ? `
                      <button class="btn btn-danger" style="padding:3px 8px;font-size:11px"
                        onclick="eliminarUsuario(${u.id},'${u.nombre.replace(/'/g,"\\'")}')">×</button>
                    ` : `<span style="font-size:11px;color:var(--text-muted);padding:3px 6px">Protegido</span>`}
                  </div>
                </td>` : ''}
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>

      <!-- Info de permisos -->
      <div class="table-container" style="padding:16px">
        <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:0.1em;
                    color:var(--text-muted);margin-bottom:12px">PERMISOS POR ROL</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
          <div style="background:var(--accent-dim);border:1px solid var(--accent);
                      border-radius:4px;padding:14px">
            <div style="font-family:var(--font-mono);font-size:12px;font-weight:600;
                        color:var(--accent);margin-bottom:8px">◈ Administrador</div>
            <div style="font-size:12px;color:var(--text-secondary);line-height:1.8">
              ✓ Ver todos los módulos<br>
              ✓ Agregar registros<br>
              ✓ Eliminar registros<br>
              ✓ Anular ventas y compras<br>
              ✓ Gestionar usuarios<br>
              ✓ Acceder a Configuración
            </div>
          </div>
          <div style="background:rgba(255,204,68,0.08);border:1px solid var(--yellow);
                      border-radius:4px;padding:14px">
            <div style="font-family:var(--font-mono);font-size:12px;font-weight:600;
                        color:var(--yellow);margin-bottom:8px">◉ Empleado</div>
            <div style="font-size:12px;color:var(--text-secondary);line-height:1.8">
              ✓ Ver todos los módulos<br>
              ✓ Agregar registros<br>
              ✗ Eliminar registros<br>
              ✗ Anular ventas y compras<br>
              ✗ Gestionar usuarios<br>
              ✗ Acceder a Configuración
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- MODAL USUARIO -->
    <div id="modal-usuario" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.75);
         z-index:500;align-items:center;justify-content:center">
      <div style="background:var(--bg-surface);border:1px solid var(--border);border-radius:6px;
                  width:520px;max-width:95vw;max-height:90vh;overflow-y:auto">
        <div style="display:flex;justify-content:space-between;align-items:center;
                    padding:16px 20px;border-bottom:1px solid var(--border)">
          <span style="font-family:var(--font-mono);font-weight:600" id="modal-usr-title">
            Nuevo Usuario
          </span>
          <button onclick="cerrarModalUsuario()"
            style="background:none;border:none;color:var(--text-muted);font-size:20px;cursor:pointer">×</button>
        </div>
        <div style="padding:20px;display:flex;flex-direction:column;gap:14px">
          <input type="hidden" id="usr-id" />

          <div class="form-group" style="margin:0">
            <label class="form-label">Nombre de usuario *</label>
            <input class="form-input" id="usr-nombre" placeholder="Nombre completo" />
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Correo electrónico *</label>
              <input class="form-input" id="usr-email" type="email" placeholder="correo@ejemplo.com" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Contraseña *</label>
              <input class="form-input" id="usr-password" type="password" placeholder="Contraseña de acceso" />
            </div>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Cédula</label>
              <input class="form-input" id="usr-cedula" placeholder="Número de cédula" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Teléfono</label>
              <input class="form-input" id="usr-telefono" placeholder="Número de teléfono" />
            </div>
          </div>

          <div class="form-group" style="margin:0">
            <label class="form-label">Dirección</label>
            <input class="form-input" id="usr-direccion" placeholder="Dirección del usuario" />
          </div>

          <div class="form-group" style="margin:0">
            <label class="form-label">Rol *</label>
            <select class="form-input" id="usr-rol">
              <option value="empleado">Empleado — acceso limitado</option>
              <option value="admin">Administrador — acceso total</option>
            </select>
            <div style="font-size:11px;color:var(--text-muted);margin-top:4px">
              El administrador puede eliminar registros, anular operaciones y gestionar usuarios.
            </div>
          </div>

          <div id="usr-msg" style="display:none" class="alert"></div>
        </div>
        <div style="padding:14px 20px;border-top:1px solid var(--border);
                    display:flex;justify-content:flex-end;gap:8px">
          <button class="btn btn-outline" onclick="cerrarModalUsuario()">Cancelar</button>
          <button class="btn btn-primary" onclick="guardarUsuario()">Guardar</button>
        </div>
      </div>
    </div>
  `;
};

// ============================================================
//  ABRIR / CERRAR MODAL
// ============================================================
window.abrirModalUsuario = function() {
  ['usr-id','usr-nombre','usr-email','usr-password',
   'usr-cedula','usr-telefono','usr-direccion'].forEach(id => {
    document.getElementById(id).value = '';
  });
  document.getElementById('usr-rol').value = 'empleado';
  document.getElementById('usr-msg').style.display = 'none';
  document.getElementById('modal-usr-title').textContent = 'Nuevo Usuario';
  document.getElementById('modal-usuario').style.display = 'flex';
};

window.cerrarModalUsuario = function() {
  document.getElementById('modal-usuario').style.display = 'none';
};

window.editarUsuario = function(id) {
  const u = DB.dbGet("SELECT * FROM usuarios WHERE id = ?", [id]);
  if (!u) return;
  document.getElementById('usr-id').value        = u.id;
  document.getElementById('usr-nombre').value    = u.nombre || '';
  document.getElementById('usr-email').value     = u.email  || '';
  document.getElementById('usr-password').value  = '';
  document.getElementById('usr-cedula').value    = u.cedula   || '';
  document.getElementById('usr-telefono').value  = u.telefono || '';
  document.getElementById('usr-direccion').value = u.direccion|| '';
  document.getElementById('usr-rol').value       = u.rol || 'empleado';
  document.getElementById('usr-msg').style.display = 'none';
  document.getElementById('modal-usr-title').textContent = 'Editar Usuario';
  document.getElementById('modal-usuario').style.display = 'flex';
};

// ============================================================
//  GUARDAR USUARIO
// ============================================================
window.guardarUsuario = function() {
  const msgEl = document.getElementById('usr-msg');
  msgEl.style.display = 'none';

  const id        = document.getElementById('usr-id').value;
  const nombre    = document.getElementById('usr-nombre').value.trim();
  const email     = document.getElementById('usr-email').value.trim();
  const password  = document.getElementById('usr-password').value;
  const cedula    = document.getElementById('usr-cedula').value.trim();
  const telefono  = document.getElementById('usr-telefono').value.trim();
  const direccion = document.getElementById('usr-direccion').value.trim();
  const rol       = document.getElementById('usr-rol').value;

  // Validaciones
  if (!nombre) { mostrarMsgUsr('El nombre es obligatorio.'); return; }
  if (!email)  { mostrarMsgUsr('El correo electrónico es obligatorio.'); return; }
  if (!id && !password) { mostrarMsgUsr('La contraseña es obligatoria para nuevos usuarios.'); return; }

  // Verificar email duplicado
  const existe = DB.dbGet(
    "SELECT id FROM usuarios WHERE email = ? AND id != ?",
    [email, id || 0]
  );
  if (existe) { mostrarMsgUsr('Ya existe un usuario con ese correo electrónico.'); return; }

  try {
    if (id) {
      // Editar — si no escribe contraseña, la mantiene
      if (password) {
        DB.dbRun(
          "UPDATE usuarios SET nombre=?,email=?,password=?,cedula=?,telefono=?,direccion=?,rol=? WHERE id=?",
          [nombre, email, password, cedula, telefono, direccion, rol, id]
        );
      } else {
        DB.dbRun(
          "UPDATE usuarios SET nombre=?,email=?,cedula=?,telefono=?,direccion=?,rol=? WHERE id=?",
          [nombre, email, cedula, telefono, direccion, rol, id]
        );
      }
      DB.saveDB();
      showToast('Usuario actualizado correctamente');
    } else {
      DB.dbRun(
        "INSERT INTO usuarios (nombre,email,password,cedula,telefono,direccion,rol,activo) VALUES (?,?,?,?,?,?,'"+rol+"',1)",
        [nombre, email, password, cedula, telefono, direccion]
      );
      DB.saveDB();
      showToast('Usuario creado correctamente');
    }

    cerrarModalUsuario();
    // Recarga la sección de usuarios
    document.getElementById('seccion-usuarios').innerHTML = renderSeccionUsuarios();

  } catch(err) {
    mostrarMsgUsr('Error al guardar: ' + err.message);
  }
};

function mostrarMsgUsr(texto) {
  const el = document.getElementById('usr-msg');
  el.className = 'alert alert-error';
  el.textContent = texto;
  el.style.display = 'block';
}

// ============================================================
//  ELIMINAR USUARIO
// ============================================================
window.eliminarUsuario = function(id, nombre) {
  if (!esAdmin()) { showToast('Sin permiso para eliminar usuarios'); return; }
  if (!confirm('¿Eliminar al usuario "' + nombre + '"?')) return;
  DB.dbRun("UPDATE usuarios SET activo = 0 WHERE id = ?", [id]);
  DB.saveDB();
  document.getElementById('seccion-usuarios').innerHTML = renderSeccionUsuarios();
  showToast('Usuario eliminado');
};
