/**
 * reportes.js — Módulo de Reportes y Análisis — Fase 4
 *
 * - Ventas vs Compras por mes (gráfica de barras)
 * - Top 10 productos más vendidos (gráfica de barras horizontal)
 * - Ingresos mes actual vs mes anterior (gráfica de línea)
 * - Clientes con más compras (gráfica de torta + tabla)
 * - Exportación a PDF
 */

// ============================================================
//  HELPERS
// ============================================================
const R = {
  fmt: (v) => new Intl.NumberFormat('es-CO',{style:'currency',currency:'COP',minimumFractionDigits:0}).format(v||0),
  fmtNum: (v) => new Intl.NumberFormat('es-CO').format(v||0),
  meses: ['Ene','Feb','Mar','Abr','May','Jun','Jul','Ago','Sep','Oct','Nov','Dic'],
  mesNombre: (n) => ['Enero','Febrero','Marzo','Abril','Mayo','Junio','Julio','Agosto','Septiembre','Octubre','Noviembre','Diciembre'][n-1]||'',
  color: (i) => ['#4a9eff','#3ddc84','#ffcc44','#ff6b6b','#a78bfa','#34d399','#fb923c','#60a5fa','#f472b6','#38bdf8'][i%10],
};

// ── Datos de ventas por mes (últimos 6 meses) ──
function getVentasPorMes() {
  try {
    const rows = DB.dbQuery(`
      SELECT strftime('%Y-%m', creado_en) as mes,
             SUM(total) as total, COUNT(*) as cnt
      FROM ventas WHERE estado != 'anulada'
      GROUP BY mes ORDER BY mes DESC LIMIT 6`);
    return rows.reverse();
  } catch(e) { return []; }
}

function getComprasPorMes() {
  try {
    const rows = DB.dbQuery(`
      SELECT strftime('%Y-%m', creado_en) as mes,
             SUM(total) as total, COUNT(*) as cnt
      FROM compras WHERE estado != 'anulada'
      GROUP BY mes ORDER BY mes DESC LIMIT 6`);
    return rows.reverse();
  } catch(e) { return []; }
}

function getTopProductos() {
  try {
    return DB.dbQuery(`
      SELECT p.nombre, SUM(vd.cantidad) as total_uds,
             SUM(vd.subtotal) as total_valor
      FROM ventas_detalle vd
      JOIN productos p ON p.id = vd.producto_id
      JOIN ventas v ON v.id = vd.venta_id
      WHERE v.estado != 'anulada'
      GROUP BY p.id ORDER BY total_uds DESC LIMIT 10`);
  } catch(e) { return []; }
}

function getClientesTop() {
  try {
    return DB.dbQuery(`
      SELECT c.nombre, COUNT(v.id) as total_ventas,
             SUM(v.total) as total_valor
      FROM ventas v
      JOIN clientes c ON c.id = v.cliente_id
      WHERE v.estado != 'anulada'
      GROUP BY c.id ORDER BY total_valor DESC LIMIT 8`);
  } catch(e) { return []; }
}

function getResumenMes() {
  try {
    const hoy      = new Date();
    const mesAct   = hoy.toISOString().substring(0,7);
    const mesAnt   = new Date(hoy.getFullYear(), hoy.getMonth()-1, 1).toISOString().substring(0,7);

    const vAct = DB.dbGet(`SELECT SUM(total) as s, COUNT(*) as n FROM ventas WHERE estado!='anulada' AND strftime('%Y-%m',creado_en)=?`,[mesAct]);
    const vAnt = DB.dbGet(`SELECT SUM(total) as s, COUNT(*) as n FROM ventas WHERE estado!='anulada' AND strftime('%Y-%m',creado_en)=?`,[mesAnt]);
    const cAct = DB.dbGet(`SELECT SUM(total) as s FROM compras WHERE estado!='anulada' AND strftime('%Y-%m',creado_en)=?`,[mesAct]);
    const util = (vAct?.s||0) - (cAct?.s||0);
    const var_ = vAnt?.s ? (((vAct?.s||0) - (vAnt?.s||0)) / (vAnt?.s||1)) * 100 : 0;

    return {
      ventas_mes:    vAct?.s  || 0,
      ventas_cnt:    vAct?.n  || 0,
      ventas_ant:    vAnt?.s  || 0,
      compras_mes:   cAct?.s  || 0,
      utilidad:      util,
      variacion:     var_,
      mes_nombre:    R.mesNombre(hoy.getMonth()+1),
      mes_ant_nombre:R.mesNombre(hoy.getMonth()),
    };
  } catch(e) {
    const hoy = new Date();
    return { ventas_mes:0, ventas_cnt:0, ventas_ant:0, compras_mes:0,
             utilidad:0, variacion:0,
             mes_nombre:R.mesNombre(hoy.getMonth()+1),
             mes_ant_nombre:R.mesNombre(hoy.getMonth()) };
  }
}

// ============================================================
//  GRÁFICA SVG — BARRAS DOBLES (Ventas vs Compras)
// ============================================================
function svgBarrasDobles(ventas, compras, width=680, height=220) {
  const meses   = [...new Set([...ventas.map(v=>v.mes), ...compras.map(c=>c.mes)])].sort();
  const maxVal  = Math.max(...meses.map(m=>{
    const v = ventas.find(x=>x.mes===m)?.total||0;
    const c = compras.find(x=>x.mes===m)?.total||0;
    return Math.max(v,c);
  }), 1);

  const pad   = { top:20, right:20, bottom:40, left:70 };
  const W     = width - pad.left - pad.right;
  const H     = height - pad.top - pad.bottom;
  const bw    = W / meses.length;
  const bPad  = bw * 0.15;
  const bW    = (bw - bPad*2) / 2 - 2;

  const yScale = v => H - (v / maxVal) * H;
  const yLabel = v => {
    if (v >= 1000000) return '$'+(v/1000000).toFixed(1)+'M';
    if (v >= 1000)    return '$'+(v/1000).toFixed(0)+'K';
    return '$'+v;
  };

  // Y grid lines
  const gridLines = [0,0.25,0.5,0.75,1].map(f => {
    const y = H - f*H;
    return `<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="#2a3a4a" stroke-width="1"/>
            <text x="-8" y="${y+4}" text-anchor="end" fill="#666" font-size="10">${yLabel(maxVal*f)}</text>`;
  }).join('');

  const bars = meses.map((mes,i) => {
    const vVal = ventas.find(x=>x.mes===mes)?.total||0;
    const cVal = compras.find(x=>x.mes===mes)?.total||0;
    const x    = i * bw + bPad;
    const vH   = (vVal/maxVal)*H;
    const cH   = (cVal/maxVal)*H;
    const label= R.meses[parseInt(mes.split('-')[1])-1] + ' ' + mes.split('-')[0].substring(2);
    return `
      <rect x="${x}" y="${yScale(vVal)}" width="${bW}" height="${vH}" fill="#4a9eff" rx="2" opacity="0.9"/>
      <rect x="${x+bW+2}" y="${yScale(cVal)}" width="${bW}" height="${cH}" fill="#ff6b6b" rx="2" opacity="0.9"/>
      <text x="${x+bW}" y="${H+16}" text-anchor="middle" fill="#888" font-size="10">${label}</text>`;
  }).join('');

  return `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg"
    style="background:#0d1117;border-radius:6px">
    <g transform="translate(${pad.left},${pad.top})">
      ${gridLines}${bars}
    </g>
    <!-- Leyenda -->
    <rect x="${pad.left}" y="${height-12}" width="10" height="10" fill="#4a9eff" rx="2"/>
    <text x="${pad.left+14}" y="${height-4}" fill="#888" font-size="11">Ventas</text>
    <rect x="${pad.left+70}" y="${height-12}" width="10" height="10" fill="#ff6b6b" rx="2"/>
    <text x="${pad.left+84}" y="${height-4}" fill="#888" font-size="11">Compras</text>
  </svg>`;
}

// ============================================================
//  GRÁFICA SVG — BARRAS HORIZONTALES (Top productos)
// ============================================================
function svgBarrasHoriz(datos, width=680, height=260) {
  if (!datos.length) return '<div style="padding:40px;text-align:center;color:var(--text-muted)">Sin datos</div>';
  const maxVal = Math.max(...datos.map(d=>d.total_uds), 1);
  const rowH   = Math.floor((height-30) / datos.length);
  const barH   = rowH * 0.55;
  const labW   = 140;
  const barW   = width - labW - 80;

  const rows = datos.map((d,i) => {
    const w   = (d.total_uds / maxVal) * barW;
    const y   = i * rowH + (rowH-barH)/2 + 20;
    const nom = d.nombre.length > 18 ? d.nombre.substring(0,17)+'…' : d.nombre;
    return `
      <text x="${labW-6}" y="${y+barH*0.7}" text-anchor="end" fill="#aaa" font-size="11">${nom}</text>
      <rect x="${labW}" y="${y}" width="${w}" height="${barH}" fill="${R.color(i)}" rx="3" opacity="0.85"/>
      <text x="${labW+w+6}" y="${y+barH*0.7}" fill="#ccc" font-size="11">${R.fmtNum(d.total_uds)} uds</text>`;
  }).join('');

  return `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg"
    style="background:#0d1117;border-radius:6px">
    <text x="${labW}" y="14" fill="#666" font-size="10">0</text>
    <text x="${labW+barW}" y="14" text-anchor="end" fill="#666" font-size="10">${R.fmtNum(maxVal)} uds</text>
    ${rows}
  </svg>`;
}

// ============================================================
//  GRÁFICA SVG — TORTA (Clientes)
// ============================================================
function svgTorta(datos, size=200) {
  if (!datos.length) return '';
  const total = datos.reduce((s,d)=>s+parseFloat(d.total_valor||0),0);
  let   ang   = -Math.PI/2;
  const cx    = size/2, cy = size/2, r = size/2 - 10;

  const slices = datos.map((d,i) => {
    const val  = parseFloat(d.total_valor||0);
    const pct  = val/total;
    const a1   = ang;
    const a2   = ang + pct * 2 * Math.PI;
    ang        = a2;
    const x1   = cx + r*Math.cos(a1), y1 = cy + r*Math.sin(a1);
    const x2   = cx + r*Math.cos(a2), y2 = cy + r*Math.sin(a2);
    const large= pct > 0.5 ? 1 : 0;
    return `<path d="M${cx},${cy} L${x1},${y1} A${r},${r} 0 ${large},1 ${x2},${y2} Z"
              fill="${R.color(i)}" opacity="0.88"/>`;
  }).join('');

  return `<svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">${slices}</svg>`;
}

// ============================================================
//  VISTA PRINCIPAL
// ============================================================
window.viewReportes = function() {
  return `
    <div class="page-header">
      <div>
        <div class="page-title">Reportes</div>
        <div class="page-subtitle">Análisis y estadísticas del negocio</div>
      </div>
      <button class="btn btn-primary" onclick="exportarReportePDF()">
        🖨 Exportar PDF
      </button>
    </div>
    <div id="reportes-contenido">
      <div style="text-align:center;padding:60px;color:var(--text-muted);font-family:var(--font-mono)">
        <div class="loading-spinner" style="margin:0 auto 16px"></div>
        Cargando reportes...
      </div>
    </div>`;
};

window.initReportes = function() {
  setTimeout(renderReportes, 50);
};

function renderReportes() {
  const res     = getResumenMes();
  const ventas  = getVentasPorMes();
  const compras = getComprasPorMes();
  const topProd = getTopProductos();
  const topCli  = getClientesTop();

  const contenido = document.getElementById('reportes-contenido');
  if (!contenido) return;

  contenido.innerHTML = `
    <div id="reporte-imprimible">

      <!-- ═══ TARJETAS KPI ═══ -->
      <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
                  gap:14px;margin-bottom:24px">
        ${[
          ['VENTAS '+res.mes_nombre.toUpperCase(), R.fmt(res.ventas_mes),
           res.variacion>=0?'var(--green)':'var(--red)',
           res.variacion>=0?'↑':'↓', Math.abs(res.variacion).toFixed(1)+'% vs mes ant.'],
          ['COMPRAS '+res.mes_nombre.toUpperCase(), R.fmt(res.compras_mes), 'var(--yellow)', '', ''],
          ['UTILIDAD BRUTA', R.fmt(res.utilidad), res.utilidad>=0?'var(--green)':'var(--red)', '', 'Ventas − Compras'],
          ['N° VENTAS', R.fmtNum(res.ventas_cnt), 'var(--accent)', '', res.mes_nombre],
        ].map(([label,val,color,icon,sub])=>`
          <div class="card">
            <div class="card-label">${label}</div>
            <div class="card-value" style="color:${color};font-size:20px">${val}</div>
            ${sub?`<div style="font-size:11px;color:${color};margin-top:4px;font-family:var(--font-mono)">${icon} ${sub}</div>`:''}
          </div>`).join('')}
      </div>

      <!-- ═══ VENTAS VS COMPRAS ═══ -->
      <div class="table-container" style="margin-bottom:20px">
        <div class="table-header">
          <span class="table-title">VENTAS VS COMPRAS — ÚLTIMOS 6 MESES</span>
        </div>
        <div style="padding:16px;overflow-x:auto">
          ${svgBarrasDobles(ventas, compras)}
        </div>
        <table>
          <thead><tr><th>Mes</th><th>Ventas</th><th>N° Ventas</th><th>Compras</th><th>Diferencia</th></tr></thead>
          <tbody>
            ${(() => {
              const meses = [...new Set([...ventas.map(v=>v.mes),...compras.map(c=>c.mes)])].sort();
              return meses.map(mes => {
                const v = ventas.find(x=>x.mes===mes);
                const c = compras.find(x=>x.mes===mes);
                const vT = v?.total||0, cT = c?.total||0;
                const dif = vT - cT;
                const label = R.meses[parseInt(mes.split('-')[1])-1]+' '+mes.split('-')[0];
                return `<tr>
                  <td style="font-family:var(--font-mono)">${label}</td>
                  <td style="font-family:var(--font-mono);color:var(--green)">${R.fmt(vT)}</td>
                  <td style="font-family:var(--font-mono)">${v?.cnt||0}</td>
                  <td style="font-family:var(--font-mono);color:var(--red)">${R.fmt(cT)}</td>
                  <td style="font-family:var(--font-mono);color:${dif>=0?'var(--green)':'var(--red)'};font-weight:600">
                    ${dif>=0?'+':''}${R.fmt(dif)}
                  </td>
                </tr>`;
              }).join('');
            })()}
          </tbody>
        </table>
      </div>

      <!-- ═══ TOP PRODUCTOS ═══ -->
      <div class="table-container" style="margin-bottom:20px">
        <div class="table-header">
          <span class="table-title">TOP 10 PRODUCTOS MÁS VENDIDOS</span>
        </div>
        <div style="padding:16px;overflow-x:auto">
          ${svgBarrasHoriz(topProd)}
        </div>
        <table>
          <thead><tr><th>#</th><th>Producto</th><th>Unidades vendidas</th><th>Valor total</th></tr></thead>
          <tbody>
            ${topProd.length ? topProd.map((p,i)=>`
              <tr>
                <td style="font-family:var(--font-mono);color:${R.color(i)};font-weight:700">${String(i+1).padStart(2,'0')}</td>
                <td>${p.nombre}</td>
                <td style="font-family:var(--font-mono)">${R.fmtNum(p.total_uds)} uds</td>
                <td style="font-family:var(--font-mono);color:var(--accent)">${R.fmt(p.total_valor)}</td>
              </tr>`).join('')
            : '<tr><td colspan="4" style="text-align:center;color:var(--text-muted)">Sin ventas registradas</td></tr>'}
          </tbody>
        </table>
      </div>

      <!-- ═══ INGRESOS MES ACTUAL VS ANTERIOR ═══ -->
      <div class="table-container" style="margin-bottom:20px">
        <div class="table-header">
          <span class="table-title">COMPARATIVO MENSUAL</span>
        </div>
        <div style="padding:16px;display:grid;grid-template-columns:1fr 1fr;gap:20px">
          <div>
            <div style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted);margin-bottom:8px">
              ${res.mes_nombre.toUpperCase()} (MES ACTUAL)
            </div>
            <div style="font-size:28px;font-weight:700;color:var(--green);font-family:var(--font-mono)">
              ${R.fmt(res.ventas_mes)}
            </div>
            <div style="font-size:12px;color:var(--text-muted);margin-top:4px">
              ${R.fmtNum(res.ventas_cnt)} ventas realizadas
            </div>
          </div>
          <div>
            <div style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted);margin-bottom:8px">
              ${res.mes_ant_nombre.toUpperCase()} (MES ANTERIOR)
            </div>
            <div style="font-size:28px;font-weight:700;color:var(--text-secondary);font-family:var(--font-mono)">
              ${R.fmt(res.ventas_ant)}
            </div>
            <div style="margin-top:12px;padding:8px 12px;border-radius:4px;
                        background:${res.variacion>=0?'rgba(61,220,132,0.1)':'rgba(255,107,107,0.1)'};
                        font-family:var(--font-mono);font-size:13px;
                        color:${res.variacion>=0?'var(--green)':'var(--red)'}">
              ${res.variacion>=0?'↑':'↓'} ${Math.abs(res.variacion).toFixed(1)}%
              ${res.variacion>=0?' más que el mes anterior':' menos que el mes anterior'}
            </div>
          </div>
        </div>
        <!-- Barra comparativa -->
        ${res.ventas_mes>0||res.ventas_ant>0 ? (() => {
          const max = Math.max(res.ventas_mes, res.ventas_ant, 1);
          const pAct = (res.ventas_mes/max)*100;
          const pAnt = (res.ventas_ant/max)*100;
          return `<div style="padding:0 16px 16px">
            <div style="margin-bottom:8px">
              <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-muted);margin-bottom:4px">
                <span>${res.mes_nombre}</span><span>${R.fmt(res.ventas_mes)}</span>
              </div>
              <div style="height:8px;background:var(--bg-elevated);border-radius:4px">
                <div style="height:100%;width:${pAct}%;background:var(--green);border-radius:4px;transition:width 0.5s"></div>
              </div>
            </div>
            <div>
              <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-muted);margin-bottom:4px">
                <span>${res.mes_ant_nombre}</span><span>${R.fmt(res.ventas_ant)}</span>
              </div>
              <div style="height:8px;background:var(--bg-elevated);border-radius:4px">
                <div style="height:100%;width:${pAnt}%;background:var(--text-muted);border-radius:4px"></div>
              </div>
            </div>
          </div>`;
        })() : ''}
      </div>

      <!-- ═══ CLIENTES TOP ═══ -->
      <div class="table-container" style="margin-bottom:20px">
        <div class="table-header">
          <span class="table-title">CLIENTES CON MÁS COMPRAS</span>
        </div>
        <div style="padding:16px;display:grid;grid-template-columns:auto 1fr;gap:24px;align-items:start">
          ${topCli.length ? svgTorta(topCli) : ''}
          <div>
            ${topCli.length ? topCli.map((c,i)=>`
              <div style="display:flex;justify-content:space-between;align-items:center;
                          padding:8px 0;border-bottom:1px solid var(--border)">
                <div style="display:flex;align-items:center;gap:10px">
                  <div style="width:12px;height:12px;border-radius:50%;background:${R.color(i)};flex-shrink:0"></div>
                  <div>
                    <div style="font-size:13px;color:var(--text-primary)">${c.nombre}</div>
                    <div style="font-size:11px;color:var(--text-muted)">${c.total_ventas} compra${c.total_ventas!==1?'s':''}</div>
                  </div>
                </div>
                <div style="font-family:var(--font-mono);color:var(--accent);font-weight:600">
                  ${R.fmt(c.total_valor)}
                </div>
              </div>`).join('')
            : '<div style="color:var(--text-muted);text-align:center;padding:20px">Sin datos de clientes</div>'}
          </div>
        </div>
      </div>

    </div><!-- fin reporte-imprimible -->`;
}

// ============================================================
//  EXPORTAR A PDF
// ============================================================
window.exportarReportePDF = function() {
  const contenido = document.getElementById('reporte-imprimible');
  if (!contenido) { if(typeof showToast==='function') showToast('Primero carga los reportes'); return; }

  const empresa = DB.Config.get('nombre_empresa') || DB.Config.get('razon_social') || 'Mi Empresa';
  const fecha   = new Date().toLocaleDateString('es-CO',{year:'numeric',month:'long',day:'numeric'});

  const win = window.open('', '_blank', 'width=900,height=700');
  win.document.write(`<!DOCTYPE html><html><head>
    <meta charset="UTF-8"/>
    <title>Reporte — ${empresa}</title>
    <style>
      * { margin:0; padding:0; box-sizing:border-box; }
      body { font-family: Arial, sans-serif; font-size:13px; color:#222;
             background:#fff; padding:24px; }
      h1 { font-size:22px; color:#1E3A5F; margin-bottom:4px; }
      h2 { font-size:15px; color:#2E6DA4; margin:20px 0 10px; border-bottom:2px solid #2E6DA4; padding-bottom:4px; }
      .header { display:flex; justify-content:space-between; align-items:flex-start;
                border-bottom:3px solid #1E3A5F; padding-bottom:14px; margin-bottom:20px; }
      .kpis { display:grid; grid-template-columns:repeat(4,1fr); gap:12px; margin-bottom:20px; }
      .kpi  { background:#f0f4fa; border-radius:6px; padding:12px; text-align:center; }
      .kpi-label { font-size:10px; color:#888; letter-spacing:1px; margin-bottom:4px; }
      .kpi-val   { font-size:18px; font-weight:700; color:#1E3A5F; font-family:monospace; }
      table { width:100%; border-collapse:collapse; margin-bottom:16px; font-size:12px; }
      th { background:#1E3A5F; color:#fff; padding:7px 10px; text-align:left; font-size:11px; }
      td { padding:6px 10px; border-bottom:1px solid #e8e8e8; }
      tr:nth-child(even) td { background:#f8fafc; }
      .section { margin-bottom:24px; }
      svg { display:block; max-width:100%; }
      @media print {
        body { padding:10px; }
        button { display:none !important; }
      }
    </style>
  </head><body>
    <div class="header">
      <div>
        <h1>${empresa}</h1>
        <div style="font-size:12px;color:#666">Reporte de análisis y estadísticas del negocio</div>
      </div>
      <div style="text-align:right;font-size:12px;color:#666">
        <div>Fecha: ${fecha}</div>
        <div>Generado por SistemaGest</div>
      </div>
    </div>
    ${contenido.innerHTML
      .replace(/background:var\(--bg[^)]+\)/g,'background:#fff')
      .replace(/color:var\(--[^)]+\)/g,'color:#333')
      .replace(/border:[^;]+var\(--[^)]+\)[^;]*/g,'border:1px solid #ddd')
      .replace(/class="[^"]*"/g,'')
      .replace(/style="display:none[^"]*"/g,'')}
    <br/>
    <div style="text-align:center;color:#aaa;font-size:11px;border-top:1px solid #eee;padding-top:12px">
      SistemaGest — Reporte generado el ${fecha}
    </div>
    <br/>
    <div style="text-align:center">
      <button onclick="window.print()" style="padding:10px 28px;font-size:14px;
        background:#1E3A5F;color:#fff;border:none;border-radius:4px;cursor:pointer">
        🖨 Imprimir / Guardar como PDF
      </button>
    </div>
  </body></html>`);
  win.document.close();
  if(typeof showToast==='function') showToast('✓ Reporte listo para imprimir');
};
