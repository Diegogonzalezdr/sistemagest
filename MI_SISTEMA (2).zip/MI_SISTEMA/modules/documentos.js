/**
 * documentos.js — Gestión de documentos legales de la empresa
 * 
 * - Cámara de Comercio: carga PDF, extrae datos, alerta vencimiento
 * - RUT: carga PDF, extrae NIT y razón social
 * - Actualiza configuración del sistema con los datos extraídos
 * - Alertas automáticas: vencido o próximo a vencer (60 días)
 */

const DIAS_ALERTA = 60;

// ── Claves en configuración ──
const KEYS = {
  razon_social:   'razon_social',
  nit:            'nit',
  direccion_emp:  'direccion_empresa',
  telefono_emp:   'telefono_empresa',
  email_emp:      'email_empresa',
  regimen:        'regimen_fiscal',
  // Cámara de Comercio
  cc_expedicion:  'cc_fecha_expedicion',
  cc_vencimiento: 'cc_fecha_vencimiento',
  cc_matricula:   'cc_numero_matricula',
  cc_pdf:         'cc_pdf_nombre',
  // RUT
  rut_actualizacion: 'rut_fecha_actualizacion',
  rut_actividad:     'rut_actividad_economica',
  rut_pdf:           'rut_pdf_nombre',
};

// ── Asegura que existan las claves en configuración ──
function initDocumentosConfig() {
  const defaults = {
    [KEYS.razon_social]:    ['', 'Razón social de la empresa'],
    [KEYS.nit]:             ['', 'NIT de la empresa'],
    [KEYS.direccion_emp]:   ['', 'Dirección de la empresa'],
    [KEYS.telefono_emp]:    ['', 'Teléfono de la empresa'],
    [KEYS.email_emp]:       ['', 'Email de la empresa'],
    [KEYS.regimen]:         ['', 'Régimen fiscal (Simplificado / Común)'],
    [KEYS.cc_expedicion]:   ['', 'Fecha de expedición Cámara de Comercio'],
    [KEYS.cc_vencimiento]:  ['', 'Fecha de vencimiento Cámara de Comercio'],
    [KEYS.cc_matricula]:    ['', 'Número de matrícula mercantil'],
    [KEYS.cc_pdf]:          ['', 'Nombre del archivo PDF - Cámara de Comercio'],
    [KEYS.rut_actualizacion]:['','Fecha de última actualización del RUT'],
    [KEYS.rut_actividad]:   ['', 'Actividad económica (CIIU)'],
    [KEYS.rut_pdf]:         ['', 'Nombre del archivo PDF - RUT'],
  };
  Object.entries(defaults).forEach(([clave, [valor, desc]]) => {
    DB.dbRun(
      "INSERT OR IGNORE INTO configuracion (clave, valor, descripcion) VALUES (?,?,?)",
      [clave, valor, desc]
    );
  });
  DB.saveDB();
}

// ── Días hasta una fecha ──
function diasHasta(fechaStr) {
  if (!fechaStr) return null;
  const partes = fechaStr.split('/');
  let fecha;
  if (partes.length === 3) {
    // dd/mm/yyyy
    fecha = new Date(partes[2], partes[1]-1, partes[0]);
  } else {
    fecha = new Date(fechaStr);
  }
  if (isNaN(fecha)) return null;
  const hoy = new Date();
  hoy.setHours(0,0,0,0);
  return Math.floor((fecha - hoy) / (1000 * 60 * 60 * 24));
}

// ── Estado de alerta de un documento ──
function estadoDocumento(fechaVenc) {
  const dias = diasHasta(fechaVenc);
  if (dias === null) return { tipo: 'sin-fecha', label: 'Sin fecha', color: 'var(--text-muted)' };
  if (dias < 0)      return { tipo: 'vencido',   label: `Vencido hace ${Math.abs(dias)} días`, color: 'var(--red)' };
  if (dias <= DIAS_ALERTA) return { tipo: 'proximo', label: `Vence en ${dias} días`, color: 'var(--yellow)' };
  return { tipo: 'vigente', label: `Vigente (${dias} días restantes)`, color: 'var(--green)' };
}

// ── Generar alertas de vencimiento en notificaciones ──
function verificarAlertas() {
  const ccVenc = DB.Config.get(KEYS.cc_vencimiento);
  if (ccVenc) {
    const est = estadoDocumento(ccVenc);
    if (est.tipo === 'vencido') {
      DB.Notificaciones.create('alerta',
        'Cámara de Comercio VENCIDA',
        `La Cámara de Comercio venció el ${ccVenc}. Renuévala para continuar operando legalmente.`
      );
    } else if (est.tipo === 'proximo') {
      const dias = diasHasta(ccVenc);
      DB.Notificaciones.create('alerta',
        'Cámara de Comercio próxima a vencer',
        `La Cámara de Comercio vence en ${dias} días (${ccVenc}). Realiza la renovación con anticipación.`
      );
    }
  }
  DB.saveDB();
  if (typeof updateNotifBadge === 'function') updateNotifBadge();
}

// ============================================================
//  EXTRACCIÓN DE TEXTO DEL PDF
// ============================================================
async function cargarPDFjs() {
  if (window.pdfjsLib) return;
  await new Promise((res, rej) => {
    const s = document.createElement("script");
    s.src = window._pdfJsUrl || "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js";
    s.onload = () => {
      pdfjsLib.GlobalWorkerOptions.workerSrc = window._pdfJsWorker || "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
      res();
    };
    s.onerror = rej;
    document.head.appendChild(s);
  });
}

async function extraerTextoPDF(file) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = async function(e) {
      try {
        await cargarPDFjs();
        if (window.pdfjsLib) {
          const pdf = await pdfjsLib.getDocument({ data: e.target.result }).promise;
          let texto = '';
          for (let i = 1; i <= Math.min(pdf.numPages, 3); i++) {
            const page = await pdf.getPage(i);
            const content = await page.getTextContent();
            texto += content.items.map(s => s.str).join(' ') + '\n';
          }
          resolve(texto);
        } else {
          resolve('');
        }
      } catch(err) {
        console.warn('PDF.js no pudo leer el PDF:', err);
        resolve('');
      }
    };
    reader.readAsArrayBuffer(file);
  });
}

// ── Extrae campos de Cámara de Comercio ──
function parsearCamaraComercio(texto) {
  const datos = {};
  const t = texto.toUpperCase();

  // NIT
  const nitMatch = texto.match(/NIT[:\s#Nº°\.]*([0-9]{6,12}[\s\-]?[0-9]?)/i);
  if (nitMatch) datos.nit = nitMatch[1].replace(/\s/g,'');

  // Razón social — busca después de "Razón Social" o "DENOMINACIÓN"
  const rsMatch = texto.match(/(?:RAZ[OÓ]N SOCIAL|DENOMINACI[OÓ]N SOCIAL)[:\s]+([A-ZÁÉÍÓÚÑ][A-Za-záéíóúñ\s\.\,\&]{3,60}?)(?:\n|NIT|MATRÍCULA)/i);
  if (rsMatch) datos.razon_social = rsMatch[1].trim();

  // Matrícula
  const matMatch = texto.match(/MATR[IÍ]CULA\s*(?:MERCANTIL)?\s*(?:N[°oO]|#|:)?\s*([0-9\-]{4,15})/i);
  if (matMatch) datos.cc_matricula = matMatch[1].trim();

  // Fechas — busca patrones dd/mm/yyyy o dd-mm-yyyy
  const fechas = [...texto.matchAll(/(\d{2})[\/\-](\d{2})[\/\-](\d{4})/g)].map(m => `${m[1]}/${m[2]}/${m[3]}`);
  if (fechas.length >= 1) datos.cc_expedicion  = fechas[0];
  if (fechas.length >= 2) datos.cc_vencimiento = fechas[1];

  // Dirección
  const dirMatch = texto.match(/(?:DIRECCI[OÓ]N|DOMICILIO)[:\s]+([A-Za-záéíóúñ0-9\s\.\,\#\-]{8,60}?)(?:\n|TEL|CIUDAD|$)/i);
  if (dirMatch) datos.direccion = dirMatch[1].trim();

  return datos;
}

// ── Extrae campos del RUT ──
function parsearRUT(texto) {
  const datos = {};

  // NIT
  const nitMatch = texto.match(/NIT[:\s#Nº°\.]*([0-9]{6,12}[\s\-]?[0-9]?)/i);
  if (nitMatch) datos.nit = nitMatch[1].replace(/\s/g,'');

  // Razón social
  const rsMatch = texto.match(/(?:RAZ[OÓ]N SOCIAL|NOMBRE O RAZ[OÓ]N SOCIAL)[:\s]+([A-ZÁÉÍÓÚÑ][A-Za-záéíóúñ\s\.\,\&]{3,60}?)(?:\n|NIT|RUT|$)/i);
  if (rsMatch) datos.razon_social = rsMatch[1].trim();

  // Actividad económica CIIU
  const actMatch = texto.match(/(?:ACTIVIDAD ECON[OÓ]MICA|CIIU)[:\s]+([0-9]{3,4}[\s\-][A-Za-záéíóúñ\s]{3,60}?)(?:\n|$)/i);
  if (actMatch) datos.rut_actividad = actMatch[1].trim();

  // Régimen
  if (/SIMPLIFICADO/i.test(texto)) datos.regimen = 'Régimen Simplificado';
  else if (/COM[UÚ]N|RESPONSABLE DE IVA/i.test(texto)) datos.regimen = 'Régimen Común';

  // Fecha actualización
  const fechas = [...texto.matchAll(/(\d{2})[\/\-](\d{2})[\/\-](\d{4})/g)].map(m => `${m[1]}/${m[2]}/${m[3]}`);
  if (fechas.length >= 1) datos.rut_actualizacion = fechas[0];

  return datos;
}

// ============================================================
//  VISTA
// ============================================================
window.renderSeccionDocumentos = function() {
  initDocumentosConfig();

  const cfg = (k) => DB.Config.get(k) || '';
  const ccVenc = cfg(KEYS.cc_vencimiento);
  const estCC  = estadoDocumento(ccVenc);
  const ccPdf  = cfg(KEYS.cc_pdf);
  const rutPdf = cfg(KEYS.rut_pdf);

  return `
    <div style="margin-top:28px">
      <div style="margin-bottom:16px">
        <div style="font-family:var(--font-mono);font-size:13px;font-weight:600;color:var(--text-primary)">
          Documentos legales de la empresa
        </div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:2px">
          Carga el PDF de cada documento. El sistema extrae los datos automáticamente y los usa en las facturas.
        </div>
      </div>

      <!-- ═══ DATOS DE LA EMPRESA ═══ -->
      <div class="table-container" style="margin-bottom:16px">
        <div class="table-header">
          <span class="table-title">DATOS PARA FACTURACIÓN ELECTRÓNICA</span>
          <button class="btn btn-primary" style="padding:4px 12px;font-size:11px"
            onclick="guardarDatosEmpresa()">Guardar cambios</button>
        </div>
        <div style="padding:16px;display:grid;grid-template-columns:1fr 1fr;gap:14px">
          <div class="form-group" style="margin:0">
            <label class="form-label">Razón Social *</label>
            <input class="form-input" id="doc-razon-social" value="${cfg(KEYS.razon_social)}" placeholder="Nombre o razón social" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">NIT *</label>
            <input class="form-input" id="doc-nit" value="${cfg(KEYS.nit)}" placeholder="Ej: 900123456-7" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Dirección</label>
            <input class="form-input" id="doc-direccion" value="${cfg(KEYS.direccion_emp)}" placeholder="Dirección principal" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Teléfono</label>
            <input class="form-input" id="doc-telefono" value="${cfg(KEYS.telefono_emp)}" placeholder="Teléfono de contacto" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Email</label>
            <input class="form-input" id="doc-email" value="${cfg(KEYS.email_emp)}" placeholder="correo@empresa.com" />
          </div>
          <div class="form-group" style="margin:0">
            <label class="form-label">Régimen fiscal</label>
            <select class="form-input" id="doc-regimen">
              <option value="" ${!cfg(KEYS.regimen)?'selected':''}>— Selecciona —</option>
              <option value="Régimen Simplificado" ${cfg(KEYS.regimen)==='Régimen Simplificado'?'selected':''}>Régimen Simplificado</option>
              <option value="Régimen Común" ${cfg(KEYS.regimen)==='Régimen Común'?'selected':''}>Régimen Común</option>
            </select>
          </div>
        </div>
        <div id="doc-empresa-msg" style="display:none;margin:0 16px 16px"></div>
      </div>

      <!-- ═══ CÁMARA DE COMERCIO ═══ -->
      <div class="table-container" style="margin-bottom:16px">
        <div class="table-header">
          <span class="table-title">CÁMARA DE COMERCIO</span>
          <span style="font-family:var(--font-mono);font-size:11px;color:${estCC.color}">${estCC.label}</span>
        </div>
        <div style="padding:16px">

          <!-- Estado visual -->
          ${ccVenc ? `
          <div class="alert alert-${estCC.tipo==='vencido'?'error':estCC.tipo==='proximo'?'':'success'}"
               style="margin-bottom:14px;background:${estCC.tipo==='vigente'?'rgba(61,220,132,0.08)':''};
                      border-color:${estCC.color};color:${estCC.color}">
            ${estCC.tipo==='vencido'?'⚠':estCC.tipo==='proximo'?'⏰':'✓'} ${estCC.label}
            ${estCC.tipo==='proximo'?'— Renueva la Cámara de Comercio antes de que venza.':''}
            ${estCC.tipo==='vencido'?'— Este documento está vencido. Debes renovarlo inmediatamente.':''}
          </div>` : ''}

          <!-- Zona de carga PDF -->
          <div id="cc-drop-zone" style="border:2px dashed var(--border);border-radius:6px;
               padding:28px;text-align:center;cursor:pointer;transition:border-color 0.2s;
               margin-bottom:16px"
               onclick="document.getElementById('cc-pdf-input').click()"
               ondragover="event.preventDefault();this.style.borderColor='var(--accent)'"
               ondragleave="this.style.borderColor='var(--border)'"
               ondrop="handleDropCC(event)">
            <div style="font-size:28px;margin-bottom:8px">📄</div>
            <div style="font-family:var(--font-mono);font-size:12px;color:var(--text-secondary)">
              ${ccPdf ? `✓ ${ccPdf}` : 'Arrastra el PDF aquí o haz clic para seleccionar'}
            </div>
            <div style="font-size:11px;color:var(--text-muted);margin-top:4px">
              Cámara de Comercio en formato PDF
            </div>
            <input type="file" id="cc-pdf-input" accept=".pdf" style="display:none"
              onchange="procesarPDFCamara(this.files[0])"/>
          </div>

          <div id="cc-procesando" style="display:none;text-align:center;color:var(--text-muted);
               font-family:var(--font-mono);font-size:12px;padding:12px">
            <div class="loading-spinner" style="margin:0 auto 8px"></div>
            Leyendo el PDF...
          </div>

          <!-- Datos extraídos / editables -->
          <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">N° Matrícula</label>
              <input class="form-input" id="cc-matricula" value="${cfg(KEYS.cc_matricula)}" placeholder="Ej: 12345678" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Fecha expedición</label>
              <input class="form-input" id="cc-expedicion" value="${cfg(KEYS.cc_expedicion)}" placeholder="dd/mm/yyyy" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Fecha vencimiento *</label>
              <input class="form-input" id="cc-vencimiento" value="${cfg(KEYS.cc_vencimiento)}" placeholder="dd/mm/yyyy" />
            </div>
          </div>
          <div style="margin-top:12px;display:flex;justify-content:flex-end">
            <button class="btn btn-primary" style="padding:6px 16px;font-size:12px"
              onclick="guardarCC()">Guardar Cámara de Comercio</button>
          </div>
        </div>
      </div>

      <!-- ═══ RUT ═══ -->
      <div class="table-container" style="margin-bottom:16px">
        <div class="table-header">
          <span class="table-title">RUT — REGISTRO ÚNICO TRIBUTARIO</span>
          <span style="font-family:var(--font-mono);font-size:11px;color:var(--green)">
            ${cfg(KEYS.rut_actualizacion) ? '✓ Cargado — ' + cfg(KEYS.rut_actualizacion) : 'Sin cargar'}
          </span>
        </div>
        <div style="padding:16px">

          <!-- Zona de carga PDF -->
          <div id="rut-drop-zone" style="border:2px dashed var(--border);border-radius:6px;
               padding:28px;text-align:center;cursor:pointer;transition:border-color 0.2s;
               margin-bottom:16px"
               onclick="document.getElementById('rut-pdf-input').click()"
               ondragover="event.preventDefault();this.style.borderColor='var(--accent)'"
               ondragleave="this.style.borderColor='var(--border)'"
               ondrop="handleDropRUT(event)">
            <div style="font-size:28px;margin-bottom:8px">📋</div>
            <div style="font-family:var(--font-mono);font-size:12px;color:var(--text-secondary)">
              ${rutPdf ? `✓ ${rutPdf}` : 'Arrastra el PDF aquí o haz clic para seleccionar'}
            </div>
            <div style="font-size:11px;color:var(--text-muted);margin-top:4px">
              RUT en formato PDF
            </div>
            <input type="file" id="rut-pdf-input" accept=".pdf" style="display:none"
              onchange="procesarPDFRUT(this.files[0])"/>
          </div>

          <div id="rut-procesando" style="display:none;text-align:center;color:var(--text-muted);
               font-family:var(--font-mono);font-size:12px;padding:12px">
            <div class="loading-spinner" style="margin:0 auto 8px"></div>
            Leyendo el PDF...
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Actividad económica (CIIU)</label>
              <input class="form-input" id="rut-actividad" value="${cfg(KEYS.rut_actividad)}" placeholder="Ej: 4711 - Comercio al por menor" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Fecha última actualización</label>
              <input class="form-input" id="rut-actualizacion" value="${cfg(KEYS.rut_actualizacion)}" placeholder="dd/mm/yyyy" />
            </div>
          </div>
          <div style="margin-top:12px;display:flex;justify-content:flex-end">
            <button class="btn btn-primary" style="padding:6px 16px;font-size:12px"
              onclick="guardarRUT()">Guardar RUT</button>
          </div>
        </div>
      </div>

      <div id="doc-msg-global" style="display:none" class="alert"></div>
    </div>
  `;
};

// ============================================================
//  DRAG & DROP
// ============================================================
window.handleDropCC = function(e) {
  e.preventDefault();
  document.getElementById('cc-drop-zone').style.borderColor = 'var(--border)';
  const file = e.dataTransfer.files[0];
  if (file && file.type === 'application/pdf') procesarPDFCamara(file);
  else mostrarMsgDoc('Solo se aceptan archivos PDF.', 'error');
};

window.handleDropRUT = function(e) {
  e.preventDefault();
  document.getElementById('rut-drop-zone').style.borderColor = 'var(--border)';
  const file = e.dataTransfer.files[0];
  if (file && file.type === 'application/pdf') procesarPDFRUT(file);
  else mostrarMsgDoc('Solo se aceptan archivos PDF.', 'error');
};

// ============================================================
//  PROCESAR PDF — CÁMARA DE COMERCIO
// ============================================================
window.procesarPDFCamara = async function(file) {
  if (!file) return;
  document.getElementById('cc-procesando').style.display = 'block';
  document.getElementById('cc-drop-zone').style.borderColor = 'var(--accent)';

  const texto = await extraerTextoPDF(file);
  const datos = parsearCamaraComercio(texto);

  document.getElementById('cc-procesando').style.display = 'none';

  // Nombre del archivo en la zona de carga
  document.querySelector('#cc-drop-zone .table-title, #cc-drop-zone div:nth-child(2)').textContent =
    '✓ ' + file.name;

  // Rellena campos con lo extraído (si hay)
  if (datos.nit)           document.getElementById('doc-nit').value           = datos.nit;
  if (datos.razon_social)  document.getElementById('doc-razon-social').value  = datos.razon_social;
  if (datos.cc_matricula)  document.getElementById('cc-matricula').value       = datos.cc_matricula;
  if (datos.cc_expedicion) document.getElementById('cc-expedicion').value      = datos.cc_expedicion;
  if (datos.cc_vencimiento)document.getElementById('cc-vencimiento').value     = datos.cc_vencimiento;
  if (datos.direccion)     document.getElementById('doc-direccion').value      = datos.direccion;

  // Guarda nombre del PDF en config
  DB.Config.set(KEYS.cc_pdf, file.name);

  const extraidos = Object.keys(datos).length;
  if (extraidos > 0) {
    mostrarMsgDoc(
      `✓ PDF leído. Se extrajeron ${extraidos} campo(s) automáticamente. Verifica los datos y guarda.`,
      'success'
    );
  } else {
    mostrarMsgDoc(
      '⚠ No se pudo extraer texto del PDF (posiblemente es una imagen escaneada). Ingresa los datos manualmente.',
      'info'
    );
  }
};

// ============================================================
//  PROCESAR PDF — RUT
// ============================================================
window.procesarPDFRUT = async function(file) {
  if (!file) return;
  document.getElementById('rut-procesando').style.display = 'block';
  document.getElementById('rut-drop-zone').style.borderColor = 'var(--accent)';

  const texto = await extraerTextoPDF(file);
  const datos = parsearRUT(texto);

  document.getElementById('rut-procesando').style.display = 'none';

  if (datos.nit)             document.getElementById('doc-nit').value           = datos.nit;
  if (datos.razon_social)    document.getElementById('doc-razon-social').value  = datos.razon_social;
  if (datos.rut_actividad)   document.getElementById('rut-actividad').value     = datos.rut_actividad;
  if (datos.rut_actualizacion)document.getElementById('rut-actualizacion').value= datos.rut_actualizacion;
  if (datos.regimen)         document.getElementById('doc-regimen').value       = datos.regimen;

  DB.Config.set(KEYS.rut_pdf, file.name);

  const extraidos = Object.keys(datos).length;
  if (extraidos > 0) {
    mostrarMsgDoc(
      `✓ PDF leído. Se extrajeron ${extraidos} campo(s) del RUT. Verifica y guarda.`,
      'success'
    );
  } else {
    mostrarMsgDoc(
      '⚠ No se pudo extraer texto del PDF. Ingresa los datos manualmente.',
      'info'
    );
  }
};

// ============================================================
//  GUARDAR DATOS
// ============================================================
window.guardarDatosEmpresa = function() {
  const razon  = document.getElementById('doc-razon-social').value.trim();
  const nit    = document.getElementById('doc-nit').value.trim();
  const dir    = document.getElementById('doc-direccion').value.trim();
  const tel    = document.getElementById('doc-telefono').value.trim();
  const email  = document.getElementById('doc-email').value.trim();
  const regimen= document.getElementById('doc-regimen').value;

  if (!razon || !nit) {
    mostrarMsgDoc('La razón social y el NIT son obligatorios.', 'error');
    return;
  }

  DB.Config.set(KEYS.razon_social,  razon);
  DB.Config.set(KEYS.nit,           nit);
  DB.Config.set(KEYS.direccion_emp, dir);
  DB.Config.set(KEYS.telefono_emp,  tel);
  DB.Config.set(KEYS.email_emp,     email);
  DB.Config.set(KEYS.regimen,       regimen);
  // También actualiza nombre_empresa para que aparezca en facturas
  DB.Config.set('nombre_empresa', razon);
  DB.saveDB();

  mostrarMsgDoc('✓ Datos de la empresa actualizados correctamente.', 'success');
  if (typeof showToast === 'function') showToast('Datos de empresa guardados');
};

window.guardarCC = function() {
  const matricula   = document.getElementById('cc-matricula').value.trim();
  const expedicion  = document.getElementById('cc-expedicion').value.trim();
  const vencimiento = document.getElementById('cc-vencimiento').value.trim();

  DB.Config.set(KEYS.cc_matricula,   matricula);
  DB.Config.set(KEYS.cc_expedicion,  expedicion);
  DB.Config.set(KEYS.cc_vencimiento, vencimiento);
  DB.saveDB();

  // Verifica y crea alertas
  verificarAlertas();

  // Recarga la sección para actualizar el estado visual
  document.getElementById('seccion-documentos').innerHTML = renderSeccionDocumentos();
  mostrarMsgDoc('✓ Cámara de Comercio guardada.', 'success');
  if (typeof showToast === 'function') showToast('Cámara de Comercio guardada');
};

window.guardarRUT = function() {
  const actividad     = document.getElementById('rut-actividad').value.trim();
  const actualizacion = document.getElementById('rut-actualizacion').value.trim();

  DB.Config.set(KEYS.rut_actividad,    actividad);
  DB.Config.set(KEYS.rut_actualizacion,actualizacion);
  DB.saveDB();

  document.getElementById('seccion-documentos').innerHTML = renderSeccionDocumentos();
  mostrarMsgDoc('✓ RUT guardado correctamente.', 'success');
  if (typeof showToast === 'function') showToast('RUT guardado');
};

function mostrarMsgDoc(texto, tipo) {
  const tipos = { success:'alert-success', error:'alert-error', info:'alert-info' };
  const el = document.getElementById('doc-msg-global');
  if (!el) { if(typeof showToast==='function') showToast(texto); return; }
  el.className = 'alert ' + (tipos[tipo] || 'alert-info');
  el.textContent = texto;
  el.style.display = 'block';
  setTimeout(() => { if(el) el.style.display = 'none'; }, 6000);
}

// ============================================================
//  VERIFICACIÓN AL ARRANCAR
// ============================================================
window.verificarDocumentosAlArrancar = function() {
  try {
    initDocumentosConfig();
    const ccVenc = DB.Config.get(KEYS.cc_vencimiento);
    if (!ccVenc) return;
    const est = estadoDocumento(ccVenc);
    if (est.tipo === 'vencido' || est.tipo === 'proximo') {
      // Solo crea la notificación una vez al día
      const hoy = new Date().toISOString().substring(0, 10);
      const yaNotificado = DB.dbGet(
        "SELECT id FROM notificaciones WHERE titulo LIKE '%Cámara de Comercio%' AND creado_en LIKE ?",
        [hoy + '%']
      );
      if (!yaNotificado) verificarAlertas();
    }
  } catch(e) {}
};
