/**
 * api-dian.js — Integración con Factus API (proveedor DIAN autorizado)
 * 
 * CONFIGURACIÓN REQUERIDA:
 * 1. Crear cuenta en factus.com.co
 * 2. Ir a Configuración → API → copiar client_id y client_secret
 * 3. Pegar las credenciales en Configuración → API e Integraciones
 * 
 * Documentación Factus: https://docs.factus.com.co
 */

// ============================================================
//  CONFIGURACIÓN
// ============================================================
const FACTUS_CONFIG = {
  sandbox:    true,   // true = pruebas, false = producción
  baseUrl:    {
    sandbox:    'https://api-sandbox.factus.com.co',
    production: 'https://api.factus.com.co',
  },
  tokenKey:   'factus_token',
  tokenExpKey:'factus_token_exp',
};

function getBaseUrl() {
  return FACTUS_CONFIG.sandbox
    ? FACTUS_CONFIG.baseUrl.sandbox
    : FACTUS_CONFIG.baseUrl.production;
}

function getCredenciales() {
  return {
    client_id:     DB.Config.get('factus_client_id')     || '',
    client_secret: DB.Config.get('factus_client_secret') || '',
  };
}

// ============================================================
//  AUTENTICACIÓN — OAuth2 Client Credentials
// ============================================================
async function factusGetToken() {
  // Reutiliza token si aún es válido
  const tokenGuardado = localStorage.getItem(FACTUS_CONFIG.tokenKey);
  const expGuardado   = localStorage.getItem(FACTUS_CONFIG.tokenExpKey);
  if (tokenGuardado && expGuardado && Date.now() < parseInt(expGuardado)) {
    return tokenGuardado;
  }

  const creds = getCredenciales();
  if (!creds.client_id || !creds.client_secret) {
    throw new Error('Credenciales de Factus no configuradas. Ve a Configuración → API e Integraciones.');
  }

  const res = await fetch(`${getBaseUrl()}/oauth/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      grant_type:    'client_credentials',
      client_id:     creds.client_id,
      client_secret: creds.client_secret,
    }),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error('Error de autenticación Factus: ' + (err.message || res.status));
  }

  const data = await res.json();
  const token   = data.access_token;
  const expMs   = Date.now() + (data.expires_in - 60) * 1000;

  localStorage.setItem(FACTUS_CONFIG.tokenKey,    token);
  localStorage.setItem(FACTUS_CONFIG.tokenExpKey, expMs.toString());

  return token;
}

// ============================================================
//  ENVIAR FACTURA A FACTUS / DIAN
// ============================================================
async function factusEnviarFactura(facturaId) {
  const factura = DB.dbGet("SELECT * FROM facturas WHERE id = ?", [facturaId]);
  const detalle = DB.dbQuery("SELECT * FROM facturas_detalle WHERE factura_id = ?", [facturaId]);

  if (!factura) throw new Error('Factura no encontrada.');
  if (!detalle.length) throw new Error('La factura no tiene ítems.');

  // Datos de la empresa emisora
  const empresa = {
    nit:     (DB.Config.get('nit') || '').replace(/[^0-9]/g, ''),
    razon:   DB.Config.get('razon_social') || DB.Config.get('nombre_empresa') || '',
    dir:     DB.Config.get('direccion_empresa') || '',
    email:   DB.Config.get('email_empresa') || '',
    regimen: DB.Config.get('regimen_fiscal') || 'Régimen Simplificado',
  };

  if (!empresa.nit || !empresa.razon) {
    throw new Error('Faltan datos de la empresa. Ve a Configuración → Mis documentos.');
  }

  // Construir payload según estructura Factus API
  const payload = {
    document: {
      numbering_range_id: DB.Config.get('factus_numbering_range_id') || '1',
      reference_code:     factura.numero,
      observation:        factura.notas || '',
      payment_method_code: mapearMedioPago(factura.medio_pago),
      due_date:           factura.fecha_vencimiento || factura.fecha_emision,
    },
    customer: {
      identification:      (factura.cliente_nit || '').replace(/[^0-9]/g, '') || '222222222222',
      dv:                  calcularDV(factura.cliente_nit || ''),
      company:             factura.cliente_nombre,
      trade_name:          factura.cliente_nombre,
      names:               factura.cliente_nombre,
      address:             factura.cliente_dir || 'Sin dirección',
      email:               factura.cliente_email || '',
      phone:               factura.cliente_tel || '',
      identification_document_id: factura.cliente_nit?.includes('-') ? 6 : 13,
      municipality_id:     149, // Bogotá por defecto
    },
    items: detalle.map((d, i) => ({
      code_reference: `ITEM-${String(i+1).padStart(3,'0')}`,
      name:           d.descripcion,
      quantity:       d.cantidad,
      discount_rate:  d.descuento || 0,
      price:          d.precio_unit,
      tax_rate:       String(d.iva_pct || 19) + '.00',
      unit_measure_id: 70,  // unidad
      standard_code_id: 1,
      is_excluded:    0,
      tribute_id:     1,    // IVA
    })),
  };

  const token = await factusGetToken();

  const res = await fetch(`${getBaseUrl()}/v1/bills/validate`, {
    method: 'POST',
    headers: {
      'Content-Type':  'application/json',
      'Authorization': `Bearer ${token}`,
      'Accept':        'application/json',
    },
    body: JSON.stringify(payload),
  });

  const data = await res.json();

  if (!res.ok) {
    const msg = data?.message || data?.errors?.[0]?.message || JSON.stringify(data);
    throw new Error('Error Factus: ' + msg);
  }

  // Guardar respuesta DIAN en la factura
  const cufeReal = data.data?.bill?.cufe || factura.cufe;
  const qrReal   = data.data?.bill?.qr   || '';
  const estado   = data.data?.bill?.status_name || 'Validada';

  DB.dbRun(
    "UPDATE facturas SET cufe = ?, estado_dian = ?, qr_dian = ? WHERE id = ?",
    [cufeReal, estado, qrReal, facturaId]
  );

  // Migración por si la columna no existe
  try { DB.dbRun("ALTER TABLE facturas ADD COLUMN estado_dian TEXT"); } catch(e) {}
  try { DB.dbRun("ALTER TABLE facturas ADD COLUMN qr_dian TEXT"); }    catch(e) {}

  DB.dbRun(
    "UPDATE facturas SET cufe = ?, estado_dian = ?, qr_dian = ? WHERE id = ?",
    [cufeReal, estado, qrReal, facturaId]
  );
  DB.saveDB();

  DB.Notificaciones.create('exito', 'Factura validada por DIAN',
    `La factura ${factura.numero} fue validada. CUFE: ${cufeReal.substring(0,20)}...`
  );
  if (typeof updateNotifBadge === 'function') updateNotifBadge();

  return { cufe: cufeReal, qr: qrReal, estado, data };
}

// ============================================================
//  DESCARGAR PDF DESDE FACTUS
// ============================================================
async function factusDescargarPDF(facturaId) {
  const factura = DB.dbGet("SELECT * FROM facturas WHERE id = ?", [facturaId]);
  if (!factura?.cufe) throw new Error('La factura no tiene CUFE. Valídala primero con la DIAN.');

  const token = await factusGetToken();
  const res = await fetch(`${getBaseUrl()}/v1/bills/download-pdf/${factura.cufe}`, {
    headers: { 'Authorization': `Bearer ${token}` }
  });

  if (!res.ok) throw new Error('No se pudo descargar el PDF de Factus.');

  const blob = await res.blob();
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `${factura.numero}.pdf`;
  a.click();
  URL.revokeObjectURL(url);
}

// ============================================================
//  HELPERS
// ============================================================
function mapearMedioPago(medio) {
  const mapa = {
    efectivo:        10,
    transferencia:   42,
    tarjeta_credito: 48,
    tarjeta_debito:  49,
    cheque:          20,
    otro:            1,
  };
  return mapa[medio] || 10;
}

function calcularDV(nit) {
  if (!nit) return '0';
  const n = nit.replace(/[^0-9]/g, '');
  const primos = [71,67,59,53,47,43,41,37,29,23,19,17,13,7,3];
  let suma = 0;
  const digits = n.split('').reverse();
  digits.forEach((d, i) => { if (primos[i]) suma += parseInt(d) * primos[i]; });
  const residuo = suma % 11;
  return residuo < 2 ? residuo.toString() : (11 - residuo).toString();
}

// ============================================================
//  VISTA — sección de configuración API
// ============================================================
window.renderSeccionAPIDIAN = function() {
  const clientId    = DB.Config.get('factus_client_id')     || '';
  const clientSecret= DB.Config.get('factus_client_secret') || '';
  const numRangeId  = DB.Config.get('factus_numbering_range_id') || '';
  const sandbox     = DB.Config.get('factus_sandbox') !== 'false';

  return `
    <div style="margin-top:28px">
      <div style="margin-bottom:14px">
        <div style="font-family:var(--font-mono);font-size:13px;font-weight:600;color:var(--text-primary)">
          Factus API — Facturación Electrónica DIAN
        </div>
        <div style="font-size:12px;color:var(--text-muted);margin-top:2px">
          Proveedor tecnológico autorizado por la DIAN. 
          <a href="https://factus.com.co" target="_blank" style="color:var(--accent)">factus.com.co</a>
          — Plan gratuito hasta 50 facturas/mes.
        </div>
      </div>

      <div class="table-container" style="margin-bottom:16px">
        <div class="table-header"><span class="table-title">CREDENCIALES API</span></div>
        <div style="padding:16px;display:flex;flex-direction:column;gap:12px">

          <div style="display:flex;align-items:center;gap:10px;padding:10px 14px;
                      background:var(--bg-elevated);border-radius:4px;border:1px solid var(--border)">
            <span style="font-size:18px">${sandbox ? '🧪' : '🚀'}</span>
            <div>
              <div style="font-size:12px;font-weight:600;color:${sandbox?'var(--yellow)':'var(--green)'}">
                Modo: ${sandbox ? 'SANDBOX (Pruebas)' : 'PRODUCCIÓN'}
              </div>
              <div style="font-size:11px;color:var(--text-muted)">
                ${sandbox ? 'Las facturas NO se envían a la DIAN real.' : 'Las facturas SE envían a la DIAN real.'}
              </div>
            </div>
            <button class="btn btn-outline" style="margin-left:auto;padding:4px 12px;font-size:11px"
              onclick="toggleSandboxFactus()">
              Cambiar a ${sandbox ? 'Producción' : 'Sandbox'}
            </button>
          </div>

          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group" style="margin:0">
              <label class="form-label">Client ID *</label>
              <input class="form-input" id="factus-client-id" 
                value="${clientId}" placeholder="Tu client_id de Factus" />
            </div>
            <div class="form-group" style="margin:0">
              <label class="form-label">Client Secret *</label>
              <input class="form-input" id="factus-client-secret" type="password"
                value="${clientSecret}" placeholder="Tu client_secret de Factus" />
            </div>
          </div>

          <div class="form-group" style="margin:0">
            <label class="form-label">ID Rango de Numeración</label>
            <input class="form-input" id="factus-numbering-range" 
              value="${numRangeId}" placeholder="Ej: 1 (ver en Factus → Numeración)" style="max-width:200px"/>
            <div style="font-size:11px;color:var(--text-muted);margin-top:4px">
              Encuéntralo en Factus → Configuración → Rangos de numeración
            </div>
          </div>

          <div id="factus-test-msg" style="display:none" class="alert"></div>

          <div style="display:flex;gap:8px">
            <button class="btn btn-outline" onclick="testConexionFactus()">
              🔌 Probar conexión
            </button>
            <button class="btn btn-primary" onclick="guardarConfigFactus()">
              Guardar credenciales
            </button>
          </div>
        </div>
      </div>

      <!-- Guía de pasos -->
      <div class="table-container" style="padding:16px">
        <div style="font-family:var(--font-mono);font-size:10px;letter-spacing:0.1em;
                    color:var(--text-muted);margin-bottom:12px">CÓMO CONFIGURAR</div>
        ${[
          ['1', 'Crea tu cuenta gratuita en factus.com.co'],
          ['2', 'Registra tu empresa con el NIT (debe coincidir con el NIT en Mis documentos)'],
          ['3', 'Ve a Configuración → API y copia el Client ID y Client Secret'],
          ['4', 'Ve a Configuración → Rangos de numeración y copia el ID del rango'],
          ['5', 'Pega las credenciales aquí y haz clic en "Probar conexión"'],
          ['6', 'Cuando funcione en Sandbox, cambia a Producción para facturas reales'],
        ].map(([n, t]) => `
          <div style="display:flex;gap:10px;margin-bottom:10px;align-items:flex-start">
            <div style="background:var(--accent);color:#fff;border-radius:50%;width:22px;height:22px;
                        display:flex;align-items:center;justify-content:center;
                        font-family:var(--font-mono);font-size:11px;font-weight:600;flex-shrink:0">${n}</div>
            <div style="font-size:13px;color:var(--text-secondary);padding-top:2px">${t}</div>
          </div>`).join('')}
      </div>
    </div>
  `;
};

// ── Guardar config ──
window.guardarConfigFactus = function() {
  const clientId    = document.getElementById('factus-client-id').value.trim();
  const clientSecret= document.getElementById('factus-client-secret').value.trim();
  const numRange    = document.getElementById('factus-numbering-range').value.trim();

  if (!clientId || !clientSecret) {
    mostrarMsgFactus('Ingresa el Client ID y Client Secret.', 'error'); return;
  }

  DB.dbRun("INSERT OR REPLACE INTO configuracion (clave,valor,descripcion) VALUES (?,?,?)",
    ['factus_client_id', clientId, 'Factus API Client ID']);
  DB.dbRun("INSERT OR REPLACE INTO configuracion (clave,valor,descripcion) VALUES (?,?,?)",
    ['factus_client_secret', clientSecret, 'Factus API Client Secret']);
  if (numRange) DB.dbRun("INSERT OR REPLACE INTO configuracion (clave,valor,descripcion) VALUES (?,?,?)",
    ['factus_numbering_range_id', numRange, 'Factus Numbering Range ID']);
  DB.saveDB();

  localStorage.removeItem(FACTUS_CONFIG.tokenKey);
  localStorage.removeItem(FACTUS_CONFIG.tokenExpKey);
  mostrarMsgFactus('✓ Credenciales guardadas correctamente.', 'success');
  if (typeof showToast === 'function') showToast('Credenciales Factus guardadas');
};

window.toggleSandboxFactus = function() {
  const actual = DB.Config.get('factus_sandbox') !== 'false';
  DB.dbRun("INSERT OR REPLACE INTO configuracion (clave,valor,descripcion) VALUES (?,?,?)",
    ['factus_sandbox', (!actual).toString(), 'Modo sandbox Factus']);
  DB.saveDB();
  localStorage.removeItem(FACTUS_CONFIG.tokenKey);
  document.getElementById('seccion-api-dian').innerHTML = renderSeccionAPIDIAN();
};

window.testConexionFactus = async function() {
  mostrarMsgFactus('Probando conexión...', 'info');
  try {
    await guardarConfigFactus();
    await factusGetToken();
    mostrarMsgFactus('✓ Conexión exitosa con Factus API. Credenciales válidas.', 'success');
  } catch(err) {
    mostrarMsgFactus('✗ ' + err.message, 'error');
  }
};

function mostrarMsgFactus(texto, tipo) {
  const el = document.getElementById('factus-test-msg');
  if (!el) return;
  const cls = { success:'alert-success', error:'alert-error', info:'alert-info' };
  el.className = 'alert ' + (cls[tipo] || 'alert-info');
  el.textContent = texto;
  el.style.display = 'block';
}

// ── Botón enviar a DIAN desde la factura ──
window.enviarFacturaADIAN = async function(facturaId) {
  const btn = document.getElementById(`btn-dian-${facturaId}`);
  if (btn) { btn.textContent = '⏳ Enviando...'; btn.disabled = true; }

  try {
    const result = await factusEnviarFactura(facturaId);
    if (typeof showToast === 'function')
      showToast('✓ Factura validada por DIAN — ' + result.estado);
    if (typeof renderListaFacturas === 'function') renderListaFacturas();
  } catch(err) {
    if (typeof showToast === 'function') showToast('✗ ' + err.message);
    console.error('Error DIAN:', err);
    if (btn) { btn.textContent = '🏛 Enviar a DIAN'; btn.disabled = false; }
  }
};

window.descargarPDFFactus = async function(facturaId) {
  try {
    await factusDescargarPDF(facturaId);
  } catch(err) {
    if (typeof showToast === 'function') showToast('✗ ' + err.message);
  }
};

window.FactusAPI = { enviarFactura: factusEnviarFactura, getToken: factusGetToken };
