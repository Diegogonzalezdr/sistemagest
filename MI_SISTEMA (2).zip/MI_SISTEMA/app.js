/**
 * app.js — Router principal y vistas del sistema
 * 
 * Sistema de rutas 100% en JS puro sin frameworks.
 * Cada vista es una función que retorna HTML.
 */

// ============================================================
//  ROUTER
// ============================================================
const Router = {
  current: null,

  routes: {
    'dashboard':     viewDashboard,
    'reportes':      viewReportes,
    'facturacion':   viewFacturacion,
    'productos':     viewProductos,
    'clientes':      viewClientes,
    'proveedores':   viewProveedores,
    'ventas':        viewVentas,
    'compras':       viewCompras,
    'facturas-proveedores': viewFacturasProveedores,
    'movimientos':   viewMovimientos,
    'notificaciones':viewNotificaciones,
    'configuracion': viewConfiguracion,
    'db-test':       viewDBTest,
  },

  navigate(route) {
    if (this.current === route) return;
    this.current = route;

    // Actualiza nav activo
    document.querySelectorAll('.nav-item').forEach(el => {
      el.classList.toggle('active', el.dataset.route === route);
    });

    // Actualiza breadcrumb
    const labels = {
      dashboard: 'Dashboard', reportes: 'Reportes', facturacion: 'Facturación', productos: 'Productos', 'facturas-proveedores': 'Facturas Recibidas', clientes: 'Clientes',
      proveedores: 'Proveedores', ventas: 'Ventas', compras: 'Compras',
      movimientos: 'Movimientos', notificaciones: 'Notificaciones',
      configuracion: 'Configuración', 'db-test': 'Test DB'
    };
    document.getElementById('breadcrumb-text').textContent = labels[route] || route;

    // Renderiza la vista
    const fn = this.routes[route];
    const area = document.getElementById('content-area');
    area.innerHTML = fn ? fn() : `<div class="alert alert-error">Vista "${route}" no encontrada.</div>`;

    // Aplica restricciones de rol en cada navegación
    if (typeof aplicarRestriccionesRol === 'function') aplicarRestriccionesRol();

    // Llama al controlador de la vista si existe
    const controllers = {
      dashboard: initDashboard,
      productos: initProductos,
      clientes: initClientes,
      proveedores: initProveedores,
      notificaciones: initNotificaciones,
      configuracion: initConfiguracion,
      reportes: initReportes,
      facturacion: initFacturacion,
      ventas: initVentas,
      compras: initCompras,
      'facturas-proveedores': initFacturasProveedores,
      'db-test': initDBTest,
    };
    if (controllers[route]) controllers[route]();

    // Actualiza badge de notificaciones
    updateNotifBadge();
  }
};

// ============================================================
//  VISTAS (HTML como strings)
// ============================================================

function viewDashboard() {
  return `
    <div class="page-header">
      <div>
        <div class="page-title">Dashboard</div>
        <div class="page-subtitle">Resumen del sistema</div>
      </div>
    </div>
    <div class="cards-grid" id="dash-cards">
      <div class="card"><div class="card-label">PRODUCTOS</div><div class="card-value accent" id="d-productos">—</div></div>
      <div class="card"><div class="card-label">CLIENTES</div><div class="card-value green" id="d-clientes">—</div></div>
      <div class="card"><div class="card-label">PROVEEDORES</div><div class="card-value" id="d-proveedores">—</div></div>
      <div class="card"><div class="card-label">STOCK BAJO</div><div class="card-value red" id="d-stock-bajo">—</div></div>
    </div>
    <div class="table-container" style="margin-bottom:20px">
      <div class="table-header">
        <span class="table-title">PRODUCTOS CON STOCK BAJO</span>
      </div>
      <table>
        <thead><tr><th>Código</th><th>Producto</th><th>Stock</th><th>Mínimo</th></tr></thead>
        <tbody id="dash-low-stock"></tbody>
      </table>
    </div>

    <div class="table-container">
      <div class="table-header">
        <span class="table-title">ABONOS A PROVEEDORES — HOY</span>
        <span style="font-family:var(--font-mono);font-size:11px;color:var(--text-muted)">
          ${new Date().toLocaleDateString('es-CO')}
        </span>
      </div>
      <table>
        <thead>
          <tr>
            <th>Proveedor</th>
            <th>N° Factura</th>
            <th>Monto abonado</th>
            <th>Nota</th>
          </tr>
        </thead>
        <tbody id="dash-abonos"></tbody>
      </table>
    </div>`;
}

function viewProductos() {
  return `
    <div class="page-header">
      <div>
        <div class="page-title">Productos</div>
        <div class="page-subtitle">Gestión de inventario</div>
      </div>
      <button class="btn btn-primary" id="btn-nuevo-producto">+ Nuevo Producto</button>
    </div>
    <div class="table-container">
      <div class="table-header">
        <span class="table-title">LISTADO DE PRODUCTOS</span>
        <input class="form-input" style="width:200px" placeholder="Buscar..." id="search-productos" />
      </div>
      <table>
        <thead><tr><th>Código</th><th>Nombre</th><th>Categoría</th><th>P.Venta</th><th>Stock</th><th>Estado</th><th>Acciones</th></tr></thead>
        <tbody id="tabla-productos"></tbody>
      </table>
    </div>

    <!-- Modal Producto -->
    <div class="modal-overlay" id="modal-producto">
      <div class="modal">
        <div class="modal-header">
          <span class="modal-title" id="modal-producto-title">Nuevo Producto</span>
          <button class="modal-close" data-close="modal-producto">×</button>
        </div>
        <div class="modal-body">
          <input type="hidden" id="prod-id" />
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group"><label class="form-label">Código *</label><input class="form-input" id="prod-codigo" /></div>
            <div class="form-group"><label class="form-label">Categoría</label><input class="form-input" id="prod-categoria" /></div>
          </div>
          <div class="form-group"><label class="form-label">Nombre *</label><input class="form-input" id="prod-nombre" /></div>
          <div class="form-group"><label class="form-label">Descripción</label><input class="form-input" id="prod-descripcion" /></div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group"><label class="form-label">P. Compra</label><input class="form-input" type="number" id="prod-pcompra" value="0" /></div>
            <div class="form-group"><label class="form-label">P. Venta</label><input class="form-input" type="number" id="prod-pventa" value="0" /></div>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
            <div class="form-group"><label class="form-label">Stock Actual</label><input class="form-input" type="number" id="prod-stock" value="0" min="0" /></div>
            <div class="form-group"><label class="form-label">Stock Mínimo</label><input class="form-input" type="number" id="prod-stockmin" value="5" min="0" /></div>
          </div>
        </div>
        <div class="modal-footer">
          <button class="btn btn-outline" data-close="modal-producto">Cancelar</button>
          <button class="btn btn-primary" id="btn-guardar-producto">Guardar</button>
        </div>
      </div>
    </div>`;
}

// viewClientes definida en modules/clientes.js
// viewProveedores definida en modules/proveedores.js

// viewVentas está definida en modules/ventas.js

// viewCompras está definida en modules/compras.js

function viewMovimientos() {
  const movs = DB.dbQuery('SELECT m.*, p.nombre as producto FROM movimientos m LEFT JOIN productos p ON p.id = m.producto_id ORDER BY m.creado_en DESC LIMIT 100');
  const rows = movs.length
    ? movs.map(m => `<tr>
        <td style="font-family:var(--font-mono);font-size:11px">${m.creado_en?.substring(0,16)||''}</td>
        <td>${m.producto}</td>
        <td><span class="tag ${m.tipo==='entrada'?'tag-green':m.tipo==='salida'?'tag-red':'tag-yellow'}">${m.tipo}</span></td>
        <td style="font-family:var(--font-mono)">${m.cantidad > 0 ? '+' : ''}${m.cantidad}</td>
        <td style="font-family:var(--font-mono)">${m.stock_antes} → ${m.stock_despues}</td>
        <td>${m.referencia||'—'}</td>
      </tr>`).join('')
    : '<tr><td colspan="6" style="text-align:center;color:var(--text-muted)">Sin movimientos registrados</td></tr>';

  return `
    <div class="page-header">
      <div><div class="page-title">Movimientos</div><div class="page-subtitle">Trazabilidad de inventario</div></div>
    </div>
    <div class="table-container">
      <div class="table-header"><span class="table-title">HISTORIAL DE MOVIMIENTOS</span></div>
      <table>
        <thead><tr><th>Fecha</th><th>Producto</th><th>Tipo</th><th>Cantidad</th><th>Stock</th><th>Referencia</th></tr></thead>
        <tbody>${rows}</tbody>
      </table>
    </div>`;
}

function viewNotificaciones() {
  return `
    <div class="page-header">
      <div><div class="page-title">Notificaciones</div></div>
      <button class="btn btn-outline" id="btn-mark-all">Marcar todas como leídas</button>
    </div>
    <div id="notif-list"></div>`;
}

function viewConfiguracion() {
  return `
    <div class="page-header">
      <div>
        <div class="page-title">Configuración</div>
        <div class="page-subtitle">Parámetros del sistema</div>
      </div>
    </div>
    <div style="max-width:640px">
      <div class="table-container" style="margin-bottom:20px">
        <div class="table-header"><span class="table-title">PARÁMETROS GENERALES</span></div>
        <div id="config-list" style="padding:16px"></div>
      </div>
      <div id="btn-cfg-sesion-wrap">
        <button class="btn btn-outline" id="btn-cfg-sesion"
          style="width:100%;padding:12px;font-size:13px;margin-bottom:12px;
                 border-color:var(--accent);color:var(--accent)"
          onclick="toggleSeccionUsuarios()">
          ◈ Configuración de inicio de sesión
        </button>
      </div>
      <button class="btn btn-outline"
        style="width:100%;padding:12px;font-size:13px;margin-bottom:12px;
               border-color:var(--green);color:var(--green)"
        onclick="toggleSeccionDocumentos()">
        📄 Mis documentos
      </button>
      <button class="btn btn-outline"
        style="width:100%;padding:12px;font-size:13px;margin-bottom:12px;
               border-color:var(--yellow);color:var(--yellow)"
        onclick="toggleSeccionBackup()">
        💾 Copias de seguridad
      </button>
      <button class="btn btn-outline"
        style="width:100%;padding:12px;font-size:13px;margin-bottom:20px;
               border-color:var(--orange);color:var(--orange)"
        onclick="toggleSeccionIntegraciones()">
        🔌 API e Integraciones
      </button>
      <div id="seccion-usuarios" style="display:none"></div>
      <div id="seccion-documentos" style="display:none"></div>
      <div id="seccion-backup" style="display:none"></div>
      <div id="seccion-integraciones" style="display:none"></div>
    </div>`;
}

function viewDBTest() {
  return `
    <div class="page-header">
      <div><div class="page-title">Test de Base de Datos</div><div class="page-subtitle">Verificar operaciones CRUD</div></div>
    </div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:20px">
      <button class="btn btn-outline" onclick="testCRUD('create')">▶ CREATE — Insertar producto test</button>
      <button class="btn btn-outline" onclick="testCRUD('read')">▶ READ — Leer productos</button>
      <button class="btn btn-outline" onclick="testCRUD('update')">▶ UPDATE — Actualizar precio</button>
      <button class="btn btn-outline" onclick="testCRUD('delete')">▶ DELETE — Borrar producto test</button>
      <button class="btn btn-outline" onclick="testCRUD('schema')">▶ SCHEMA — Ver tablas</button>
      <button class="btn btn-danger" onclick="testCRUD('reset')">⚠ RESET — Borrar BD completa</button>
    </div>
    <div class="table-container">
      <div class="table-header"><span class="table-title">CONSOLA DE RESULTADOS</span></div>
      <div id="test-output" style="padding:16px;font-family:var(--font-mono);font-size:12px;min-height:200px;white-space:pre-wrap;color:var(--text-secondary)">
Listo. Pulsa un botón para ejecutar una operación.</div>
    </div>`;
}

// ============================================================
//  CONTROLADORES DE VISTAS
// ============================================================

function initDashboard() {
  const productos   = DB.dbQuery('SELECT COUNT(*) as n FROM productos WHERE activo=1')[0]?.n || 0;
  const clientes    = DB.dbQuery('SELECT COUNT(*) as n FROM clientes  WHERE activo=1')[0]?.n || 0;
  const proveedores = DB.dbQuery('SELECT COUNT(*) as n FROM proveedores WHERE activo=1')[0]?.n || 0;
  const stockBajo   = DB.Productos.getLowStock();

  document.getElementById('d-productos').textContent   = productos;
  document.getElementById('d-clientes').textContent    = clientes;
  document.getElementById('d-proveedores').textContent = proveedores;
  document.getElementById('d-stock-bajo').textContent  = stockBajo.length;

  const tbody = document.getElementById('dash-low-stock');
  tbody.innerHTML = stockBajo.length
    ? stockBajo.map(p => `<tr>
        <td style="font-family:var(--font-mono)">${p.codigo}</td>
        <td>${p.nombre}</td>
        <td><span class="tag tag-red">${p.stock}</span></td>
        <td style="color:var(--text-muted)">${p.stock_minimo}</td>
      </tr>`).join('')
    : '<tr><td colspan="4" style="text-align:center;color:var(--text-muted)">✓ Todos los productos tienen stock suficiente</td></tr>';

  // Reporte diario de abonos — crea tabla si no existe
  try { DB.dbRun("CREATE TABLE IF NOT EXISTS abonos_proveedores (id INTEGER PRIMARY KEY AUTOINCREMENT, factura_id INTEGER NOT NULL, proveedor_id INTEGER NOT NULL, monto REAL NOT NULL, nota TEXT, fecha TEXT NOT NULL DEFAULT (date('now')), creado_en TEXT NOT NULL DEFAULT (datetime('now')))"); } catch(e){}
  try { DB.dbRun("CREATE TABLE IF NOT EXISTS facturas_proveedores (id INTEGER PRIMARY KEY AUTOINCREMENT, proveedor_id INTEGER NOT NULL, numero_factura TEXT, fecha_expedicion TEXT, fecha_vencimiento TEXT, total REAL DEFAULT 0, abonado REAL DEFAULT 0, estado TEXT DEFAULT 'pendiente', pdf_nombre TEXT, pdf_data TEXT, notas TEXT, creado_en TEXT DEFAULT (datetime('now')))"); } catch(e){}

  const hoy = new Date().toISOString().substring(0, 10);
  try {
    const abonos = DB.dbQuery(`
      SELECT a.*, fp.numero_factura, p.nombre as proveedor_nombre,
             fp.total, fp.abonado
      FROM abonos_proveedores a
      JOIN facturas_proveedores fp ON fp.id = a.factura_id
      JOIN proveedores p ON p.id = a.proveedor_id
      WHERE a.fecha = ?
      ORDER BY a.creado_en DESC
    `, [hoy]);

    const contenedor = document.getElementById('dash-abonos');
    if (!contenedor) return;

    if (!abonos.length) {
      contenedor.innerHTML = '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:16px">Sin abonos registrados hoy</td></tr>';
    } else {
      const totalAbonado = abonos.reduce((s,a) => s + parseFloat(a.monto), 0);
      contenedor.innerHTML = abonos.map(a => `
        <tr>
          <td>${a.proveedor_nombre}</td>
          <td style="font-family:var(--font-mono);font-size:11px">${a.numero_factura||'—'}</td>
          <td style="font-family:var(--font-mono);color:var(--green)">
            +$${parseFloat(a.monto).toLocaleString('es-CO')}
          </td>
          <td style="font-size:11px;color:var(--text-muted)">${a.nota||'—'}</td>
        </tr>`).join('') +
        `<tr style="border-top:2px solid var(--border)">
          <td colspan="2" style="font-family:var(--font-mono);font-size:12px;font-weight:600;color:var(--text-primary)">
            TOTAL ABONADO HOY
          </td>
          <td style="font-family:var(--font-mono);font-size:14px;font-weight:700;color:var(--green)">
            $${totalAbonado.toLocaleString('es-CO')}
          </td>
          <td></td>
        </tr>`;
    }
  } catch(e) {
    // tabla aún no existe
  }
}

function initProductos() {
  const renderTabla = (filter = '') => {
    let prods = DB.Productos.getAll();
    if (filter) prods = prods.filter(p =>
      p.nombre.toLowerCase().includes(filter) || p.codigo.toLowerCase().includes(filter)
    );
    const tbody = document.getElementById('tabla-productos');
    tbody.innerHTML = prods.length
      ? prods.map(p => `<tr>
          <td style="font-family:var(--font-mono)">${p.codigo}</td>
          <td>${p.nombre}</td>
          <td>${p.categoria||'—'}</td>
          <td style="font-family:var(--font-mono)">$${parseFloat(p.precio_venta).toFixed(2)}</td>
          <td><span class="tag ${p.stock <= p.stock_minimo ? 'tag-red' : 'tag-green'}">${p.stock}</span></td>
          <td><span class="tag tag-blue">ACTIVO</span></td>
          <td style="display:flex;gap:6px">
            <button class="btn btn-outline" style="padding:4px 8px" onclick="editarProducto(${p.id})">Editar</button>
            <button class="btn btn-danger"  style="padding:4px 8px" onclick="eliminarProducto(${p.id})">×</button>
          </td>
        </tr>`).join('')
      : '<tr><td colspan="7" style="text-align:center;color:var(--text-muted)">Sin productos. Crea el primero →</td></tr>';
  };

  renderTabla();

  document.getElementById('search-productos').addEventListener('input', e => renderTabla(e.target.value.toLowerCase()));
  document.getElementById('btn-nuevo-producto').addEventListener('click', () => {
    document.getElementById('prod-id').value = '';
    document.getElementById('prod-codigo').value = '';
    document.getElementById('prod-nombre').value = '';
    document.getElementById('prod-descripcion').value = '';
    document.getElementById('prod-categoria').value = '';
    document.getElementById('prod-pcompra').value = '0';
    document.getElementById('prod-pventa').value = '0';
    document.getElementById('prod-stock').value = '0';
    document.getElementById('prod-stockmin').value = '5';
    document.getElementById('modal-producto-title').textContent = 'Nuevo Producto';
    openModal('modal-producto');
  });

  document.getElementById('btn-guardar-producto').addEventListener('click', () => {
    const id = document.getElementById('prod-id').value;
    const data = {
      codigo:       document.getElementById('prod-codigo').value.trim(),
      nombre:       document.getElementById('prod-nombre').value.trim(),
      descripcion:  document.getElementById('prod-descripcion').value.trim(),
      categoria:    document.getElementById('prod-categoria').value.trim(),
      precio_compra: parseFloat(document.getElementById('prod-pcompra').value) || 0,
      precio_venta:  parseFloat(document.getElementById('prod-pventa').value) || 0,
      stock:         parseInt(document.getElementById('prod-stock').value) || 0,
      stock_minimo:  parseInt(document.getElementById('prod-stockmin').value) || 5,
      unidad: 'unidad',
    };
    if (!data.codigo || !data.nombre) return alert('Código y nombre son obligatorios.');
    if (id) {
      DB.dbRun(
        'UPDATE productos SET nombre=?,descripcion=?,categoria=?,precio_compra=?,precio_venta=?,stock=?,stock_minimo=?,unidad=? WHERE id=?',
        [data.nombre,data.descripcion,data.categoria,data.precio_compra,data.precio_venta,data.stock,data.stock_minimo,data.unidad,id]
      );
      DB.saveDB();
    } else {
      DB.Productos.create(data);
    }
    closeModal('modal-producto');
    renderTabla();
  });

  // Delegación de eventos para modals
  setupModalClose();
}

window.editarProducto = function(id) {
  const p = DB.Productos.getById(id);
  if (!p) return;
  document.getElementById('prod-id').value           = p.id;
  document.getElementById('prod-codigo').value        = p.codigo;
  document.getElementById('prod-nombre').value        = p.nombre;
  document.getElementById('prod-descripcion').value   = p.descripcion || '';
  document.getElementById('prod-categoria').value     = p.categoria || '';
  document.getElementById('prod-pcompra').value       = p.precio_compra;
  document.getElementById('prod-pventa').value        = p.precio_venta;
  document.getElementById('prod-stock').value         = p.stock;
  document.getElementById('prod-stockmin').value      = p.stock_minimo;
  document.getElementById('modal-producto-title').textContent = 'Editar Producto';
  openModal('modal-producto');
};

window.eliminarProducto = function(id) {
  if (confirm('¿Eliminar este producto?')) {
    DB.Productos.delete(id);
    Router.navigate('productos');
  }
};

// initClientes definida en modules/clientes.js

function initNotificaciones() {
  const notifs = DB.Notificaciones.getAll();
  const list = document.getElementById('notif-list');
  list.innerHTML = notifs.length
    ? notifs.map(n => `
        <div class="alert alert-${n.tipo === 'alerta' ? 'error' : n.tipo === 'exito' ? 'success' : 'info'}" style="margin-bottom:8px;opacity:${n.leida ? '0.5' : '1'}">
          <strong>${n.titulo}</strong><br/>
          ${n.mensaje}<br/>
          <small style="color:var(--text-muted);font-family:var(--font-mono)">${n.creado_en?.substring(0,16)}</small>
          ${!n.leida ? `<button class="btn btn-outline" style="padding:2px 8px;font-size:10px;margin-left:8px" onclick="DB.Notificaciones.markRead(${n.id});Router.navigate('notificaciones')">Marcar leída</button>` : ''}
        </div>`).join('')
    : '<div style="color:var(--text-muted);text-align:center;padding:40px;font-family:var(--font-mono)">Sin notificaciones</div>';

  document.getElementById('btn-mark-all').addEventListener('click', () => {
    DB.Notificaciones.markAllRead();
    Router.navigate('notificaciones');
  });
}

function initConfiguracion() {
  const configs = DB.Config.getAll();
  const list = document.getElementById('config-list');
  list.innerHTML = configs.map(c => `
    <div style="margin-bottom:14px">
      <label class="form-label">${c.clave.replace(/_/g,' ').toUpperCase()}</label>
      <div style="display:flex;gap:8px">
        <input class="form-input" value="${c.valor}" id="cfg-${c.clave}" style="flex:1"/>
        <button class="btn btn-outline" onclick="saveConfig('${c.clave}')">Guardar</button>
      </div>
      <div style="font-size:11px;color:var(--text-muted);margin-top:3px">${c.descripcion||''}</div>
    </div>`).join('');

  // Verifica rol — si no hay sesión o es admin, muestra el botón
  const wrap = document.getElementById('btn-cfg-sesion-wrap');
  if (wrap) {
    try {
      const sesion = JSON.parse(sessionStorage.getItem('sg_user') || '{}');
      const esAdminLocal = !sesion.rol || sesion.rol === 'admin';
      wrap.style.display = esAdminLocal ? 'block' : 'none';
    } catch(e) {
      wrap.style.display = 'block'; // si hay error, muestra por defecto
    }
  }
}

window.toggleSeccionUsuarios = function() {
  const sec = document.getElementById('seccion-usuarios');
  if (!sec) return;
  if (sec.style.display === 'none') {
    sec.style.display = 'block';
    sec.innerHTML = renderSeccionUsuarios();
  } else {
    sec.style.display = 'none';
  }
};

window.toggleSeccionDocumentos = function() {
  const sec = document.getElementById('seccion-documentos');
  if (!sec) return;
  if (sec.style.display === 'none') {
    sec.style.display = 'block';
    sec.innerHTML = renderSeccionDocumentos();
  } else {
    sec.style.display = 'none';
  }
};

window.toggleSeccionIntegraciones = function() {
  const sec = document.getElementById('seccion-integraciones');
  if (!sec) return;
  if (sec.style.display === 'none') {
    sec.style.display = 'block';
    sec.innerHTML = `
      <div style="margin-top:4px">
        ${typeof renderSeccionAPIDIAN === 'function' ? renderSeccionAPIDIAN() : ''}
        <div id="seccion-api-dian"></div>
        ${typeof renderSeccionEmail === 'function' ? renderSeccionEmail() : ''}
        <div id="seccion-email"></div>
      </div>`;
    // Render after DOM is ready
    setTimeout(() => {
      const d = document.getElementById('seccion-api-dian');
      const e = document.getElementById('seccion-email');
      if (d && typeof renderSeccionAPIDIAN === 'function') d.innerHTML = renderSeccionAPIDIAN();
      if (e && typeof renderSeccionEmail  === 'function') e.innerHTML = renderSeccionEmail();
    }, 10);
  } else {
    sec.style.display = 'none';
  }
};

window.saveConfig = function(clave) {
  const val = document.getElementById(`cfg-${clave}`).value;
  DB.Config.set(clave, val);
  showToast('Configuración guardada');
};

// ============================================================
//  TEST DB
// ============================================================
function initDBTest() {}

window.testCRUD = function(op) {
  const out = document.getElementById('test-output');
  const log = (msg) => { out.textContent += '\n' + msg; };

  out.textContent = `[${new Date().toLocaleTimeString()}] Operación: ${op.toUpperCase()}\n${'─'.repeat(40)}`;

  try {
    if (op === 'create') {
      const ts = Date.now();
      DB.Productos.create({
        codigo: `TEST-${ts}`, nombre: `Producto Test ${ts}`,
        descripcion: 'Creado desde Test DB', categoria: 'Test',
        precio_compra: 10, precio_venta: 15, stock: 100, stock_minimo: 5, unidad: 'unidad'
      });
      log('✅ INSERT ejecutado correctamente');
      log(`   Código: TEST-${ts}`);

    } else if (op === 'read') {
      const prods = DB.Productos.getAll();
      log(`✅ SELECT retornó ${prods.length} producto(s):`);
      prods.slice(0, 5).forEach(p => log(`   [${p.id}] ${p.codigo} — ${p.nombre} — Stock: ${p.stock}`));
      if (prods.length > 5) log(`   ... y ${prods.length - 5} más`);

    } else if (op === 'update') {
      const prods = DB.dbQuery("SELECT * FROM productos WHERE codigo LIKE 'TEST-%' LIMIT 1");
      if (prods.length) {
        const p = prods[0];
        DB.Productos.update(p.id, { ...p, precio_venta: p.precio_venta + 5 });
        log(`✅ UPDATE ejecutado en producto ID ${p.id}`);
        log(`   Precio anterior: $${p.precio_venta} → Nuevo: $${p.precio_venta + 5}`);
      } else {
        log('⚠ No hay productos TEST. Ejecuta CREATE primero.');
      }

    } else if (op === 'delete') {
      const prods = DB.dbQuery("SELECT * FROM productos WHERE codigo LIKE 'TEST-%'");
      if (prods.length) {
        prods.forEach(p => DB.Productos.delete(p.id));
        log(`✅ DELETE (soft) ejecutado en ${prods.length} producto(s) TEST`);
      } else {
        log('⚠ No hay productos TEST para eliminar.');
      }

    } else if (op === 'schema') {
      const tables = DB.dbQuery("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name");
      log(`✅ Tablas en la BD (${tables.length}):`);
      tables.forEach(t => {
        const cols = DB.dbQuery(`PRAGMA table_info(${t.name})`);
        log(`\n   📋 ${t.name} (${cols.length} columnas)`);
        cols.forEach(c => log(`      ${c.name.padEnd(20)} ${c.type}`));
      });

    } else if (op === 'reset') {
      if (confirm('¿RESETEAR TODA LA BASE DE DATOS? Esto borrará todos los datos.')) {
        localStorage.removeItem('sistemgest_db');
        log('⚠ BD eliminada de localStorage');
        log('Recargando en 2 segundos...');
        setTimeout(() => location.reload(), 2000);
      }
    }
  } catch (err) {
    log(`❌ ERROR: ${err.message}`);
  }
};

// ============================================================
//  UTILIDADES
// ============================================================

function openModal(id)  { document.getElementById(id)?.classList.add('open'); }
function closeModal(id) { document.getElementById(id)?.classList.remove('open'); }

function setupModalClose() {
  document.querySelectorAll('[data-close]').forEach(btn => {
    btn.addEventListener('click', () => closeModal(btn.dataset.close));
  });
  document.querySelectorAll('.modal-overlay').forEach(overlay => {
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.classList.remove('open');
    });
  });
}

function updateNotifBadge() {
  const count = DB.Notificaciones.countUnread();
  const badge = document.getElementById('notif-badge');
  if (badge) {
    badge.textContent = count;
    badge.style.display = count > 0 ? '' : 'none';
  }
}

function showToast(msg) {
  const t = document.createElement('div');
  t.className = 'alert alert-success';
  t.style.cssText = 'position:fixed;bottom:20px;right:20px;z-index:999;max-width:300px;animation:fadeIn 0.2s';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 2500);
}

// Reloj en topbar
function startClock() {
  const el = document.getElementById('topbar-time');
  if (!el) return;
  const tick = () => {
    const now = new Date();
    el.textContent = now.toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };
  tick();
  setInterval(tick, 1000);
}

// Toggle sidebar
document.getElementById('menu-toggle').addEventListener('click', () => {
  document.getElementById('sidebar').classList.toggle('collapsed');
});

// Navegación por links del sidebar
document.querySelectorAll('.nav-item[data-route]').forEach(el => {
  el.addEventListener('click', e => {
    e.preventDefault();
    Router.navigate(el.dataset.route);
  });
});

// ============================================================
//  SESIÓN
// ============================================================
window.cerrarSesion = function() {
  if (confirm('¿Deseas cerrar sesión?')) {
    sessionStorage.removeItem('sg_user');
    window.location.href = 'login.html';
  }
};

// ============================================================
//  ARRANQUE
// ============================================================
(async function boot() {
  startClock();

  const ok = await DB.initDB();
  if (!ok) {
    document.getElementById('content-area').innerHTML = `
      <div class="alert alert-error">
        <strong>Error al cargar la base de datos.</strong><br>
        Asegúrate de que los archivos <code>libs/sql-wasm.js</code> y <code>libs/sql-wasm.wasm</code> están presentes.
        <br><br>
        Descárgalos de: <a href="https://github.com/sql-js/sql.js/releases" style="color:var(--accent)">github.com/sql-js/sql.js/releases</a>
      </div>`;
    return;
  }

  // Notificación de bienvenida si es primera vez
  const notifs = DB.Notificaciones.getAll();
  if (notifs.length === 0) {
    DB.Notificaciones.create('info', 'Bienvenido', 'Sistema inicializado correctamente. Base de datos lista.');
    DB.Notificaciones.create('alerta', 'Paso siguiente', 'Descarga sql-wasm.js y sql-wasm.wasm para habilitar la BD.');
  }

  // Carga datos del usuario en el topbar
  try {
    const userData = JSON.parse(sessionStorage.getItem('sg_user') || '{}');
    if (userData.nombre) {
      const nombreEl = document.getElementById('user-nombre');
      const avatarEl = document.getElementById('user-avatar');
      if (nombreEl) nombreEl.textContent = userData.nombre;
      if (avatarEl) avatarEl.textContent = userData.nombre.charAt(0).toUpperCase();
    }
  } catch(e) {}

  // Aplica restricciones de rol
  if (typeof aplicarRestriccionesRol === 'function') aplicarRestriccionesRol();

  // Verifica documentos legales al arrancar
  if (typeof verificarDocumentosAlArrancar === 'function') verificarDocumentosAlArrancar();

  // Inicia el backup automático programado
  if (typeof iniciarBackupAutomatico === 'function') iniciarBackupAutomatico();

  Router.navigate('dashboard');
  updateNotifBadge();
})();
